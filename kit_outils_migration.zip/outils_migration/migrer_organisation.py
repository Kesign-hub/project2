# -*- coding: utf-8 -*-
"""Réorganise les outils de migration par thème dans un NOUVEAU dossier local.

    python migrer_organisation.py                 # SIMULATION : n'écrit rien, affiche le plan
    python migrer_organisation.py --executer      # copie réellement

Principes :
  * COPIE, jamais déplacement : l'ancien dossier reste intact (retour arrière possible).
  * Les groupes de fichiers qui dépendent les uns des autres restent ENSEMBLE
    (generate_cartography.py + cartographie\\, lancer_desensibilisation + desensibilisation_code
    + parametrage_lot1, sas_conn.py + pacifica_migration\\, saskit + config.yml...).
  * Aucun fichier oublié : tout ce qui n'est pas dans le plan est copié dans _a_classer\\
    et listé, pour décision.
  * Données, résultats et référentiels sensibles vont dans des dossiers LOCAUX
    (_donnees_locales\\, _referentiels\\) que publier.bat n'envoie jamais sur le partage.
"""
from __future__ import annotations

import argparse
import fnmatch
import shutil
import sys
import zipfile
from pathlib import Path

ICI = Path(__file__).resolve().parent
SOURCE_DEFAUT = Path.home() / "migration_sas_python"

# Ce qui n'est jamais recopié (régénérable ou propre à un poste)
IGNORER = ["venv", ".venv", "__pycache__", "*.pyc", ".git", ".vscode", ".pytest_cache",
           ".inventaire_lanceurs_cache.sqlite", "pip"]

# (source relative, destination relative). Un dossier est copié avec son contenu.
# L'ordre compte : la première règle qui couvre un fichier gagne.
PLAN: list[tuple[str, str]] = [
    # ---------------------------------------------------------------- 01 inventaire / cartographie
    ("outils_inventaire/generate_cartography.py", "01_inventaire_cartographie/generate_cartography.py"),
    ("outils_inventaire/cartographie", "01_inventaire_cartographie/cartographie"),
    ("outils_inventaire/macros_config.yml", "01_inventaire_cartographie/macros_config.yml"),
    ("outils_inventaire/README_FIX.txt", "01_inventaire_cartographie/README_FIX.txt"),
    ("outils_inventaire/inventaire_lanceurs.py", "01_inventaire_cartographie/inventaire_lanceurs.py"),
    ("outils_inventaire/iventaire_biblio.py", "01_inventaire_cartographie/iventaire_biblio.py"),
    ("outils_inventaire/recense_tables_libname.py", "01_inventaire_cartographie/recense_tables_libname.py"),
    ("outils_inventaire/recherche_libname.py", "01_inventaire_cartographie/recherche_libname.py"),
    # ---------------------------------------------------------------- 02 désensibilisation
    # lancer_desensibilisation_depuis_lineage importe desensibilisation_code ET parametrage_lot1 :
    # les trois restent dans le même dossier (aucune modification de code nécessaire).
    ("outils_inventaire/desensibilisation_code.py", "02_desensibilisation/desensibilisation_code.py"),
    ("outils_inventaire/lancer_desensibilisation_depuis_lineage.py",
     "02_desensibilisation/lancer_desensibilisation_depuis_lineage.py"),
    ("outils_inventaire/parametrage_lot1.py", "02_desensibilisation/parametrage_lot1.py"),
    # ---------------------------------------------------------------- 03 anonymisation / DCP
    ("outils_inventaire/completer_dcp_ref_anonym.py", "03_anonymisation_dcp/completer_dcp_ref_anonym.py"),
    ("outils_inventaire/recenser_dcp_prets.py", "03_anonymisation_dcp/recenser_dcp_prets.py"),
    ("outils_inventaire/recenser_ambiguites_anonym.py", "03_anonymisation_dcp/recenser_ambiguites_anonym.py"),
    ("copier_dcp_dpo.py", "03_anonymisation_dcp/copier_dcp_dpo.py"),
    # ---------------------------------------------------------------- 04 transcription (ex-DOSSIER_BASE)
    # Structure conservée telle quelle : pacifica_migration cherche sas_conn.py dans son dossier parent.
    ("DOSSIER_BASE/pacifica_migration/references_sas", "_donnees_locales/transcription/references_sas"),
    ("DOSSIER_BASE/pacifica_migration/comparaison_*.xlsx", "_donnees_locales/transcription/"),
    ("DOSSIER_BASE/pacifica_migration/verification_dates_*.xlsx", "_donnees_locales/transcription/"),
    ("DOSSIER_BASE/pacifica_migration/agent_sessions", "_donnees_locales/transcription/agent_sessions"),
    ("DOSSIER_BASE/pacifica_migration/SORTIES_PY", "_donnees_locales/transcription/SORTIES_PY"),
    ("DOSSIER_BASE", "04_transcription_sas_python"),
    # ---------------------------------------------------------------- 05 organisation du partage
    ("fileinvent.py", "05_organisation_partage/fileinvent.py"),
    ("Organisation_M/Organisation_M/reorganiser_M.py", "05_organisation_partage/reorganiser_M.py"),
    ("Organisation_M/Organisation_M/LIRE_MOI.md", "05_organisation_partage/LIRE_MOI.md"),
    ("Organisation_M", "_donnees_locales/organisation_M"),
    # ---------------------------------------------------------------- 90 archives (framework saskit, juillet-août)
    # saskit lit config.yml dans le dossier COURANT : tout le bloc reste ensemble, à lancer depuis ce dossier.
    ("saskit", "90_archives/saskit_v1/saskit"),
    ("transcriptions", "90_archives/saskit_v1/transcriptions"),
    ("validation", "90_archives/saskit_v1/validation"),
    ("config.yml", "90_archives/saskit_v1/config.yml"),
    ("sas_libname_inventory.py", "90_archives/saskit_v1/sas_libname_inventory.py"),
    ("sas_lineage.py", "90_archives/saskit_v1/sas_lineage.py"),
    ("parametrage_lineage.py", "90_archives/saskit_v1/parametrage_lineage.py"),
    ("parametrage_anonymisation.py", "90_archives/saskit_v1/parametrage_anonymisation.py"),
    ("test_co.py", "90_archives/brouillons/test_co.py"),
    ("test.py", "90_archives/brouillons/test.py"),
    ("sascfg_personal.py", "90_archives/brouillons/sascfg_personal_ancien.py"),
    ("outils_inventaire/__init__.py", None),                     # plus utile : chaque thème se lance seul
    # ---------------------------------------------------------------- référentiels (LOCAUX, jamais publiés)
    ("EFFECTIFS.csv", "_referentiels/EFFECTIFS.csv"),
    ("outils_inventaire/ref_anonym.csv", "_referentiels/ref_anonym.csv"),
    ("cartographie_c4*.csv", "_referentiels/"),
    ("outils_inventaire/cartographie_c4*.csv", "_referentiels/"),
    # ---------------------------------------------------------------- données et résultats (LOCAUX)
    ("outils_inventaire/anonymisation", "_donnees_locales/anonymisation"),
    ("*.xlsx", "_donnees_locales/"),
    ("*.csv", "_donnees_locales/"),
    ("*.txt", "_donnees_locales/"),
    ("outils_inventaire/*.xlsx", "_donnees_locales/outils_inventaire/"),
    ("outils_inventaire/*.csv", "_donnees_locales/outils_inventaire/"),
]


def _ignore(rel: str) -> bool:
    return any(fnmatch.fnmatch(part, motif) for part in Path(rel).parts for motif in IGNORER)


def _regle(rel: str) -> tuple[str, str | None] | None:
    """Règle qui couvre ce fichier (chemin relatif avec /)."""
    for src, dst in PLAN:
        if any(c in src for c in "*?"):
            # un motif ne descend pas dans les sous-dossiers ('*.xlsx' = racine seulement)
            if src.count("/") == rel.count("/") and fnmatch.fnmatch(rel, src):
                return src, dst
            continue
        if rel == src or rel.startswith(src + "/"):
            return src, dst
    return None


def _destination(rel: str, src: str, dst: str | None) -> str | None:
    if dst is None:
        return None
    if any(c in src for c in "*?"):
        return dst + Path(rel).name if dst.endswith("/") else dst
    if rel == src:
        return dst
    return dst + rel[len(src):]


def planifier(source: Path) -> tuple[list[tuple[Path, str]], list[str]]:
    copies, non_classes = [], []
    for f in sorted(p for p in source.rglob("*") if p.is_file()):
        rel = f.relative_to(source).as_posix()
        if _ignore(rel):
            continue
        r = _regle(rel)
        if r is None:
            non_classes.append(rel)
            copies.append((f, "_a_classer/" + rel))
            continue
        d = _destination(rel, *r)
        if d:
            copies.append((f, d))
    return copies, non_classes


def mises_a_jour(cible: Path, executer: bool) -> list[str]:
    """Zips de mise à jour déposés dans _mises_a_jour\\ (ex. agent_transcription.zip) :
    leurs fichiers pacifica_migration/... sont posés dans 04_transcription_sas_python\\."""
    faits = []
    for z in sorted((ICI / "_mises_a_jour").glob("*.zip")):
        with zipfile.ZipFile(z) as zf:
            for n in zf.namelist():
                if n.endswith("/"):
                    continue
                dest = cible / "04_transcription_sas_python" / n
                if n.startswith("A_AJOUTER"):
                    dest = cible / "04_transcription_sas_python" / "pacifica_migration" / "config" / n
                faits.append(f"{z.name} -> {dest.relative_to(cible)}")
                if executer:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(zf.read(n))
    return faits


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", default=str(SOURCE_DEFAUT), help="ancien dossier (défaut : %(default)s)")
    ap.add_argument("--cible", default=str(ICI), help="nouveau dossier (défaut : celui de ce script)")
    ap.add_argument("--executer", action="store_true", help="copier réellement (sinon simulation)")
    a = ap.parse_args(argv)
    source, cible = Path(a.source).resolve(), Path(a.cible).resolve()
    if not source.is_dir():
        print(f"[erreur] Dossier source introuvable : {source}")
        return 1
    if cible == source or source in cible.parents:
        print("[erreur] La cible doit être un AUTRE dossier que la source (ex. ...\\outils_migration).")
        return 1

    copies, non_classes = planifier(source)
    deja = [(f, d) for f, d in copies if (cible / d).exists()]
    print(f"{'SIMULATION' if not a.executer else 'COPIE'} : {source}  ->  {cible}\n")
    par_theme: dict[str, int] = {}
    for _, d in copies:
        par_theme[d.split("/")[0]] = par_theme.get(d.split("/")[0], 0) + 1
    for t in sorted(par_theme):
        print(f"  {t:<32} {par_theme[t]:>4} fichier(s)")
    if non_classes:
        print(f"\n[!] {len(non_classes)} fichier(s) hors plan -> _a_classer\\ (à décider) :")
        for r in non_classes:
            print(f"      {r}")
    if deja:
        print(f"\n[i] {len(deja)} fichier(s) existent déjà dans la cible : ils seront remplacés.")

    # Le correctif de desensibilisation_code.py livré avec ce kit remplace la copie de l'ancien dossier
    correctif = ICI / "_correctifs" / "desensibilisation_code.py"
    maj = mises_a_jour(cible, a.executer)
    if maj:
        print(f"\n[i] Mises à jour appliquées depuis _mises_a_jour\\ : {len(maj)} fichier(s)")

    if not a.executer:
        print("\nRien n'a été copié. Relance avec --executer pour appliquer.")
        return 0

    journal = []
    for f, d in copies:
        dest = cible / d
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, dest)
        journal.append(f"{f.relative_to(source).as_posix()}\t{d}")
    if correctif.exists():
        shutil.copy2(correctif, cible / "02_desensibilisation" / "desensibilisation_code.py")
        journal.append(f"(kit) _correctifs/desensibilisation_code.py\t02_desensibilisation/desensibilisation_code.py")
    if maj:
        mises_a_jour(cible, True)
        journal += [f"(maj) {m}" for m in maj]
    for d in ("_referentiels", "_donnees_locales"):
        (cible / d).mkdir(exist_ok=True)
    (cible / "journal_migration.tsv").write_text("source\tdestination\n" + "\n".join(journal), encoding="utf-8")
    print(f"\nTerminé : {len(journal)} copie(s). Journal : {cible / 'journal_migration.tsv'}")
    print("L'ancien dossier n'a pas été modifié.")
    print("Étape suivante : installer_environnement.bat")
    return 0


if __name__ == "__main__":
    sys.exit(main())
