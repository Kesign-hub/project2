# Outils de migration SAS -> Python — équipe Mission SAS

Partage : `O:\DSIN\POLORGA\EP\04-Projets équipe\03-Transverse\33-Mission SAS\9-Outils migration`

**On ne travaille pas sur le partage** (trop lent). Chacun a une copie locale, la met à jour
avec `recuperer.bat` et, s'il fait évoluer un outil, la publie avec `publier.bat`.

## Organisation

| Dossier | Contenu | Lancer depuis |
|---|---|---|
| `01_inventaire_cartographie\` | cartographie des fichiers plats et DCP (`generate_cartography.py` + `cartographie\`), inventaire des lanceurs, des bibliothèques et des LIBNAME | ce dossier |
| `02_desensibilisation\` | désensibilisation du code SAS (`desensibilisation_code.py`), traitement en masse depuis le lineage (`lancer_desensibilisation_depuis_lineage.py` + `parametrage_lot1.py`) | n'importe où |
| `03_anonymisation_dcp\` | complétion des DCP depuis ref_anonym, tri des DCP prêts (A_TRAITER), recensement des ambiguïtés, copie des DCP pour le DPO | ce dossier |
| `04_transcription_sas_python\` | connexion SAS depuis Python (`sas_conn.py`, `sascfg_personal.py`, procédure VS Code) et framework de transcription `pacifica_migration\` (lanceurs, recette SAS/Python, cible GCP) | `04_transcription_sas_python\` |
| `05_organisation_partage\` | inventaire et réorganisation des lecteurs réseau | ce dossier |
| `90_archives\` | premier framework (saskit, juillet-août) et brouillons — conservés, plus maintenus | `90_archives\saskit_v1\` |

Restent **sur le poste uniquement** (jamais publiés) :
- `venv\` — l'environnement Python, propre à chaque poste ;
- `_referentiels\` — `EFFECTIFS.csv` (annuaire RH), cartographie C4, `ref_anonym.csv` : données
  sensibles, à récupérer auprès de [responsable à préciser] ;
- `_donnees_locales\` — résultats, inventaires Excel, références SAS, rapports de désensibilisation
  (qui contiennent des valeurs réelles).

## Installation sur un nouveau poste
1. Créer un dossier local vide, par ex. `C:\Users\<moi>\outils_migration`.
2. Y copier `recuperer.bat` depuis le partage et le lancer.
3. Lancer `installer_environnement.bat` : crée `venv\` avec Python 3.12 et les mêmes versions de
   paquets pour tout le monde (dépôt Artifactory interne, proxy contourné pendant l'installation).
   Il termine par `verifier_environnement.py` : toutes les lignes doivent être `[OK]`.
4. Déposer les référentiels dans `_referentiels\`.

## Au quotidien
```powershell
cd C:\Users\<moi>\outils_migration
.\venv\Scripts\activate
python 02_desensibilisation\desensibilisation_code.py --lot 'M:\DSIN\Lot 1' --categorie Climatique
cd 04_transcription_sas_python ; python pacifica_migration\lancer.py climatique --env sas --comparer
```
Chemins avec espaces ou `$` : toujours entre **apostrophes** dans PowerShell.

## Faire évoluer un outil
1. Modifier et tester en local.
2. `.\publier.bat test` (simulation), puis `.\publier.bat`.
3. Prévenir l'équipe, qui lance `recuperer.bat`.

La publication n'écrase jamais un fichier plus récent sur le partage : si deux personnes ont
modifié le même fichier, il apparaît comme « Plus ancien » dans le journal, à fusionner à la main.
Si plusieurs personnes modifient régulièrement les mêmes outils, passer sur Git.
