@echo off
chcp 1252 >nul
setlocal
REM ===========================================================================
REM  Cree (ou complete) l'environnement Python du dossier, identique pour toute
REM  l'equipe : Python 3.12, paquets de requirements.txt, depot Artifactory interne.
REM  A lancer UNE FOIS par poste, depuis ce dossier (double-clic ou PowerShell).
REM  Ne touche a aucune configuration du poste : les proxys sont neutralises
REM  uniquement pendant l'installation.
REM ===========================================================================
cd /d "%~dp0"

set "INDEX=https://registry.saas.cagip.group.gca/artifactory/api/pypi/pypi-remote/simple"
set "HOTE=registry.saas.cagip.group.gca"

REM Le depot Artifactory est interne : on contourne le proxy local (localhost:3128)
set "HTTP_PROXY="
set "HTTPS_PROXY="
set "http_proxy="
set "https_proxy="

where python >nul 2>nul || (echo [ERREUR] Python introuvable dans le PATH. & goto fin)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set "PYV=%%v"
echo Python detecte : %PYV%
echo %PYV% | findstr /b "3.12." >nul || echo [ATTENTION] Python 3.12 attendu (reference : 3.12.10).

if not exist "venv\Scripts\python.exe" (
  echo Creation de l'environnement venv...
  python -m venv venv || (echo [ERREUR] creation du venv impossible & goto fin)
)

echo Installation des paquets (depot Artifactory)...
venv\Scripts\python.exe -m pip install --upgrade pip --index-url %INDEX% --trusted-host %HOTE% -q
venv\Scripts\python.exe -m pip install -r requirements.txt --index-url %INDEX% --trusted-host %HOTE%
if errorlevel 1 (echo [ERREUR] installation des paquets : voir les messages ci-dessus & goto fin)

echo.
venv\Scripts\python.exe verifier_environnement.py

:fin
echo.
echo Pour travailler :  .\venv\Scripts\activate
endlocal
pause
