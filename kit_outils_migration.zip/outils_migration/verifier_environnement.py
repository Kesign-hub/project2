# -*- coding: utf-8 -*-
"""Vérifie que l'environnement est prêt :   .\\venv\\Scripts\\python.exe verifier_environnement.py

Contrôle : version de Python, venv actif, paquets aux bonnes versions, chaque outil
importable depuis son dossier, référentiels locaux présents. Ne se connecte à rien.
"""
from __future__ import annotations

import importlib
import importlib.metadata as md
import os
import re
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parent
OK, KO, INFO = "[OK]  ", "[KO]  ", "[i]   "
erreurs = 0


def ligne(etat, texte):
    global erreurs
    erreurs += etat == KO
    print(etat + texte)


# 1. Python et venv
v = sys.version_info
ligne(OK if (v.major, v.minor) == (3, 12) else KO, f"Python {sys.version.split()[0]} (attendu 3.12.x)")
dans_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
ligne(OK if dans_venv else KO, f"environnement virtuel : {sys.prefix}")

# 2. Paquets
for l in (RACINE / "requirements.txt").read_text(encoding="utf-8").splitlines():
    l = l.strip()
    if not l or l.startswith("#"):
        continue
    nom, _, attendu = l.partition("==")
    try:
        installe = md.version(nom)
        ligne(OK if not attendu or installe == attendu else KO,
              f"{nom} {installe}" + (f" (attendu {attendu})" if attendu and installe != attendu else ""))
    except md.PackageNotFoundError:
        ligne(KO, f"{nom} absent -> relancer installer_environnement.bat")

# 3. Outils importables depuis leur dossier (dépendances internes)
OUTILS = [
    ("01_inventaire_cartographie", ["cartographie.sas_scanner", "cartographie.dcp_generator"]),
    ("02_desensibilisation", ["desensibilisation_code", "parametrage_lot1"]),
    ("04_transcription_sas_python", ["sas_conn"]),
    ("04_transcription_sas_python/pacifica_migration", ["pacifica.contexte", "pacifica.sources",
                                                        "pacifica.reference_sas"]),
]
for dossier, modules in OUTILS:
    d = RACINE / dossier
    if not d.is_dir():
        ligne(KO, f"dossier absent : {dossier}")
        continue
    sys.path.insert(0, str(d))
    if dossier.endswith("pacifica_migration"):
        sys.path.insert(0, str(d.parent))
    for m in modules:
        try:
            importlib.import_module(m)
            ligne(OK, f"{dossier} : import {m}")
        except Exception as e:  # noqa: BLE001
            ligne(KO, f"{dossier} : import {m} -> {type(e).__name__}: {e}")

# 4. Référentiels locaux (jamais publiés sur le partage)
ref = RACINE / "_referentiels"
for f in ("EFFECTIFS.csv",):
    ligne(OK if (ref / f).exists() else INFO,
          f"_referentiels\\{f}" + ("" if (ref / f).exists() else " absent : la désensibilisation des noms ne fonctionnera pas"))
c4 = list(ref.glob("cartographie_c4*.csv")) if ref.exists() else []
ligne(OK if c4 else INFO, "cartographie C4 : " + (c4[0].name if c4 else "absente (détection C4 par mots-clés seulement)"))

# 5. Proxy (information)
for k in ("HTTP_PROXY", "HTTPS_PROXY"):
    if os.environ.get(k):
        print(INFO + f"{k} défini ({re.sub(r'//[^@]+@', '//***@', os.environ[k])}) : normal hors installation")

print("\n" + ("Environnement prêt." if not erreurs else f"{erreurs} problème(s) à corriger (lignes [KO])."))
sys.exit(1 if erreurs else 0)
