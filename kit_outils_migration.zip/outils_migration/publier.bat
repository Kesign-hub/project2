@echo off
chcp 1252 >nul
setlocal
REM ===========================================================================
REM  PUBLIER : copie les outils de CE dossier local vers le partage d'equipe.
REM  - Seulement ce qui a change ; ne supprime rien sur le partage.
REM  - N'ecrase JAMAIS un fichier plus recent sur le partage (modifie par un
REM    collegue) : il apparait comme "Plus ancien" dans le journal.
REM  - N'envoie jamais : venv, referentiels (EFFECTIFS...), donnees, resultats,
REM    rapports de desensibilisation (valeurs reelles).
REM  Usage :  publier.bat          publication
REM           publier.bat test     simulation (montre ce qui serait copie)
REM ===========================================================================
set "LOCAL=%~dp0."
set "PARTAGE=O:\DSIN\POLORGA\EP\04-Projets �quipe\03-Transverse\33-Mission SAS\9-Outils migration"

if not exist "%PARTAGE%\" (echo [ERREUR] Partage inaccessible : %PARTAGE% & goto fin)
set "SIMU="
if /I "%~1"=="test" set "SIMU=/L"
for /f %%d in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmm"') do set "HORO=%%d"
set "JOURNAL=%~dp0publication_%HORO%.log"

robocopy "%LOCAL%" "%PARTAGE%" /E /XO /FFT /R:1 /W:2 /NP /NDL %SIMU% ^
  /XD venv .venv __pycache__ .git .vscode .pytest_cache _referentiels _donnees_locales _a_classer ^
      _mises_a_jour _correctifs agent_sessions references_sas SORTIES_PY _echange sauvegarde_tri ^
  /XF *.pyc *.log journal_migration.tsv migrer_organisation.py EFFECTIFS*.csv cartographie_c4*.csv ^
      ref_anonym*.csv *_rapport_desensibilisation.txt *.sas7bdat *.parquet *.pkl *.sqlite ~$* ^
  /LOG:"%JOURNAL%" /TEE

if %ERRORLEVEL% GEQ 8 (echo [ERREUR] Publication en echec : voir %JOURNAL% & goto fin)
echo.
if defined SIMU (echo SIMULATION : rien n'a ete copie.) else (echo Publication terminee.)
echo Journal : %JOURNAL%
echo Lignes "Plus ancien" = plus recent sur le partage, NON ecrase : a regarder.
:fin
endlocal
