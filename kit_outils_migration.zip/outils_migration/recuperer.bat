@echo off
chcp 1252 >nul
setlocal
REM ===========================================================================
REM  RECUPERER : copie les outils du partage d'equipe dans CE dossier local.
REM  Premiere fois : copier ce fichier dans un dossier vide de son poste
REM  (ex. C:\Users\<moi>\outils_migration), puis le lancer.
REM  N'ecrase jamais un fichier local plus recent ; ne supprime rien.
REM  Usage :  recuperer.bat          recuperation
REM           recuperer.bat test     simulation
REM ===========================================================================
set "LOCAL=%~dp0."
set "PARTAGE=O:\DSIN\POLORGA\EP\04-Projets �quipe\03-Transverse\33-Mission SAS\9-Outils migration"

if not exist "%PARTAGE%\" (echo [ERREUR] Partage inaccessible : %PARTAGE% & goto fin)
set "SIMU="
if /I "%~1"=="test" set "SIMU=/L"

robocopy "%PARTAGE%" "%LOCAL%" /E /XO /FFT /R:1 /W:2 /NP /NDL %SIMU% ^
  /XD venv .venv __pycache__ .git /XF *.pyc publication_*.log /TEE

if %ERRORLEVEL% GEQ 8 (echo [ERREUR] Recuperation en echec. & goto fin)
echo.
if defined SIMU (echo SIMULATION : rien n'a ete copie.) else (echo Recuperation terminee dans %~dp0)
if not exist "%~dp0venv\Scripts\python.exe" (
  echo.
  echo Premiere installation : lancer installer_environnement.bat
  echo puis deposer EFFECTIFS.csv et la cartographie C4 dans _referentiels\
)
:fin
endlocal
