#!/usr/bin/env python3
"""Copie contrôlée selon le plan. Simulation par défaut; aucune suppression des sources.
Python 3.9+, bibliothèque standard. Les liens dans les programmes ne sont pas réécrits.
"""
import argparse
import collections
import csv
import hashlib
import json
import os
import shutil
import stat
import uuid
from datetime import datetime
from pathlib import Path, PureWindowsPath

BLOCK=4*1024*1024
MARKER='.organisation_pacifica.json'


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(BLOCK),b''):h.update(chunk)
    return h.hexdigest()


def relative_parts(value):
    p=PureWindowsPath(value)
    if not value or p.is_absolute() or p.drive or any(x in ('..','.') or ':' in x for x in p.parts):
        raise ValueError(f'Chemin relatif invalide: {value}')
    return p.parts


def no_links(root,parts):
    p=root
    for part in (None,)+tuple(parts):
        if part is not None:p=p/part
        if p.exists() or p.is_symlink():
            st=p.lstat()
            if stat.S_ISLNK(st.st_mode) or getattr(st,'st_file_attributes',0)&1024:
                raise ValueError(f'Lien/jonction non parcouru: {p}')
    return p


def fingerprint(st):return st.st_size,st.st_mtime_ns,st.st_ctime_ns


def metadata_matches(path,row):
    st=path.stat()
    if not stat.S_ISREG(st.st_mode):raise ValueError('La source n’est pas un fichier régulier')
    if st.st_size!=int(row['Taille_octets']):raise ValueError('Taille source modifiée depuis l’inventaire: actualiser le plan')
    expected=row.get('Derniere_modification','').strip()
    if expected:
        dt=datetime.fromisoformat(expected)
        actual=datetime.fromtimestamp(st.st_mtime,dt.tzinfo).replace(microsecond=0)
        if actual!=dt.replace(microsecond=0):raise ValueError('Date source modifiée depuis l’inventaire: actualiser le plan')
    return st


def publish(temp,target):
    # Windows rename refuses to replace an existing file. POSIX link is exclusive.
    if os.name=='nt':os.rename(temp,target)
    else:
        os.link(temp,target)
        temp.unlink()


def copy_verified(source,target,row):
    before=metadata_matches(source,row)
    if target.exists() or target.is_symlink():
        if not target.is_file() or target.is_symlink():raise FileExistsError('Destination existante incompatible')
        if source.samefile(target):raise ValueError('Source et destination désignent le même fichier')
        if target.stat().st_size!=before.st_size:raise FileExistsError('Destination différente: aucun écrasement')
        source_hash=digest(source);target_hash=digest(target)
        if fingerprint(source.stat())!=fingerprint(before):raise ValueError('Source modifiée pendant le contrôle')
        if source_hash!=target_hash:raise FileExistsError('Destination différente: aucun écrasement')
        return 'DEJA_IDENTIQUE',source_hash,target_hash
    target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_name('.pacifica_'+uuid.uuid4().hex+'.part')
    try:
        h=hashlib.sha256()
        with source.open('rb') as src,temp.open('xb') as dst:
            for chunk in iter(lambda:src.read(BLOCK),b''):
                dst.write(chunk);h.update(chunk)
            dst.flush();os.fsync(dst.fileno())
        if fingerprint(source.stat())!=fingerprint(before):raise ValueError('Source modifiée pendant la copie')
        copied=digest(temp)
        if temp.stat().st_size!=before.st_size or copied!=h.hexdigest():raise IOError('Vérification SHA-256 de la copie échouée')
        if fingerprint(source.stat())!=fingerprint(before):raise ValueError('Source modifiée pendant la vérification de la copie')
        shutil.copystat(source,temp,follow_symlinks=False)
        publish(temp,target)
        return 'COPIE_VERIFIEE',h.hexdigest(),copied
    finally:
        # Uniquement le temporaire créé par cette opération, jamais une source ou un fichier préexistant.
        if temp.exists():temp.unlink()


def load_plan(path):
    with path.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f,delimiter=';'))
    required={'ID','Action','Chemin_source_relatif','Chemin_cible_relatif','Taille_octets','Domaine','Circuit'}
    if not rows or not required<=rows[0].keys():raise ValueError('Plan vide ou colonnes attendues absentes')
    if len({r['ID'] for r in rows})!=len(rows):raise ValueError('ID dupliqué dans le plan')
    for r in rows:
        relative_parts(r['Chemin_source_relatif'])
        if r['Action'] not in ('COPIER','SIGNALER'):raise ValueError('Action inconnue dans le plan')
        if r['Action']=='COPIER':relative_parts(r['Chemin_cible_relatif']);int(r['Taille_octets'])
    # Aucun membre d’une collision n’est copié, y compris sur un système sensible à la casse.
    targets=collections.defaultdict(list);sources=collections.defaultdict(list)
    for r in rows:
        if r['Action']=='COPIER':
            targets[str(PureWindowsPath(r['Chemin_cible_relatif'])).casefold()].append(r)
            sources[str(PureWindowsPath(r['Chemin_source_relatif'])).casefold()].append(r)
    blocked=set()
    for group in list(targets.values())+list(sources.values()):
        if len(group)>1:blocked.update(r['ID'] for r in group)
    for name,group in targets.items():
        for parent in PureWindowsPath(name).parents:
            if str(parent).casefold() in targets:
                blocked.update(r['ID'] for r in group)
                blocked.update(r['ID'] for r in targets[str(parent).casefold()])
    for r in rows:
        if r['ID'] in blocked:r.update(Action='SIGNALER',Motif='Collision de chemins dans le plan: aucun fichier concerné copié')
    return rows


def run(plan_path,architecture,source,target,reports,copy=False,domain=None,circuit=None,limit=None,all_lots=False):
    rows=load_plan(plan_path)
    selected=[r for r in rows if (not domain or r['Domaine'].casefold()==domain.casefold()) and
              (not circuit or r['Circuit'].casefold()==circuit.casefold())]
    if not selected:raise ValueError('Aucune ligne ne correspond aux filtres')
    source=source.resolve();target=target.resolve();reports=reports.resolve()
    if target==source or source in target.parents or target in source.parents:
        raise ValueError('Cible à placer hors de la source, et non dans un dossier parent de la source')
    if reports==source or source in reports.parents or reports==target or target in reports.parents:
        raise ValueError('Rapport à placer hors de la source et de la cible')
    if copy:
        if not source.is_dir():raise FileNotFoundError(f'Source inaccessible: {source}')
        no_links(source,());no_links(target.parent,())
        if not target.parent.is_dir():raise FileNotFoundError('Dossier parent de la cible inaccessible')
        candidats=[r for r in selected if r['Action']=='COPIER']
        if limit is not None:candidats=candidats[:limit]
        besoin=sum(int(r['Taille_octets']) for r in candidats
                   if not target.joinpath(*relative_parts(r['Chemin_cible_relatif'])).exists())
        libre=shutil.disk_usage(target.parent).free
        if libre<besoin+50*1024*1024:
            raise OSError(f'Espace cible insuffisant: {besoin/1e9:.2f} Go à copier, {libre/1e9:.2f} Go libres')
        token=dict(source=str(source),outil='PACIFICA_COPIE_V1')
        if target.exists():
            no_links(target,())
            if not (target/MARKER).is_file() or json.loads((target/MARKER).read_text())!=token:
                raise ValueError('Cible existante non reconnue pour ce plan: choisir une nouvelle racine dédiée')
        else:
            target.mkdir()
            with (target/MARKER).open('x',encoding='utf-8') as f:json.dump(token,f)
        for value in architecture['dossiers']:
            parts=relative_parts(value)
            if not all_lots and len(parts)>1 and parts[0]=='Lots' and parts[1]!='Lot_01':continue
            no_links(target,parts).mkdir(parents=True,exist_ok=True)
    reports.mkdir(parents=True,exist_ok=False)
    nouveaux=0;acces_erreurs=0
    # Tout fichier apparu après l’inventaire reste signalé, jamais attribué arbitrairement.
    connus={str(PureWindowsPath(r['Chemin_source_relatif'])).casefold() for r in rows}
    with (reports/'nouveaux_fichiers_non_recenses.csv').open('w',encoding='utf-8-sig',newline='') as nf, \
         (reports/'acces_inventaire.csv').open('w',encoding='utf-8-sig',newline='') as ef:
        nw=csv.writer(nf,delimiter=';');nw.writerow(['Chemin','Statut'])
        ew=csv.writer(ef,delimiter=';');ew.writerow(['Chemin','Erreur'])
        def scan_error(exc):
            nonlocal acces_erreurs
            acces_erreurs+=1;ew.writerow([str(getattr(exc,'filename','')),str(exc)])
        if source.is_dir():
            for current,dirs,names in os.walk(source,onerror=scan_error,followlinks=False):
                kept=[]
                for d in dirs:
                    try:no_links(source,(Path(current)/d).relative_to(source).parts);kept.append(d)
                    except (OSError,ValueError) as exc:scan_error(exc)
                dirs[:]=kept
                for name in names:
                    file=Path(current)/name
                    rel=str(PureWindowsPath(*file.relative_to(source).parts)).casefold()
                    if rel not in connus:
                        nw.writerow([str(file),'NON_RECENSE_NON_COPIE']);nouveaux+=1
    fields=['ID','Domaine','Circuit','Source','Destination','Statut','Motif','SHA256_source','SHA256_copie']
    counts=collections.Counter();attempts=0
    with (reports/'journal.csv').open('w',encoding='utf-8-sig',newline='') as f, \
         (reports/'fichiers_non_copies.csv').open('w',encoding='utf-8-sig',newline='') as g:
        journal=csv.DictWriter(f,fieldnames=fields,delimiter=';');journal.writeheader()
        pending=csv.DictWriter(g,fieldnames=fields,delimiter=';');pending.writeheader()
        for r in selected:
            item=dict(ID=r['ID'],Domaine=r['Domaine'],Circuit=r['Circuit'],
                Source=str(source.joinpath(*relative_parts(r['Chemin_source_relatif']))),
                Destination=str(target.joinpath(*relative_parts(r['Chemin_cible_relatif']))) if r['Chemin_cible_relatif'] else '',
                Statut='',Motif=r.get('Motif',''),SHA256_source='',SHA256_copie='')
            if r['Action']=='SIGNALER':item['Statut']='A_VERIFIER_NON_COPIE'
            elif limit is not None and attempts>=limit:item['Statut']='NON_TRAITE_LIMITE'
            elif not copy:
                attempts+=1;item['Statut']='SIMULATION_COPIE_PREVUE'
            else:
                attempts+=1
                try:
                    src=no_links(source,relative_parts(r['Chemin_source_relatif']))
                    dst=no_links(target,relative_parts(r['Chemin_cible_relatif']))
                    status,h1,h2=copy_verified(src,dst,r)
                    item.update(Statut=status,SHA256_source=h1,SHA256_copie=h2)
                except Exception as exc:item.update(Statut='ERREUR_NON_COPIE',Motif=str(exc))
            counts[item['Statut']]+=1;journal.writerow(item);f.flush()
            if item['Statut'] in ('A_VERIFIER_NON_COPIE','ERREUR_NON_COPIE','NON_TRAITE_LIMITE'):
                pending.writerow(item);g.flush()
            if attempts and attempts%25==0 and r['Action']=='COPIER':print(f'{attempts} fichiers examinés...',flush=True)
    result=dict(mode='COPIE' if copy else 'SIMULATION',source=str(source),cible=str(target),
        lignes=len(selected),nouveaux_fichiers_non_copies=nouveaux,erreurs_scan=acces_erreurs,plan_sha256=digest(plan_path),statuts=dict(counts),octets_planifies=sum(int(r['Taille_octets']) for r in selected if r['Action']=='COPIER'))
    (reports/'resume.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2));print(f'Rapports: {reports}')
    return result


def main():
    here=Path(__file__).parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',type=Path,default=here/'plan_classement.csv')
    p.add_argument('--architecture',type=Path,default=here/'architecture.json')
    p.add_argument('--source',type=Path)
    p.add_argument('--cible',type=Path)
    p.add_argument('--rapport',type=Path,help='Nouveau dossier de rapport hors source et cible')
    p.add_argument('--copier',action='store_true',help='Effectuer réellement les copies; sans option: simulation')
    p.add_argument('--domaine',help='Exemple: Climatique, Reporting, Satisfaction_client')
    p.add_argument('--circuit',choices=['Usine','Onshore','Commun_ou_non_identifie'])
    p.add_argument('--limite',type=int,help='Limiter le nombre de fichiers prévus/examinés')
    p.add_argument('--tous-les-lots',action='store_true')
    a=p.parse_args()
    if a.limite is not None and a.limite<1:p.error('--limite doit être positif')
    arch=json.loads(a.architecture.read_text(encoding='utf-8'))
    reports=a.rapport or Path.home()/('Rapport_organisation_M_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    result=run(a.plan,arch,a.source or Path(arch['source']),a.cible or Path(arch['cible_proposee']),reports,a.copier,a.domaine,a.circuit,a.limite,a.tous_les_lots)
    if result['statuts'].get('ERREUR_NON_COPIE'):raise SystemExit(1)


if __name__=='__main__':
    main()
