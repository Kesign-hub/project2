# PACIFICA — Organisation simple, parcours Usine et Onshore, copie contrôlée

Ouvrir organisation_M.html. Script principal: reorganiser_M.py.

## Organisation
Racine proposée: M:\DSIN\Migration_SAS_Python (nouvelle racine, distincte de M:\DSIN\Lot 1).

Dans Lots/Lot_01, ouvrir le domaine: Climatique, Demandes, Pilotage_activite, Reporting ou Satisfaction_client.
Chaque domaine contient cinq dossiers:
- 01_Codes: Communs (sources SAS), Usine et Onshore (versions attribuées à un parcours).
- 02_Carto_DCP: cartographie, DCP, dossiers DPO à confirmer, validations et historiques.
- 03_Desensibilisation: données, code, pilotage DOC et contrôles; les ressources communes ne sont pas dupliquées par parcours.
- 04_Recette: Usine et Onshore, puis ensembles SAS/Python avec leurs logs et résultats.
- 05_Livraisons: Usine et Onshore, avec statut à qualifier jusqu’à preuve de validation/envoi.

Les outils partagés restent dans Outils, le guide dans 00_Guide_et_suivi. 99_Archives est disponible pour les décisions d’archivage ultérieures.

## Comment le classement est déterminé
Le plan est fondé sur l’inventaire fourni de M:\DSIN\Lot 1, pas sur tout M:. Seuls les fichiers figurent dans le plan exécutable (8 723 lignes). Les répertoires sont créés via architecture.json.
Les dossiers portant explicitement le nom usine ou ONSHORE sous Desensibilisation/synthese déterminent le parcours; un chemin contenant les deux est ambigu. Aucun parcours n’est déduit d’une extension .py ni de la seule date.
Les ensembles d’exécution sans parcours explicite, les éléments à revoir/exclure, les anciennes versions présumées et les chemins non déterminés sont signalés et non copiés.
Les codes sources et DCP communs peuvent être copiés sans attribution arbitraire à Usine ou Onshore. Le projet migration_sas_python reste entier sous Outils, pour préserver les imports et dépendances internes; son venv et les caches ne sont pas copiés.
Les dossiers DPO et usine ne sont pas présumés validés ou livrés. Les ZIP existants identifiés comme Usine vont en 05_Livraisons/Usine/A_qualifier; aucune livraison réelle n’est déduite du nom.
Les .bak et dossiers OLD/OLD2 sont conservés dans la source et signalés, pas supprimés. Les historiques de complétion DCP identifiés sont conservés comme historiques, sans décision sur la version faisant foi.

## Démarrer (Python 3.9+, sans dépendances)
Dézipper tout le ZIP dans un dossier local. Dans Anaconda Prompt ou un terminal, se placer dans Organisation_M.

1. SIMULATION, aucune création dans M: ni copie de fichier:
    python reorganiser_M.py

2. Premier essai réel limité à 10 fichiers Climatique:
    python reorganiser_M.py --copier --domaine Climatique --limite 10

3. Copier tout Climatique, puis reprendre les autres domaines:
    python reorganiser_M.py --copier --domaine Climatique
    python reorganiser_M.py --copier --domaine Demandes
    python reorganiser_M.py --copier --domaine Pilotage_activite
    python reorganiser_M.py --copier --domaine Reporting
    python reorganiser_M.py --copier --domaine Satisfaction_client

4. Copier tous les fichiers dont la destination est identifiée, outils et éléments communs compris:
    python reorganiser_M.py --copier

Filtrer un parcours (les ressources communes ne sont pas incluses dans ce filtre):
    python reorganiser_M.py --copier --domaine Climatique --circuit Usine
    python reorganiser_M.py --copier --domaine Climatique --circuit Onshore

Cible personnalisée:
    python reorganiser_M.py --copier --cible "M:\DSIN\Migration_SAS_Python_organise"

Créer aussi les modèles des lots 2 à 8:
    python reorganiser_M.py --copier --tous-les-lots

Depuis Jupyter, lancer dans une cellule (adapter le dossier):
    import subprocess
    import sys
    subprocess.run([sys.executable, r"C:\chemin\Organisation_M\reorganiser_M.py"], check=True)

Pour l’essai réel depuis Jupyter:
    subprocess.run([sys.executable, r"C:\chemin\Organisation_M\reorganiser_M.py", "--copier", "--domaine", "Climatique", "--limite", "10"], check=True)

## Rapports
Un dossier local horodaté Rapport_organisation_M_* est créé dans le profil utilisateur et son chemin est affiché.
- journal.csv: une ligne par fichier du plan dans le périmètre choisi; copies vérifiées, déjà identiques, erreurs, cas à vérifier et fichiers non traités du fait de la limite.
- fichiers_non_copies.csv: cas à vérifier, erreurs et fichiers laissés de côté par la limite.
- nouveaux_fichiers_non_recenses.csv: fichiers trouvés sur le lecteur depuis l’inventaire, sans classement automatique.
- acces_inventaire.csv: chemins non parcourus et erreurs d’accès du nouveau scan.
- resume.json: compteurs, volume planifié et empreinte du plan utilisé.
Le fichier fichiers_a_verifier.csv présent dans le ZIP est le préclassement initial, pas le journal de la dernière exécution.

## Contrôles de copie
- Source conservée: aucun déplacement ni suppression de M:\DSIN\Lot 1.
- Cible obligatoirement distincte de la source et de ses dossiers parents/enfants.
- Première copie vers une nouvelle racine. Les exécutions suivantes reconnaissent la cible via un marqueur technique créé par le script. Si la cible a été créée par un ancien script sans ce marqueur, choisir une nouvelle cible dédiée.
- Le plan peut évoluer après revue: une nouvelle exécution ajoute les fichiers manquants sans écraser ceux déjà copiés. Conserver l’historique du plan; le journal en enregistre l’empreinte.
- Vérification de la taille et de la date de modification de la source par rapport à l’inventaire. Si elles ont changé, le fichier est signalé et ne sera pas copié avec ce plan.
- Copie par blocs dans un temporaire, comparaison SHA-256, puis publication sans écrasement. Le temporaire appartient uniquement au script et est retiré si la copie échoue.
- Destination existante: si le contenu est identique (SHA-256), statut DEJA_IDENTIQUE; sinon conflit signalé et fichier conservé tel quel.
- Liens symboliques et jonctions non parcourus. Chemins relatifs invalides et collisions bloqués.
- Vérification de l’espace libre avant copie. Le volume initial identifié est d’environ 110 Go; --limite aide à démarrer petit. La lecture et la vérification d’un gros fichier peuvent prendre du temps.
- Le script ne réécrit aucun chemin dans les programmes et ne lance ni SAS ni Python métier. L’intégrité binaire des copies ne garantit pas leur fonctionnement après changement de racine: configurations, LIBNAME, %INCLUDE, imports et liens Excel/EGP restent à vérifier.
- Conserver les restrictions d’accès aux données et référentiels de tokenisation dans la cible. Les droits hérités du dossier cible sont à vérifier: le script ne reproduit pas les ACL Windows.
- La structure interne des ZIP attendue par Accenture n’est pas modifiée; les copies de ZIP restent strictement identiques.

## Lever un cas à vérifier
Revoir la ligne du plan avec l’équipe, puis renseigner une destination relative justifiée et Action=COPIER; conserver une copie du plan précédent. Ne pas décider d’un parcours ni d’une version à partir de suppositions. Un fichier nouvellement apparu ou modifié nécessite une actualisation de l’inventaire et du plan.

## Vérifications réalisées avant livraison
Tests synthétiques: simulation sans création cible, copie et SHA-256, reprise, destination différente non écrasée, sources inchangées, fichiers ambigus ignorés, collisions insensibles à la casse, liens, chemins invalides, source modifiée et essai limité. Le lecteur M: réel, ses droits Windows et l’exécution SAS restent à vérifier sur le poste Pacifica.
