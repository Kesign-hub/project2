/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE4_DONNES_REC.SAS									      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 05/09/2018												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION:																	  */
/* Afin de suivre l'impact de la convention IRSI qui s'applique sur les sinistres */
/* en habitation (NH, HA,MR),en PRO (MP) et en AGRI (MA) avec la garantie DDE ou  */
/* INC (hors ELEC et INC sinistr�es simultan�ment), nous construisons un datamart.*/
/* Ce dernier contient le p�rim�tre suivant :									  */
/* 			- Sinistres survenus depuis 01/06/2018								  */
/*			- hors les sinistres annul�s										  */
/*			- avec la garantie DDE et/ou INC non annul�							  */
/*			- pour les produits NH, HA, MR, MP, MA								  */
/*			- Aucun sinistre DDE ou INC ne sera ouvert en pr�d�claration		  */
/* Le principe est d'ajouter chaque mois les donn�es vision fin du mois pr�c�dent */
/* Dans cette �tape nous ajoutons les donn�es des REC que DARVA nous transmets    */
/* Plus pr�cis�ment les REC o� nous sommes l'assureur gestionnaire				  */
/* ------------------------------------------------------------------------------ */
/* JUILLET 2019 |		| - modification du fichier sinistre et du code de 		  */
/*							recalcul des dates du fichier: 						  */
/*							CSV_IRSI_PACIFICA_SINISTRE_&DARVA..csv				  */
/* 							Transformation dans Notepad de l'�criture des dates	  */
/*							Puis correction de la transformation de la variable   */
/*							au format Mdy										  */
/* MARS 2020	|		|- Migration du r�pertoire G:\ vers O:\					  */
/* ------------------------------------------------------------------------------ */


%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;
/* Emplacement des donn�es DARVA REC */
%let chemin =\\bureautique\bureautique\DSIN\POLORGA\EP\02-Productions r�currentes\03-MENS\03-Suivi IRSI\03-Fichiers sources\01-Donn�es externes\DARVA;


%let mois_deb = 1;
%let mois_fin = 12;


/* -------------------------------------------------------------------------------- */
/* ETAPE 1 : Import des fichiers mis � disposition par DARVA sur les donn�es REC    */
/* -------------------------------------------------------------------------------- */
/* INFORMATIONS SUR LE SINISTRE */

%Macro SINISTREDARVA;
    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i.;
        		%else %let i_format = &i.;

        data IRSI_SINISTRE_&i_format.20&j.;
        %let _EFIERR_ = 0; /* set the ERROR detection macro variable */
        infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_SINISTRE_A20&j.M&i_format..csv"
            dlm=';'
            missover dsd lrecl=32767 firstobs=2;

        informat ID_MSG best12.;
        informat ASSU_CALCUL_STATS $8.;
        informat DATE_REC date9.;
        informat NAT_SINISTRE $2.;
        informat SOURCE $1.;
        informat EXPERT $55.;
        informat REF_EXPERT $12.;
        informat MAIL_EXPERT $50.;
        informat RAISON_SOCIALE $30.;
        informat NUM_DOC $2.;
        informat NUM_DOSS_DARVA $12.;
        informat DTOM date9.;
        informat DT_VISITEXP date9.;
        informat DTENVREC date9.;
        informat TYP_EXP $1.;
        informat ASSUREUR_GEST $30.;
        informat CODE_GTA $3.;
        informat ASSU_ACPR $10.;
        informat NUMORDREMISS $11.;
        informat SIN $17.;
        informat NUM_CONTRAT $17.;
        informat CP_ASSURE $5.;
        informat VILLE_ASSURE $50.;
        informat QUALASSUR $2.;
        informat USAGE $2.;
        informat CP_SINISTRE $5.;
        informat VILLE_SINISTRE $50.;
        informat DATE_SINISTRE date9.;
        informat HEURE_SINISTRE best8.;
        informat REPETITIF $1.;
        informat IMMAT_IMMEUBLE $20.;
        informat STATUT_IMMEUBLE $2.;
        informat TOTAL_ASSIETTE_DU_LOCAL_HT best8.;
        informat TOTAL_RECOURS_PO_TTC best8.;
        informat TOTAL_RECOURS_OCCUPANT_TTC best8.;
        informat TOTAL_RECOURS_PNO_CNP_TTC best8.;
        informat TOTAL_RECOURS_IMMEUBLE_TTC best8.;

        format ID_MSG best12.;
        format ASSU_CALCUL_STATS $8.;
        format DATE_REC date9.;
        format NAT_SINISTRE $2.;
        format SOURCE $1.;
        format EXPERT $55.;
        format REF_EXPERT $12.;
        format MAIL_EXPERT $50.;
        format RAISON_SOCIALE $30.;
        format NUM_DOC $2.;
        format NUM_DOSS_DARVA $12.;
        format DTOM date9.;
        format DT_VISITEXP date9.;
        format DTENVREC date9.;
        format TYP_EXP $1.;
        format ASSUREUR_GEST $30.;
        format CODE_GTA $3.;
        format ASSU_ACPR $10.;
        format NUMORDREMISS $11.;
        format SIN $17.;
        format NUM_CONTRAT $17.;
        format CP_ASSURE $5.;
        format VILLE_ASSURE $50.;
        format QUALASSUR $2.;
        format USAGE $2.;
        format CP_SINISTRE $5.;
        format VILLE_SINISTRE $50.;
        format DATE_SINISTRE date9.;
        format HEURE_SINISTRE best8.;
        format REPETITIF $1.;
        format IMMAT_IMMEUBLE $20.;
        format STATUT_IMMEUBLE $2.;
        format TOTAL_ASSIETTE_DU_LOCAL_HT best8.;
        format TOTAL_RECOURS_PO_TTC best8.;
        format TOTAL_RECOURS_OCCUPANT_TTC best8.;
        format TOTAL_RECOURS_PNO_CNP_TTC best8.;
        format TOTAL_RECOURS_IMMEUBLE_TTC best8.;

        input
            ID_MSG
            ASSU_CALCUL_STATS $
            DATE_REC
            NAT_SINISTRE $
            SOURCE $
            EXPERT $
            REF_EXPERT $
            MAIL_EXPERT $
            RAISON_SOCIALE $
            NUM_DOC $
            NUM_DOSS_DARVA $
            DTOM
            DT_VISITEXP
            DTENVREC
            TYP_EXP $
            ASSUREUR_GEST $
            CODE_GTA $
            ASSU_ACPR $
            NUMORDREMISS $
            SIN $
            NUM_CONTRAT $
            CP_ASSURE $
            VILLE_ASSURE $
            QUALASSUR $
            USAGE $
            CP_SINISTRE $
            VILLE_SINISTRE $
            DATE_SINISTRE
            HEURE_SINISTRE
            REPETITIF $
            IMMAT_IMMEUBLE $
            STATUT_IMMEUBLE $
            TOTAL_ASSIETTE_DU_LOCAL_HT
            TOTAL_RECOURS_PO_TTC
            TOTAL_RECOURS_OCCUPANT_TTC
            TOTAL_RECOURS_PNO_CNP_TTC
            TOTAL_RECOURS_IMMEUBLE_TTC
        ;
        if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
        run;



	data IRSI_SINISTRE_&i_format.20&j. (drop= DATE_REC DTOM DT_VISITEXP DTENVREC DATE_SINISTRE);
	set IRSI_SINISTRE_&i_format.20&j.;

	format DATE_REC2 DTOM2 DT_VISITEXP2 DTENVREC2 DATE_SINISTRE2 ddmmyy10.;

	DATE_REC2 = DATE_REC;
	DTOM2 =DTOM;
	DT_VISITEXP2 =DT_VISITEXP;
	DTENVREC2 =DTENVREC;
	DATE_SINISTRE2 =DATE_SINISTRE;
	run;

    %End;
	%end;
%Mend SINISTREDARVA;
%SINISTREDARVA

/* CAUSE DU SINISTRE */

%Macro CAUSEDARVA;
    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;

	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

	data IRSI_CAUSE_&i_format.20&j.   ;
	%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
	 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_CAUSE_A20&j.M&i_format..csv"
	 delimiter = ';'
	   missover dsd firstobs=2 ;


	   informat ID_MSG best12. ;
	   informat ASSU_CALCUL_STATS $8. ;
	   informat CAUSE_MULTIPLE $2. ;
	   informat CAS_DE_BAREME $2. ;
	   informat CAUSE_BAREME $2. ;
	   informat CAUSE_SINISTRE $2. ;
	   informat CAUSE_SUPPRIMEE $1. ;
	   informat RECHERCHE_FUITE $1. ;
	   
	   
	                                                                         
	   format ID_MSG best12. ;
	   format ASSU_CALCUL_STATS $8. ;
	   format CAUSE_MULTIPLE $2. ;
	   format CAS_DE_BAREME $2. ;
	   format CAUSE_BAREME $2. ;
	   format CAUSE_SINISTRE $2. ;
	   format CAUSE_SUPPRIMEE $1. ;
	   format RECHERCHE_FUITE $1. ;
	   
	input
	            ID_MSG
	            ASSU_CALCUL_STATS $
	            CAUSE_MULTIPLE $
	            CAS_DE_BAREME $
	            CAUSE_BAREME $
	            CAUSE_SINISTRE $
	            CAUSE_SUPPRIMEE $
	            RECHERCHE_FUITE $
	           
	;
	if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
	run;



	proc sql;
			create table IRSI_CAUSE_&i_format.20&j.0 as 
					select a.ID_MSG,
						  a.CAUSE_MULTIPLE,
						  a1.Libelles as casbareme,
						  a2.Libelles as causebareme,
						  a3.libelles as cause_sinistre,
						  a4.libelles as CAUSE_SUPPRIMEE,
						  a.RECHERCHE_FUITE
					from IRSI_CAUSE_&i_format.20&j. as a

					 left join REF.REF_BAREME as a1
					  on a.CAS_DE_BAREME = a1.codes
					left join REF.REF_CAUSEBAREME as a2
					  on a.CAUSE_BAREME = a2.codes
					  left join REF.REF_TYPRISQ as a3
					  on a.CAUSE_SINISTRE = a3.codes
					left join ref.REF_CAUSSUPP as a4
						on a.CAUSE_SUPPRIMEE = a4.codes
	;
	quit;



	proc sort data =IRSI_CAUSE_&i_format.20&j.0;
	by ID_MSG CAUSE_MULTIPLE   RECHERCHE_FUITE;
	run;

	data IRSI_CAUSE_&i_format.20&j.1;
	set IRSI_CAUSE_&i_format.20&j.0;
	by ID_MSG  CAUSE_MULTIPLE   RECHERCHE_FUITE;
	retain Nb;
	if first.ID_MSG then nb = 1;
	else nb = nb+1;
	run;


	proc transpose data = IRSI_CAUSE_&i_format.20&j.1 
				    out = IRSI_CAUSE_&i_format.20&j.2 
	 ;
	by ID_MSG CAUSE_MULTIPLE RECHERCHE_FUITE Nb  ;
	var    casbareme  causebareme CAUSE_SINISTRE CAUSE_SUPPRIMEE  ;

	run;

	proc transpose data =  IRSI_CAUSE_&i_format.20&j.2
				delimiter = _
	 				out = IRSI_CAUSE_&i_format.20&j.3 (drop=_name_)
	;

	by ID_MSG  CAUSE_MULTIPLE RECHERCHE_FUITE;
	var  col1;
	id _name_ Nb;
	run;

	/* on sait combien de maxi causes supprim�es nous avons dans les fichiers*/
	/* Mettre en commentaire � l'�tape 3 sur les variables des causes supprim�es qui ne sont pas pr�sentes dans le fichier source*/
	proc sort  data = IRSI_CAUSE_&i_format.20&j.3 nodupkey out=ssdd dupout=dd;
	by ID_MSG;
	run;

	%end;
	%end;
%Mend CAUSEDARVA;
%CAUSEDARVA




/* DOMMAGE IMMATERIEL PAR PARTIE */

%Macro DOMIMMAT;
    %Do i=&mois_deb. %To &mois_fin.;
		%DO j= &an0. %to &annee_vis.;

	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		data IRSI_DOM_IMMA_&i_format.20&j. ;
		%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
		 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_DOM_IMMA_A20&j.M&i_format..csv"
		 delimiter = ';'
		   missover dsd lrecl=32767 firstobs=2 ;

		    informat ID_MSG best12. ;
		    informat ID_PARTIE best12. ;
		    informat ASSU_CALCUL_STATS $8. ;
		    informat NAT_DOMMAGE_IMMAT $2. ;
		    informat TAUX_TVA_IMMAT best4. ;
		    informat MT_HT_DOMIMMAT best12. ;
		    informat MT_TTC_DOMIMMAT best32. ;
		    format ID_MSG best12. ;
		    format ID_PARTIE best12. ;
		    format ASSU_CALCUL_STATS $8. ;
		    format NAT_DOMMAGE_IMMAT $2. ;
		    format TAUX_TVA_IMMAT best4. ;
		    format MT_HT_DOMIMMAT best12. ;
		    format MT_TTC_DOMIMMAT best12. ;
		 input
		             ID_MSG
		             ID_PARTIE
		             ASSU_CALCUL_STATS $
		             NAT_DOMMAGE_IMMAT $
		             TAUX_TVA_IMMAT
		             MT_HT_DOMIMMAT
		             MT_TTC_DOMIMMAT

		           
		;
		if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
		run;

	%end;
	%end;
%Mend DOMIMMAT;
%DOMIMMAT

/* DOMMAGE MATERIEL PAR PARTIE */
%Macro DOMMAT;
    %Do i=&mois_deb. %To &mois_fin.;
		%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		data IRSI_DOM_MAT_&i_format.20&j.  ;
		%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
		 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_DOM_MAT_A20&j.M&i_format..csv"
		 delimiter = ';'
		   missover dsd lrecl=32767 firstobs=2 ;

		    informat ID_MSG best12. ;
		    informat ID_PARTIE best12. ;
			informat ID_PREJMAT best12.;
		    informat ASSU_CALCUL_STATS $8. ;
		    informat NATURE_DOMMAGE_MAT $2. ;
		    informat TAUX_TVA_MAT best4. ;
		    informat VAN_HT_DOMMAT best12. ;
		    informat VAN_TTC_DOMMAT best32. ;
			informat VD_HT_DOMMAT best12. ;
		    informat VD_TTC_DOMMAT best32. ;


		    format ID_MSG best12. ;
		    format ID_PARTIE best12. ;
			format ID_PREJMAT best12.;
		    format ASSU_CALCUL_STATS $8. ;
		    format NATURE_DOMMAGE_MAT $2. ;
		    format TAUX_TVA_MAT best4. ;
		    format VAN_HT_DOMMAT best12. ;
		    format VAN_TTC_DOMMAT best12. ;
			format VD_HT_DOMMAT best12. ;
		    format VD_TTC_DOMMAT best12. ;

		 input
		              ID_MSG
					  ID_PARTIE
					  ID_PREJMAT
					  ASSU_CALCUL_STATS $
					  NATURE_DOMMAGE_MAT $
					  TAUX_TVA_MAT
					  VAN_HT_DOMMAT
					  VAN_TTC_DOMMAT
					  VD_HT_DOMMAT
		              VD_TTC_DOMMAT
		;
		if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
		run;

	%end;
	%end;
%mend DOMMAT;
%DOMMAT


/* FRAIS AFFERENT LIE AUX DOM MAT PAR PARTIE */

%Macro FRAIS;
    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		data IRSI_FRAIS_AF_&i_format.20&j.  ;
		%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
		 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_FRAIS_AF_A20&j.M&i_format..csv"
		 delimiter = ';'
		   missover dsd lrecl=32767 firstobs=2 ;

		    informat ID_MSG best12. ;
		    informat ID_PARTIE best12. ;
			informat ID_PREJMAT best12.;
		    informat ASSU_CALCUL_STATS $8. ;
		    informat NATURE_FRAIS_AFFERENTS $2. ;
		    informat TAUX_TVA_FRAI best4. ;
		    informat VAN_HT_FRAI best12. ;
		    informat VAN_TTC_FRAI best32. ;

		    format ID_MSG best12. ;
		    format ID_PARTIE best12. ;
			format ID_PREJMAT best12.;
		    format ASSU_CALCUL_STATS $8. ;
		    format NATURE_FRAIS_AFFERENTS $2. ;
		    format TAUX_TVA_FRAI best4. ;
		    format VAN_HT_FRAI best12. ;

		 input
		              ID_MSG
					  ID_PARTIE
					  ID_PREJMAT
					  ASSU_CALCUL_STATS $
					  NATURE_FRAIS_AFFERENTS $
					  TAUX_TVA_FRAI
					  VAN_HT_FRAI
					  VAN_TTC_FRAI
					  
		;
		if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
		run;

	%end;
	%end;
%mend FRAIS;
%FRAIS

/* INFORMATIONS SUR LES PARTIES */


%Macro PARTIE;
    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		data IRSI_PARTIE_&i_format.20&j.  ;
		%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
		 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_PARTIE_A20&j.M&i_format..csv"
		 delimiter = ';'
		   missover dsd lrecl=32767 firstobs=2 ;
		 informat ID_MSG best12. ;
		   informat ID_PARTIE best12. ;
		   informat ASSU_CALCUL_STATS $8. ;
		   informat QUALITE_PARTIE $2. ;
		   informat NOM_PARTIE $50. ;
		   informat ADRESSE $55. ;
		   informat CP_PARTIE $5. ;
		   informat VILLE_PARTIE $50. ;
		   informat GTA_PARTIE $3. ;
		   informat NUM_CONTRAT $15. ;
		   informat SIN_PARTIE $11. ;
		   informat LRAR $1. ;
		   informat PRESENCE_PARTIE $1. ;
		   informat LESE_AUTEUR $2. ;
		   informat ASSUJETTI_TVA best12. ;
		   informat ACCORD_OCCUPANT $1. ;
		   informat ACCORD_NON_OCCUPANT $1. ;
		   informat ACCORD $1.;
		   
		                                                                         
		   format ID_MSG best12. ;
		   format ID_PARTIE best12. ;
		   format ASSU_CALCUL_STATS $8. ;
		   format QUALITE_PARTIE $2. ;
		   format NOM_PARTIE $50. ;
		   format ADRESSE $55. ;
		   format CP_PARTIE $5. ;
		   format VILLE_PARTIE $50. ;
		   format GTA_PARTIE $3. ;
		   format NUM_CONTRAT $15. ;
		   format SIN_PARTIE $11. ;
		   format LRAR $1. ;
		   format PRESENCE_PARTIE $1. ;
		   format LESE_AUTEUR $2. ;
		   format ASSUJETTI_TVA best12. ;
		   format ACCORD_OCCUPANT $1. ;
		   format ACCORD_NON_OCCUPANT $1. ;
		   format ACCORD $1. ;
		input
		            ID_MSG
		            ID_PARTIE
		            ASSU_CALCUL_STATS $
		            QUALITE_PARTIE $
		            NOM_PARTIE $
		            ADRESSE $
		            CP_PARTIE $
		            VILLE_PARTIE $
		            GTA_PARTIE $
		            NUM_CONTRAT $
		            SIN_PARTIE $
		            LRAR $
		            PRESENCE_PARTIE $
		            LESE_AUTEUR $
		            ASSUJETTI_TVA
		            ACCORD_OCCUPANT $
		            ACCORD_NON_OCCUPANT $
		            ACCORD $
		;
		if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
		run;

		proc sql;
				create table IRSI_PARTIE_&i_format.20&j.0 as 
						select a.ID_MSG,
							   a.ID_PARTIE,
							   a1.sin,
							   a.LRAR,
							   case when a.GTA_PARTIE = "" AND A.SIN_PARTIE = "" 
										and a.NUM_CONTRAT = "" then "ASSURE"
							   else "TIERS" end as IDENTIFICATION_PARTIE,					   
							   a.PRESENCE_PARTIE,
							   a.ASSUJETTI_TVA,
							   a.ACCORD_OCCUPANT,
							   a.ACCORD_NON_OCCUPANT,
							   a.ACCORD,
							   case when a.QUALITE_PARTIE in ("01","06","99") then b1.Libelles 
							   else b3.Libelles end as QUALITE_PARTIE,
							   b2.libelles  as LESE_AUTEUR,
							   d1.Libelles as DOM_IMMAT,
							   d.MT_HT_DOMIMMAT,
							   d.MT_TTC_DOMIMMAT,
							   e1.Libelles as DOM_MAT,
							   e.VAN_HT_DOMMAT,
							   e.VAN_TTC_DOMMAT,
							   e.VD_HT_DOMMAT,
							   e.VD_TTC_DOMMAT,
							   f1.libelles as frais,
							   f.VAN_HT_FRAI,
							   f.VAN_TTC_FRAI

						from IRSI_PARTIE_&i_format.20&j. as a
						inner join IRSI_SINISTRE_&i_format.20&j. as a1
							on a.ID_MSG = a1.ID_MSG

						left join REF.REF_QUALLESE as b1
						  on a.QUALITE_PARTIE = b1.Codes 
						left join REF.REF_TYPELESE as b2
						  on a.LESE_AUTEUR = b2.Codes
						left join REF.REF_QUALASSUR as b3
						  on a.QUALITE_PARTIE = b3.Codes 

						left join IRSI_DOM_IMMA_&i_format.20&j. as d
						 	on a.ID_MSG = d.ID_MSG and a.ID_PARTIE = d.ID_PARTIE
						left join REF.REF_NATUREPREJUDICE as d1
						 	on d.NAT_DOMMAGE_IMMAT = d1.Codes
						
						/* Ajout des donn�es sur l'�valuation des dommages mat�riels du local de notre assur� */
						left join IRSI_DOM_MAT_&i_format.20&j. as e
						 on a.ID_MSG = e.ID_MSG and a.ID_PARTIE = e.ID_PARTIE
						left join REF.REF_NATUREDOM as e1
						 	on e.NATURE_DOMMAGE_MAT = e1.Codes

					    /* Ajout des donn�es sur l'�valuation des frais aff�rents du local de notre assur� */
						left join IRSI_FRAIS_AF_&i_format.20&j. as f
						on a.ID_MSG = f.ID_MSG and a.ID_PARTIE = f.ID_PARTIE and e.ID_PREJMAT=f.ID_PREJMAT
						left join  REF.REF_FRAISAFFERENT as f1
							on f.NATURE_FRAIS_AFFERENTS = f1.codes
						where a1.ASSUREUR_GEST = "PACIFICA"
		;
		quit;

	%end;
	%end;
%mend PARTIE;
%PARTIE

/* -------------------------------------------------------------------------------- */
/* ETAPE 2 : Consolidation des donnees REC en une seule table						*/
/* -------------------------------------------------------------------------------- */

%Macro CONSOLIDATION;
    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i. < 10 %then %let i_format = 0&i.;
        		%else %let i_format = &i.;

		proc sql;

				create table temp2.DONNEES_REC_&i_format.20&j. as 
					select    case when month (a.DATE_REC2) in (4,6,9,11) then mdy(month (a.DATE_REC2),30,20&j.)	
								   when month (a.DATE_REC2) = 2 and 20&j. ne 2020	then mdy(month (a.DATE_REC2),28,20&j.)
								   when month (a.DATE_REC2) = 2 and 20&j. = 2020	then mdy(month (a.DATE_REC2),29,20&j.)
							  else mdy(month (a.DATE_REC2),31,20&j.)
							  end as DTREF 										length = 4 format ddmmyy10.,
							  a.sin,
							  a.NUM_CONTRAT  as contrat,
							  a.ID_MSG,
							  a.DATE_REC2 as DT_REC format ddmmyy10.,
							  a.DTOM2 as DTOM format ddmmyy10. ,
							  a.DT_VISITEXP2 as DT_VISITEXP format ddmmyy10. ,
							  a.DTENVREC2 as DTENVREC format ddmmyy10.,
							  a3.Libelles as NATSIN,
							  a1.Libelles as type_expertise,
							  a2.libelles as QUALASSUR,
							  a4.Libelles as USAGE,
							  a.NUMORDREMISS,
							  a.CP_SINISTRE,
							  a.REPETITIF,
							  a.ASSUREUR_GEST,
							  a5.Libelles as TYP_IMMEUBLE,
							  a.TOTAL_ASSIETTE_DU_LOCAL_HT as ASSIETTE_TOTAL_HT,
							  a.TOTAL_RECOURS_PO_TTC,
							  a.TOTAL_RECOURS_OCCUPANT_TTC,
							  a.TOTAL_RECOURS_PNO_CNP_TTC,
							  a.TOTAL_RECOURS_IMMEUBLE_TTC,
							  c.*,
							  b.id_partie,
							  b.QUALITE_PARTIE,
							  b.IDENTIFICATION_PARTIE,
							  b.LRAR,
							  case when b.PRESENCE_PARTIE = "N" then "Personne pr�sente"
							  else "Non pr�sente" end as PRESENCE,
							  b.LESE_AUTEUR,
							  case when b.ACCORD_OCCUPANT="1" then "Non retourn�e"
							  when b.ACCORD_OCCUPANT="2" then "Refus" 
							  when b.ACCORD_OCCUPANT="3" then "Acceptation des dommages"
							  else "" end as ACCORD_OCCUPANT format $30.,
							  case when b.ACCORD_NON_OCCUPANT="1" then "Non retourn�e"
							  when b.ACCORD_NON_OCCUPANT="2" then "Refus" 
							  when b.ACCORD_NON_OCCUPANT="3" then "Acceptation des dommages"
							  else "" end as ACCORD_NON_OCCUPANT format $30.,
							  case when b.ACCORD="1" then "Non retourn�e"
							  when b.ACCORD="2" then "Refus" 
							  when b.ACCORD="3" then "Acceptation des dommages"
							  else "" end as ACCORD format $30.,					  				  
							  b.DOM_IMMAT,
							  b.MT_HT_DOMIMMAT,
							  b.MT_TTC_DOMIMMAT,
							  b.DOM_MAT,
							  b.VAN_HT_DOMMAT,
							  b.VAN_TTC_DOMMAT,
							  b.VD_HT_DOMMAT,
							  b.VD_TTC_DOMMAT,
							  b.frais,
							  b.VAN_HT_FRAI,
							  b.VAN_TTC_FRAI



						from IRSI_SINISTRE_&i_format.20&j. as a

						/* Ajout des informations sur les donn�es principale du l�s� PACIFICA */
						left join REF.REF_TYPEXP as a1
							on a.TYP_EXP = a1.codes
						left join REF.REF_QUALASSUR as a2
							on a.QUALASSUR = a2.Codes
						left join REF.REF_NATSIN as a3
							on a.NAT_SINISTRE = a3.codes
						left join REF.REF_USAGERIS as a4
							on a.USAGE = a4.codes
						left join REF.REF_STATUT_IMMEUBLE as a5
							on a.STATUT_IMMEUBLE = a5.codes
						
						/* Ajout d'information sur les parties concern�es par le sinistre : notre assur� et les tiers */	
						left join IRSI_PARTIE_&i_format.20&j.0  as b
						 on a.ID_MSG = b.ID_MSG
						
					
						/* ajout de l'information sur les causes du sinistre */
						left join IRSI_CAUSE_&i_format.20&j.3 as c
						  on a.ID_MSG = c.ID_MSG 
						  where a.ASSUREUR_GEST = "PACIFICA"

		;
		quit;
	%end;
	%end;
%mend CONSOLIDATION;
%CONSOLIDATION

/* -------------------------------------------------------------------------------- */
/* ETAPE 3: Rapprochement avec les donn�es sinistres de  l'�tape 2				    */
/* -------------------------------------------------------------------------------- */
/* retravaillent des informations des REC pour avoir 1 ligne par dtref et ID_MSG    */
/* -------------------------------------------------------------------------------- */

/* --------------------------------------- */
/* DONNEES GENERALES ASSIETTE PROTOCOLAIRE */
/* --------------------------------------- */
/* ces informations sont uniques par rapport => suppression des doublons li�es aux lignes de d�tails des dommages et pr�judices par partie
 et des rapports extraits sur 2 mois car � cheval entre extraction de 2 mois cons�cutifs */

/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/

%Macro GENERAL1;
    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;	

		proc sort data=temp2.DONNEES_REC_&i_format.20&j. nodupkey out= sansdd_&i_format.20&j. dupout= doublons0;
		by _all_;
		run;

		proc sql noprint;
		    /* Permet de trouver la variable qui commence par CAUSE_SUPPRIMEE_ la plus �lev� du dataset SANSDD */
		    select name into :stop_var
		    from sashelp.vcolumn
		    where libname="WORK" and memname="SANSDD_&i_format.20&j." and name like "CAUSE_SUPPRIMEE_%"
		    order by input(scan(name, -1, "_"), 8.) desc;
		quit;

		%put &stop_var;

		proc sql noprint;
		    /* � l"aide de la librairie SASHELP VCOLUMN on r�cup�re la position de cette variable */
		    select varnum into :stop_varnum
		    from sashelp.vcolumn
		    where libname="WORK" and memname="SANSDD_&i_format.20&j." and name = "&stop_var";

		    /* Et enfin on prend toutes les variables pr�sentes avant cette variable comprise */
		    select name into :keepvars separated by " "
		    from sashelp.vcolumn
		    where libname="WORK" and memname="SANSDD_&i_format.20&j." and varnum <= &stop_varnum;
		quit;

		%put &stop_varnum;
		%put &keepvars;

		proc sort data = sansdd_&i_format.20&j. (keep = &keepvars) nodupkey/* A modifier */
		   out = GENERAL_IRSI_&i_format.20&j.;
			by _all_;
		run;

		proc sort data= general_irsi_&i_format.20&j. ;
		by id_msg descending dt_rec;
		run;

		data general_irsi_&i_format.20&j.1;
		set general_irsi_&i_format.20&j. ;
		by id_msg descending dt_rec;
		if first.id_msg ;
		run;

		/* --------------------------------------- */
		/* DONNEES GENERALES PARTIES ASSURE		   */
		/* --------------------------------------- */

		proc sort data = sansdd_&i_format.20&j. (keep = DTREF ID_MSG id_partie dt_rec QUALITE_PARTIE IDENTIFICATION_PARTIE   
										LRAR PRESENCE LESE_AUTEUR ACCORD_OCCUPANT ACCORD_NON_OCCUPANT ACCORD
						 	            DOM_MAT VAN_HT_DOMMAT VAN_TTC_DOMMAT VD_HT_DOMMAT VD_TTC_DOMMAT 
										frais VAN_HT_FRAI VAN_TTC_FRAI 
										DOM_IMMAT MT_HT_DOMIMMAT MT_TTC_DOMIMMAT) nodupkey
				   out = PARTIE_IRSI_&i_format.20&j. dupout= doublons2;

		by _all_;
		run;

		proc sort data=PARTIE_IRSI_&i_format.20&j. ;
		by id_msg id_partie descending dt_rec;
		run;

	%end;
	%end;
%mend GENERAL1;
%GENERAL1


/* --------------------------------------- */
/* DONNEES DOMMAGES IMMAT 				   */
/* --------------------------------------- */

%Macro GENERAL2;

    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;	


		proc sort data = PARTIE_IRSI_&i_format.20&j. (keep = DTREF ID_MSG dt_rec ID_PARTIE DOM_IMMAT MT_HT_DOMIMMAT MT_TTC_DOMIMMAT 
									 where = (DOM_IMMAT ne "")) nodupkey
		out = PARTIE_IRSI_&i_format.20&j.a;
		by  _all_;
		run;

		proc sort data=PARTIE_IRSI_&i_format.20&j.a;
		by  ID_MSG ID_PARTIE DOM_IMMAT ;
		data PARTIE_IRSI_&i_format.20&j.a1 (drop=MT_HT_DOMIMMAT MT_TTC_DOMIMMAT);
		set PARTIE_IRSI_&i_format.20&j.a;
		by  ID_MSG ID_PARTIE DOM_IMMAT ;
		retain nb;

		if first.ID_PARTIE then nb = 1;
		else NB = NB+1;
			 if DOM_IMMAT = "Les frais de garde-meubles" then do;
			 													MTHT_GARDEMEUBLE = MT_HT_DOMIMMAT ;
							   									MTTTC_GARDEMEUBLE=MT_TTC_DOMIMMAT;
															  end;
		else if DOM_IMMAT = "Les frais de relogement" then do;
		 													MTHT_RELOGEMENT = MT_HT_DOMIMMAT ;
						   									MTTTC_RELOGEMENT=MT_TTC_DOMIMMAT;
														   end;
		else if DOM_IMMAT = "La perte d�usage des locaux" then do;
				 												MTHT_PERTEUSAGELOC  = MT_HT_DOMIMMAT ;
								   								MTTTC_PERTEUSAGELOC = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "La perte de loyers"		 then do;
				 												MTHT_PERTELOYER  = MT_HT_DOMIMMAT ;
								   								MTTTC_PERTELOYER = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "Les frais d�huissier"		 then do;
				 												MTHT_HUISSIER  = MT_HT_DOMIMMAT ;
								   								MTTTC_HUISSIER = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "Les frais de reconstitution d�archives" then do;
							 												MTHT_ARCHIVES  = MT_HT_DOMIMMAT ;
											   								MTTTC_ARCHIVES = MT_TTC_DOMIMMAT;
																		   end;				   			  
		else if DOM_IMMAT = "Les pertes d�exploitation"	 then do;
				 												MTHT_PERTEEXPLOIT  = MT_HT_DOMIMMAT ;
								   								MTTTC_PERTEEXPLOIT = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "Les frais de gardiennage"	 then do;
				 												MTHT_GARDIENNAGE  = MT_HT_DOMIMMAT ;
								   								MTTTC_GARDIENNAGE = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "Les honoraires de ma�trise d��uvre"	 then do;
							 												MTHT_HONOMOE  = MT_HT_DOMIMMAT ;
											   								MTTTC_HONOMOE = MT_TTC_DOMIMMAT;
																		   end;

		else if DOM_IMMAT = "Autres"	 then do;
							 					MTHT_IMATAUT  = MT_HT_DOMIMMAT ;
												MTTTC_IMATAUT = MT_TTC_DOMIMMAT;
											   end;
											  
		run;

		proc transpose data = PARTIE_IRSI_&i_format.20&j.a1 
					    out = PARTIE_IRSI_&i_format.20&j.a2  
		 ;
		by ID_MSG ID_PARTIE  nb ;
		var   MTHT_GARDEMEUBLE MTTTC_GARDEMEUBLE MTHT_RELOGEMENT MTTTC_RELOGEMENT MTHT_PERTEUSAGELOC MTTTC_PERTEUSAGELOC 
			  MTHT_PERTELOYER MTTTC_PERTELOYER MTHT_HUISSIER MTTTC_HUISSIER MTHT_ARCHIVES MTTTC_ARCHIVES 
			  MTHT_PERTEEXPLOIT MTTTC_PERTEEXPLOIT MTHT_HONOMOE MTTTC_HONOMOE MTHT_IMATAUT MTTTC_IMATAUT ;

		run;

		proc sql;
			create table PARTIE_IRSI_&i_format.20&j.a2b as 
						select ID_MSG,
							   ID_PARTIE,
							   _NAME_,
							   sum(col1) as col1
					from PARTIE_IRSI_&i_format.20&j.a2
					group by ID_MSG, ID_PARTIE,_NAME_;
		quit;

		proc transpose data =  PARTIE_IRSI_&i_format.20&j.a2b
				
		 				out = PARTIE_IRSI_&i_format.20&j.a3 (drop=_name_)
		;

		by ID_MSG ID_PARTIE ;
		var  col1;
		id _name_ ;
		run;

		proc sort data = PARTIE_IRSI_&i_format.20&j. (keep=DTREF ID_MSG dt_rec ID_PARTIE DOM_MAT VAN_HT_DOMMAT VAN_TTC_DOMMAT VD_HT_DOMMAT
							  			VD_TTC_DOMMAT where=(DOM_MAT ne "")) 
		out = PARTIE_IRSI_&i_format.20&j.b;
		by  _all_;
		run;

		proc sort data=PARTIE_IRSI_&i_format.20&j.b;
		by  ID_MSG ID_PARTIE DOM_MAT ;
		data PARTIE_IRSI_&i_format.20&j.b1;
		set PARTIE_IRSI_&i_format.20&j.b;
		by  ID_MSG ID_PARTIE DOM_MAT ;
		retain nb;

		if first.ID_PARTIE then nb = 1;
		else NB = NB+1;
			if DOM_MAT = "EMBELLISSEMENT" then do;
												 VANHT_EMBELISSEMENT = VAN_HT_DOMMAT;
												 VANTTC_EMBELISSEMENT = VAN_TTC_DOMMAT;
												 VDHT_EMBELISSEMENT = VD_HT_DOMMAT;
												 VDTTC_EMBELISSEMENT = VD_TTC_DOMMAT;
												end;
		else 	if DOM_MAT = "MOBILIER" then do;
												 VANHT_MOBILIER = VAN_HT_DOMMAT;
												 VANTTC_MOBILIER = VAN_TTC_DOMMAT;										 
												 VDHT_MOBILIER = VD_HT_DOMMAT;
												 VDTTC_MOBILIER = VD_TTC_DOMMAT;
												end;
		else 	if DOM_MAT = "RECHERCHE DE FUITE DESTRUCTIVE" then do;
																	 VANHT_FUITEDESTRUC = VAN_HT_DOMMAT ;
																	 VANTTC_FUITEDESTRUC = VAN_TTC_DOMMAT;
																	 VDHT_FUITEDESTRUC = VD_HT_DOMMAT;
																	 VDTTC_FUITEDESTRUC = VD_TTC_DOMMAT;
																	end;
		else 	if DOM_MAT = "RECHERCHE DE FUITE NON DESTRUCTIVE" then do;
																		 VANHT_FUITENODESTRUC = VAN_HT_DOMMAT ;
																		 VANTTC_FUITENODESTRUC = VAN_TTC_DOMMAT;
																		 VDHT_FUITENODESTRUC = VD_HT_DOMMAT;
																		 VDTTC_FUITENODESTRUC = VD_TTC_DOMMAT;
																		end;
		else 	if DOM_MAT = "RECHERCHE DE FUITE PASSAGE EN APPARENT" then do;
																			 VANHT_FUITEAPPARENT = VAN_HT_DOMMAT ;
																			 VANTTC_FUITEAPPARENT = VAN_TTC_DOMMAT;
																			 VDHT_FUITEAPPARENT = VD_HT_DOMMAT;
																			 VDTTC_FUITEAPPARENT = VD_TTC_DOMMAT;
																			end;
		else 	if DOM_MAT = "PARTIES IMMOBILIERE PRIVATIVES" then do;
																	 VANHT_PIP = VAN_HT_DOMMAT ;
																	 VANTTC_PIP = VAN_TTC_DOMMAT;
																	 VDHT_PIP = VD_HT_DOMMAT;
																	 VDTTC_PIP = VD_TTC_DOMMAT;
																	end;
		else 	if DOM_MAT = "PARTIES COMMUNES" then do;
														 VANHT_PARTIECOMMUN = VAN_HT_DOMMAT ;
													 	VANTTC_PARTIECOMMUN = VAN_TTC_DOMMAT;
													 	VDHT_PARTIECOMMUN = VD_HT_DOMMAT;
													 	VDTTC_PARTIECOMMUN = VD_TTC_DOMMAT;
													 end;


		run;


		proc transpose data = PARTIE_IRSI_&i_format.20&j.b1 
					    out = PARTIE_IRSI_&i_format.20&j.b2 
		 ;
		by ID_MSG ID_PARTIE Nb  ;
		var VANHT_EMBELISSEMENT VANTTC_EMBELISSEMENT VDHT_EMBELISSEMENT VDTTC_EMBELISSEMENT
		    VANHT_MOBILIER VANTTC_MOBILIER VDHT_MOBILIER VDTTC_MOBILIER
		    VANHT_FUITEDESTRUC VANTTC_FUITEDESTRUC VDHT_FUITEDESTRUC VDTTC_FUITEDESTRUC
		    VANHT_FUITENODESTRUC VANTTC_FUITENODESTRUC VDHT_FUITENODESTRUC VDTTC_FUITENODESTRUC
			VANHT_FUITEAPPARENT VANTTC_FUITEAPPARENT VDHT_FUITEAPPARENT VDTTC_FUITEAPPARENT
			VANHT_PIP VANTTC_PIP VDHT_PIP VDTTC_PIP
			VANHT_PARTIECOMMUN VANTTC_PARTIECOMMUN VDHT_PARTIECOMMUN VDTTC_PARTIECOMMUN;
		run;

		proc sql;
			create table PARTIE_IRSI_&i_format.20&j.b2b as 
						select distinct ID_MSG,
							   ID_PARTIE,
							   _NAME_,
							   sum(col1) as col1
					from PARTIE_IRSI_&i_format.20&j.b2
					group by ID_MSG, ID_PARTIE,_NAME_;
		quit;

		proc transpose data =  PARTIE_IRSI_&i_format.20&j.b2b
					delimiter=_
		 				out = PARTIE_IRSI_&i_format.20&j.b3 (drop=_name_)
		;

		by ID_MSG ID_PARTIE;
		var  col1;
		id _name_ ;
		run;

		proc sort data=PARTIE_IRSI_&i_format.20&j.b3 nodupkey out=ss dupout=doublo;
		by ID_MSG ID_PARTIE;
		run;

	%end;
	%end;
%mend GENERAL2;
%GENERAL2

/* --------------------------------------- */
/* DONNEES FRAIS AFFERENTS				   */
/* --------------------------------------- */

%Macro GENERAL3;

    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;	

		proc sort data=PARTIE_IRSI_&i_format.20&j. (keep=DTREF ID_MSG ID_PARTIE dt_rec frais VAN_HT_FRAI VAN_TTC_FRAI
							  			 where=(frais ne ""))  
				   out=PARTIE_IRSI_&i_format.20&j.c;
		by  ID_MSG ID_PARTIE  descending dt_rec;
		run;
		data PARTIE_IRSI_&i_format.20&j.c1;
		set PARTIE_IRSI_&i_format.20&j.c;
		by  ID_MSG ID_PARTIE  descending dt_rec;
		retain nb;

		if first.ID_PARTIE then nb = 1;
		else NB = NB+1;
			if frais = "MESURES PROVISOIRES ET CONSERVATOIRES" then do;
																	  VANHT_MESUREPROVCONS = VAN_HT_FRAI;
																	  VANTTC_MESUREPROVCONS = VAN_TTC_FRAI;
																	end;
		else 	if frais = "MESURES DE SAUVETAGE" then do;
														 VANHT_MESURESAUV = VAN_HT_FRAI;
														 VANTTC_MESURESAUV = VAN_TTC_FRAI;					 
														end;
		else 	if frais = "FRAIS DE DEPLACEMENT DES OBJETS MOBILIERS" then do;
																				 VANHT_DEPLACTOBJET = VAN_HT_FRAI ;
																				 VANTTC_DEPLACTOBJET = VAN_TTC_FRAI;
																				end;
		else 	if frais = "FRAIS DE DEMOLITION ET DE DEBLAIEMENT, TRANSPORT DE DECOMBRES, TRAITEMENT DES DECHETS" then do;
																														 	VANHT_DEMOLDEBLAI = VAN_HT_FRAI ;
																														 	VANTTC_DEMOLDEBLAI = VAN_TTC_FRAI;
																														end;
		else 	if frais = "FRAIS DE MISE EN CONFORMITE" then do;
																 VANHT_MISECONFORM = VAN_HT_FRAI ;
															 	VANTTC_MISECONFORM = VAN_TTC_FRAI;
															  end;
		else 	if frais = "FRAIS DES DIAGNOSTICS OBLIGATOIRES LIMITES A LA ZONE SINISTREE" then do;
																									 VANHT_DIAGNOSTIC = VAN_HT_FRAI ;
																									 VANTTC_DIAGNOSTIC = VAN_TTC_FRAI;
																								 end;


		run;

		proc transpose data = PARTIE_IRSI_&i_format.20&j.c1 
					    out = PARTIE_IRSI_&i_format.20&j.c2 
		 ;
		by ID_MSG ID_PARTIE Nb  ;
		var VANHT_MESUREPROVCONS VANTTC_MESUREPROVCONS VANHT_MESURESAUV VANTTC_MESURESAUV
			VANHT_DEPLACTOBJET VANTTC_DEPLACTOBJET VANHT_DEMOLDEBLAI VANTTC_DEMOLDEBLAI
			VANHT_MISECONFORM VANTTC_MISECONFORM VANHT_DIAGNOSTIC VANTTC_DIAGNOSTIC;
		run;

		proc sql;
			create table PARTIE_IRSI_&i_format.20&j.c2b as 
						select distinct ID_MSG,
							   ID_PARTIE,
							   _NAME_,
							   sum(col1) as col1
					from PARTIE_IRSI_&i_format.20&j.c2
					group by ID_MSG, ID_PARTIE,_NAME_;
		quit;

		proc transpose data =  PARTIE_IRSI_&i_format.20&j.c2b
					delimiter=_
		 				out = PARTIE_IRSI_&i_format.20&j.c3 (drop=_name_)
		;

		by ID_MSG ID_PARTIE;
		var  col1;
		id _name_ ;
		run;


		/* --------------------------------------- */
		/* DONNEES DOMMAGES ASSURE				   */
		/* --------------------------------------- */
		data PARTIE_IRSI3_&i_format.20&j.;
		set PARTIE_IRSI_&i_format.20&j. (keep = DTREF ID_MSG dt_rec id_partie IDENTIFICATION_PARTIE QUALITE_PARTIE LRAR 
							    PRESENCE LESE_AUTEUR ACCORD_OCCUPANT ACCORD_NON_OCCUPANT ACCORD
						where=(IDENTIFICATION_PARTIE ="ASSURE"));
		by id_msg id_partie descending dt_rec;
		if first.ID_PARTIE;
		run;

		proc sql;
				create table ASSURE_&i_format.20&j. as 
					select 
						   a.*,
						   b.*,
						   c.*,
						   d.*

					from  PARTIE_IRSI3_&i_format.20&j. as a
					left join PARTIE_IRSI_&i_format.20&j.a3 as b
						on a.id_msg = b.id_msg and a.id_partie = b.id_partie
					left join PARTIE_IRSI_&i_format.20&j.b3 as c
						on a.id_msg = c.id_msg and a.id_partie = c.id_partie
					left join PARTIE_IRSI_&i_format.20&j.c3 as d
						on a.id_msg = d.id_msg and a.id_partie = d.id_partie
				;
		quit;


		/* --------------------------------------- */
		/* DONNEES DOMMAGES IMMAT TIERS			   */
		/* --------------------------------------- */

		data PARTIE_IRSI_&i_format.20&j.4;
		set PARTIE_IRSI_&i_format.20&j. (keep = DTREF ID_MSG dt_rec id_partie IDENTIFICATION_PARTIE QUALITE_PARTIE LRAR 
							    PRESENCE LESE_AUTEUR ACCORD_OCCUPANT ACCORD_NON_OCCUPANT ACCORD
						where=(IDENTIFICATION_PARTIE ="TIERS"));
		by id_msg id_partie descending dt_rec;
		/*retain nb;*/
		if first.ID_PARTIE/* then nb = 1;
		else NB = NB+1*/;
		run;


		proc sql;
				create table IRSI_PARTIE_TIERS_&i_format.20&j. as 
					select 
						   a.*,
						   b.*,
						   c.*,
						   d.*

					from  PARTIE_IRSI_&i_format.20&j.4 as a
					left join PARTIE_IRSI_&i_format.20&j.a3 as b
						on a.id_msg = b.id_msg and a.id_partie = b.id_partie
					left join PARTIE_IRSI_&i_format.20&j.b3 as c
						on a.id_msg = c.id_msg and a.id_partie = c.id_partie
					left join PARTIE_IRSI_&i_format.20&j.c3 as d
						on a.id_msg = d.id_msg and a.id_partie = d.id_partie
				;
		quit;
		proc sort data=IRSI_PARTIE_TIERS_&i_format.20&j.;
		by  ID_MSG ;
		run;

		data PARTIE_IRSI_&i_format.20&j.4b;
		set IRSI_PARTIE_TIERS_&i_format.20&j.;
		by id_msg ;
		retain nb;
		if first.id_msg then nb = 1;
		else NB = NB+1;
		run;

		proc transpose data = PARTIE_IRSI_&i_format.20&j.4b
					   out = PARTIE_IRSI_&i_format.20&j.4c;
		by id_msg nb;
		var /*accord accord_non_occupant accord_occupant lese_auteur lrar */
			MTHT_GARDEMEUBLE MTTTC_GARDEMEUBLE MTHT_RELOGEMENT MTTTC_RELOGEMENT MTHT_PERTEUSAGELOC MTTTC_PERTEUSAGELOC 
			MTHT_PERTELOYER MTTTC_PERTELOYER MTHT_HUISSIER MTTTC_HUISSIER MTHT_ARCHIVES MTTTC_ARCHIVES 
			MTHT_PERTEEXPLOIT MTTTC_PERTEEXPLOIT MTHT_HONOMOE MTTTC_HONOMOE MTHT_IMATAUT MTTTC_IMATAUT 
			VANHT_EMBELISSEMENT VANTTC_EMBELISSEMENT VDHT_EMBELISSEMENT VDTTC_EMBELISSEMENT
		    VANHT_MOBILIER VANTTC_MOBILIER VDHT_MOBILIER VDTTC_MOBILIER
		    VANHT_FUITEDESTRUC VANTTC_FUITEDESTRUC VDHT_FUITEDESTRUC VDTTC_FUITEDESTRUC
		    VANHT_FUITENODESTRUC VANTTC_FUITENODESTRUC VDHT_FUITENODESTRUC VDTTC_FUITENODESTRUC
			VANHT_FUITEAPPARENT VANTTC_FUITEAPPARENT VDHT_FUITEAPPARENT VDTTC_FUITEAPPARENT
			VANHT_PIP VANTTC_PIP VDHT_PIP VDTTC_PIP
			VANHT_PARTIECOMMUN VANTTC_PARTIECOMMUN VDHT_PARTIECOMMUN VDTTC_PARTIECOMMUN;
		run;

		proc transpose data =  PARTIE_IRSI_&i_format.20&j.4c
					delimiter=_
		 				out = PARTIE_IRSI_&i_format.20&j.4d (drop=_name_)
		;

		by ID_MSG ;
		var  col1;
		id _name_ nb;
		run;

		proc transpose data=PARTIE_IRSI_&i_format.20&j.4b
					   out=PARTIE_IRSI_&i_format.20&j.4e;
		by id_msg nb;
		var QUALITE_PARTIE accord accord_non_occupant accord_occupant lese_auteur lrar;
		run;

		proc transpose data =  PARTIE_IRSI_&i_format.20&j.4e
					delimiter=_
		 				out = PARTIE_IRSI_&i_format.20&j.4f (drop=_name_)
		;

		by ID_MSG ;
		var  col1;
		id _name_ nb;
		run;

		data TIERS_&i_format.20&j. ;
		merge PARTIE_IRSI_&i_format.20&j.4f (in=a)
			   PARTIE_IRSI_&i_format.20&j.4d (in=b);
		by ID_MSG;
		if a;
		run;
	
	%end;
	%end;
%mend GENERAL3;
%GENERAL3


/* -------------------------------------------------------------------------------- */
/* ETAPE 4 : SAUVEGARDE DES DONNEES DES REC										    */
/* -------------------------------------------------------------------------------- */
%MACRO FINAL;
    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;	
		proc sql;
				create table  GENERAL_IRSI_&i_format.20&j.3 as 
					select  a.*,
					        b.*,
							c.*

				from general_irsi_&i_format.20&j.1 as a				
				inner join ASSURE_&i_format.20&j. as b
				on a.ID_MSG = b.ID_MSG and a.dtref = b.dtref 
				inner join TIERS_&i_format.20&j. as c
				on a.ID_MSG = c.ID_MSG  ;
		quit;

		proc sort data=GENERAL_IRSI_&i_format.20&j.3 nodupkey out=ssdd2 dupout= doudou;
		by _all_;
		run;

	%end;
	%end;
%MEND FINAL;
%FINAL



/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/


proc freq data=tables.DONNEES_REC;
table dtref;
run;

/*
data DONNEES_REC;
set tables.DONNEES_REC;
if 		dtref="31JAN2026"d then dtref="31JAN2025"d;
else if dtref="28FEB2026"d then dtref="28FEB2025"d;
else if dtref="31MAR2026"d then dtref="31MAR2025"d;
else if dtref="30APR2026"d then dtref="30APR2025"d;
else if dtref="31MAY2026"d then dtref="31MAY2025"d;
else if dtref="30JUN2026"d then dtref="30JUN2025"d;
else if dtref="31JUL2026"d then dtref="31JUL2025"d;
else if dtref="31AUG2026"d then dtref="31AUG2025"d;
else if dtref="30SEP2026"d then dtref="30SEP2025"d;
else if dtref="31OCT2026"d then dtref="31OCT2025"d;
else if dtref="30NOV2026"d then dtref="30NOV2025"d;
else if dtref="31DEC2026"d then dtref="31DEC2025"d;
run;
proc sort nodupkey data=DONNEES_REC;
by _all_;run;


data tables.DONNEES_REC ;
set 
tables.DONNEES_REC_old25
DONNEES_REC;
run;

proc sort nodupkey data=tables.DONNEES_REC ;
by _all_;run;

*/

%MACRO SAUVEGARDE; 
    %Do i=&mois_deb. %To &mois_fin.;
	%DO j= &an0. %to &annee_vis.;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;
		data tables.DONNEES_REC;
		set tables.DONNEES_REC 
			GENERAL_IRSI_&i_format.20&j.3;
		run;
	%end;
	%end;
%MEND SAUVEGARDE;
%SAUVEGARDE

proc sort data= tables.DONNEES_REC; 
by sin   descending dtref;
run;


/* on prend le dernier REC re�u quand il y a plusieurs missions */
data DONNEES_REC;
set tables.DONNEES_REC ;
by sin   descending dtref;

if first.sin;
run;


data controle;
set tables.DONNEES_REC ;
longuersin = length(compress(sin));
run;

proc freq data= tables.DONNEES_REC;
tables dtref /list missing;
run;

proc freq data= controle;
tables longuersin /list missing;
run;

data controle2;
set controle (where=(longuersin ne 10));
run;
/* => ano de saisie de l'expert => pas de correction */
/* -------------------------------------------------------------------------------- */
/* ETAPE 5 : AJOUT DES DONNEES DES REC											    */
/* -------------------------------------------------------------------------------- */
proc sql;
		create table temp.PERIMETRE_IRSI_ETAPE4 as 
			select 	a.*,
				    b.*


			from temp.PERIMETRE_IRSI_ETAPE3 as a /* 132 848 */
			left join DONNEES_REC  as b
				on a.sin = b.sin  and b.sin ne ""
				
		;
quit;

proc sort data=temp.PERIMETRE_IRSI_ETAPE4 nodupkey out=ssdd2 dupout= doudou;
by sin garantie_non_annule gtiesin ;
run;




/* -------------------------------------------------------------------------------- */
/* ETAPE 6 : Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */
proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE4) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";