/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE0_SUVI_IRSI.SAS									      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 11/06/2018												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION:																	  */
/* Afin de suivre l'impact de la convention IRSI qui s'applique sur les sinistres */
/* en habitation (NH, HA,MR),en PRO (MP) et en AGRI (MA) avec la garantie DDE ou  */
/* INC (hors ELEC et INC sinistr�es simultan�ment), nous consruisons un datamart. */
/* Ce dernier contient le p�rim�tre suivant :									  */
/* 			- Sinistres survenus depuis 01/06/2018								  */
/*			- hors les sinistres annul�s										  */
/*			- avec la garantie DDE et/ou INC non annul�							  */
/*			- pour les produits NH, HA, MR, MP, MA								  */
/*			- Aucun sinistre DDE ou INCne sera ouvert en pr�d�claration			  */
/* ------------------------------------------------------------------------------ */
/* MODIFICATIONS:																  */
/* NOV 2018 |		|- apr�s �change avec la DPART, nous ne remontons plus les 	  */
/*					   donn�es qualit� et type de batiment pour les sinistres MA  */
/*					   cette information ne leur est pas utile pour les �vol	  */
/*					   tarifaires. Pour le suivi des sinistres, l'information     */
/*					   n'est pas exploitable.									  */
/*																				  */
/* MARS 2019|		|-optimisation de la r�cup�ration des images contrats +       */
/*					  ajout des contrats MRA et AFIARD avant migration			  */
/*																				  */
/* JANV 2021|		|- Ajout du produit M9									      */
/*																				  */
/* ------------------------------------------------------------------------------ */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));

option nofmterr;
option  compress = yes;

/* -------------------------------------------------------------------------------- */
/* ETAPE 0 : R�cup�ration des r�f�rentiels DARVA								    */
/* -------------------------------------------------------------------------------- */
/* 
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "REF" /!\

PROC IMPORT OUT= REF.BAREME_IRSI 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_BAREME.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="Feuil1";
RUN;

PROC IMPORT OUT= REF.REF_SINISTRES_DARVA 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="SINISTRES";
RUN;
PROC IMPORT OUT= REF.REF_CAUSES_DARVA 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="CAUSES";
RUN;
PROC IMPORT OUT= REF.REF_PARTIES_DARVA 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="PARTIES";
RUN;
PROC IMPORT OUT= REF.REF_TOTAL_DARVA 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="TOTAL";
RUN;
PROC IMPORT OUT= REF.REF_DOMMAT_DARVA 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="DOMMAT";
RUN;
PROC IMPORT OUT= REF.REF_FRAISAFFERENT_DARVA 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="FRAISAFFERENT";
RUN;
PROC IMPORT OUT= REF.REF_PREJIMAT_DARVA 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="PREJIMAT";
RUN;

PROC IMPORT OUT= REF.REF_SINISTRES_DARVA_0718 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA_JUILLET18.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="SINISTRES";
RUN;
PROC IMPORT OUT= REF.REF_CAUSES_DARVA_0718 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA_JUILLET18.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="CAUSES";
RUN;
PROC IMPORT OUT= REF.REF_PARTIES_DARVA_0718 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA_JUILLET18.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="PARTIES";
RUN;
PROC IMPORT OUT= REF.REF_TOTAL_DARVA_0718 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA_JUILLET18.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="TOTAL";
RUN;
PROC IMPORT OUT= REF.REF_DOMMAT_DARVA_0718 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA_JUILLET18.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="DOMMAT";
RUN;
PROC IMPORT OUT= REF.REF_FRAISAFFERENT_DARVA_0718 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA_JUILLET18.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="FRAISAFFERENT";
RUN;
PROC IMPORT OUT= REF.REF_PREJIMAT_DARVA_0718 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_HOMOGENISATION_DONNEES_DARVA_JUILLET18.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="PREJIMAT";
RUN;
*/
/* -------------------------------------------------------------------------------- */
/* ETAPE 3 : Tables de transcodage des modalit�s des donn�es du rapport DARVA	  */
/* -------------------------------------------------------------------------------- */
/*
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "REF" /!\

PROC IMPORT OUT= REF.REF_TYPRISQ
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="TYPRISQ";
RUN;
PROC IMPORT OUT= REF.REF_TYPEXP
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="TYPEXP";
RUN;
PROC IMPORT OUT= REF.REF_USAGERIS
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="USAGERIS";
RUN;
PROC IMPORT OUT= REF.REF_QUALASSUR
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="QUALASSUR";
RUN;
PROC IMPORT OUT= REF.REF_STATUT_IMMEUBLE 
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="STATUT_IMMEUBLE";
RUN;
PROC IMPORT OUT= REF.REF_OUTIL_GENERATEUR
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="OUTIL_GENERATEUR";
RUN;
PROC IMPORT OUT= REF.REF_CAUSSUPP
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="CAUSSUPP";
RUN;
PROC IMPORT OUT= REF.REF_NATSIN
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="NATSIN";
RUN;
PROC IMPORT OUT= REF.REF_CAUSEBAREME
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="CAUSEBAREME";
RUN;
PROC IMPORT OUT= REF.REF_BAREME
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="BAREME";
RUN;
PROC IMPORT OUT= REF.REF_TYPELESE
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="TYPELESE";
RUN;
PROC IMPORT OUT= REF.REF_QUALLESE
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="QUALLESE";
RUN;
PROC IMPORT OUT= REF.REF_ACCOREXP
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="ACCOREXP";
RUN;
PROC IMPORT OUT= REF.REF_NATUREDOM
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="NATUREDOM";
RUN;
PROC IMPORT OUT= REF.REF_FRAISAFFERENT
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="FRAISAFFERENT";
RUN;
PROC IMPORT OUT= REF.REF_NATUREPREJUDICE
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_CODES_DARVA.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="NATUREPREJUDICE";
RUN;*/
/* -------------------------------------------------------------------------------- */
/* ETAPE 4 : Tables de transcodage des modalit�s des donn�es de l'outil DDE		  */
/* -------------------------------------------------------------------------------- */

/*
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "REF" /!\

PROC IMPORT OUT= REF.TYPE_PIECE_OUTIL
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_DDE.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="TYPE_PIECE";
RUN;

PROC IMPORT OUT= REF.TYPE_SURF_OUTIL
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_DDE.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="TYPE_SURF";
RUN;

PROC IMPORT OUT= REF.MATERIAUX_OUTIL
            DATAFILE = "\\bureautique\Pacifica\Dsi\P�le PERFORMANCE\03 - STATISTIQUES\01_SUIVI\02_FREQUENCE_MENSUELLE\15_IRSI\Referentiels\REFERENTIEL_DDE.xlsx" 
            DBMS=xlsx REPLACE ;
			SHEET="MATERIAUX";
RUN;*/

/* -------------------------------------------------------------------------------- */
/* ETAPE 1 : R�cup�ration des images contrats des produits concern�s			 	*/
/* -------------------------------------------------------------------------------- */
/* -------------------- */
/* pour les contrats NH */
/* -------------------- */
%let var_contrat= contrat image qualite habitat sitcont ;
/*
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\
%macro create_list(basename,start,end);
  %local _var;
  %if &end>0 %then %let _var=&basename.&start;
  %do i=&start+1 %to &end;
    %let _var=&_var &basename&i;
  %end;
  &_var
%mend;

%macro create_list_1(basename,basename2,start,end);
  %local _var;
  %if &end>0 %then %let _var=&basename.&start.&basename2.;
  %do i=&start+1 %to &end;
  	%if &i >= 10 %then %let _var=&_var &basename.&i.&basename2.;
    %else    %let _var=&_var &basename.0&i.&basename2.;
  %end;
  &_var
%mend;
*/

data mvtprmh;
		set/* /!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\
			%create_list_1(date12,.mvtprmh(keep=&var_contrat ),start=01,end=&an1) */
			 date&fichier.mvtprmh(keep=&var_contrat.);
			 where sitcont not in ('F',/*'I',*/'J','B','W');
run;

proc sort data=mvtprmh nodupkey
		out=mvtprmh
		
	  ;
	 BY contrat image; 
run;

data temp2.mvtprmh;
set temp2.mvtprmh
    mvtprmh;
run;

proc sort data = temp2.mvtprmh 
		out = temp2.mvtprmh
	 nodupkey ;
	 BY _all_; 
run;

/* 
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\

data mvtprmh_mra;
		set %create_list_1(date12,.mvtprmh_mra(keep=&var_contrat ),start=09,end=11) 
			 ;
			 where sitcont not in ('F',/*'I',*//*'J','B','W');*/
/*run;
proc sort data=mvtprmh_mra nodupkey
		out=temp.mvtprmh_mra
		
	  ;
	 BY contrat image; 
run;

data mvtprmh_af;
set date1208.mvtprmh_AF (keep= contrat image qualite habitat sitcont);
			 where sitcont not in ('F',/*'I',*//*'J','B','W');
run;
proc sort data = mvtprmh_af nodupkey
		   out = temp.mvtprmh_af;
	 BY contrat image; 
run;*/

/* --------------------- */
/* pour les contrats HA */
/* --------------------- */
%let var_contrat= contrat image qualite habitat sitcont;
/*
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\

%macro create_list(basename,start,end);
  %local _var;
  %if &end>0 %then %let _var=&basename.&start;
  %do i=&start+1 %to &end;
    %let _var=&_var &basename&i;
  %end;
  &_var
%mend;

%macro create_list_1(basename,basename2,start,end);
  %local _var;
  %if &end>0 %then %let _var=&basename.&start.&basename2.;
  %do i=&start+1 %to &end;
  	%if &i >= 10 %then %let _var=&_var &basename.&i.&basename2.;
    %else    %let _var=&_var &basename.0&i.&basename2.;
  %end;
  &_var
%mend;*/

data mvtprha;
		set /*
			/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\

			%create_list_1(date12,.mvtprha(keep=&var_contrat),start=01,end=&an1) */
			date&fichier.mvtprha(keep=&var_contrat.);
		where sitcont not in ('F',/*'I',*/'J','B','W');
run;

proc sort data = mvtprha
		out = mvtprha
	 nodupkey ;
	 BY contrat image; 
run;

data temp2.mvtprha;
set temp2.mvtprha
    mvtprha;
run;

proc sort data = temp2.mvtprha
		out = temp2.mvtprha
	 nodupkey ;
	 BY _all_; 
run;

/* --------------------- */
/* pour les contrats MR */
/* --------------------- */

%let var_contrat= contrat sitcont image qualite habitat;
/*
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\

%macro create_list(basename,start,end);
  %local _var;
  %if &end.>0 %then %let _var=&basename.&start;
  %do i=&start.+1 %to &end.;
    %let _var=&_var. &basename&i.;
  %end;
  &_var.
%mend;

%macro create_list_1(basename,basename2,start,end);
  %local _var;
  %if &end.>0 %then %let _var=&basename.&start.&basename2.;
  %do i=&start.+1 %to &end.;
  	%if &i. >= 10 %then %let _var=&_var. &basename.&i.&basename2.;
    %else    %let _var=&_var. &basename.0&i.&basename2.;
  %end;
  &_var.
%mend;*/

data mvtprmr;
		set /*
			/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\
			%create_list_1(date12,.mvtprmr(keep=&var_contrat),start=01,end=&an1) */
			date&fichier.mvtprmr(keep=&var_contrat.);
		where sitcont not in ('F',/*'I',*/'J','B','W');
run;

proc sort data = mvtprmr
		out = mvtprmr
	 nodupkey ;
	 BY contrat image; 
run;

data temp2.mvtprmr;
set temp2.mvtprmr
    mvtprmr;
run;

proc sort data = temp2.mvtprmr
		out = temp2.mvtprmr
	 nodupkey ;
	 BY _all_; 
run;

/* --------------------- */
/* pour les contrats MP */
/* --------------------- */

%let var_contrat= contrat sitcont image qualite TYPBAT;
/*
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\
%macro create_list(basename,start,end);
  %local _var;
  %if &end.>0 %then %let _var=&basename.&start;
  %do i=&start.+1 %to &end.;
    %let _var=&_var &basename&i;
  %end;
  &_var
%mend;

%macro create_list_1(basename,basename2,start,end);
  %local _var;
  %if &end.>0 %then %let _var=&basename.&start.&basename2.;
  %do i=&start.+1 %to &end.;
  	%if &i. >= 10 %then %let _var=&_var &basename.&i.&basename2.;
    %else    %let _var=&_var &basename.0&i.&basename2.;
  %end;
  &_var
%mend;*/

data mvtprmp;
		set/* 
			/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\
			%create_list_1(date12,.mvtprmp(keep=&var_contrat.),start=04,end=&an1.)*/
			date&fichier.mvtprmp(keep=&var_contrat.);
		where sitcont not in ('F',/*'I',*/'J','B','W');
run;
proc sort data= mvtprmp
		out=mvtprmp
	 nodupkey ;
	 BY contrat image; 
run;

data temp2.mvtprmp;
set temp2.mvtprmp
    mvtprmp;
run;

proc sort data= temp2.mvtprmp
		out=temp2.mvtprmp
	 nodupkey ;
	 BY contrat image; 
run;

/* --------------------- */
/* pour les contrats M9 */
/* --------------------- */

%let var_contrat= contrat sitcont image qualite /*TYPBAT*/;
/*
/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\
%macro create_list(basename,start,end);
  %local _var;
  %if &end.>0 %then %let _var=&basename.&start;
  %do i=&start.+1 %to &end.;
    %let _var=&_var &basename&i;
  %end;
  &_var
%mend;

%macro create_list_1(basename,basename2,start,end);
  %local _var;
  %if &end.>0 %then %let _var=&basename.&start.&basename2.;
  %do i=&start.+1 %to &end.;
  	%if &i. >= 10 %then %let _var=&_var &basename.&i.&basename2.;
    %else    %let _var=&_var &basename.0&i.&basename2.;
  %end;
  &_var
%mend;*/

data mvtprm9;
		set/* 
			/!\ A lancer une fois car les tables SAS sont stock�es dans la librairie SAS "TEMP" /!\
			%create_list_1(date12,.mvtprmp(keep=&var_contrat.),start=04,end=&an1.)*/
			date&fichier.mvtprm9(keep=&var_contrat.);
		where sitcont not in ('F',/*'I',*/'J','B','W');
TYPBAT ="";
run;
proc sort data= mvtprm9
		out=mvtprm9
	 nodupkey ;
	 BY contrat image; 
run;

data temp2.mvtprmp;
set temp2.mvtprmp
    mvtprm9;
run;

proc sort data= temp2.mvtprmp
		out=temp2.mvtprmp
	 nodupkey ;
	 BY contrat image; 
run;

/* --------------------- */
/* pour les contrats MA */
/* --------------------- */
/* d�sactiv� le 22/11/2018: donn�e non utile pour la DPART */
/*data mvtprma;
run;/

%macro contratma (start = ,
				  end =);

 			
							proc sql;
										create table mvtprma as 
												select a.contrat,
													   a.image,
													   a.sitcont,
													   b.qualite,
													   b.TYPBAT
												from date&fichier.mvtprma as a
												left join date&fichier.mvtprba as b
												 on a.contrat = b.contrat and a.image = b.image
												where a.sitcont not in ("F","I","J","B","W");
							quit;

							data mvtprma;
							set mvtprma;
							run;
			
%do i = &start. %to &end. %by 1;
			 %if  &i < &end. and  &i >= &start. and %sysfunc (exist (DATE12&i..mvtprma)) = 1 %then %do;
							 proc sql;
										create table mvtprma12&i. as 
												select a.contrat,
													   a.image,
													   a.sitcont,
													   b.qualite,
													   b.TYPBAT
												from date12&i..mvtprma as a
												left join date12&i..mvtprba as b
												 on a.contrat = b.contrat and a.image = b.image
												where a.sitcont not in ("F","I","J","B","W");
							quit;

							data mvtprma;
							set mvtprma 
								mvtprma12&i.;
								
							run;

				%end;
		
%end;

%mend;

%contratma ( start = 17,
			 end = &an0);
proc sort data=mvtprma (where= ( contrat ne ""))
		out=temp.mvtprma
	 nodupkey ;
	 BY _all_; 
run;*/

/* lib�re de l'espace */
proc datasets library = work mentype = all
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE0) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";