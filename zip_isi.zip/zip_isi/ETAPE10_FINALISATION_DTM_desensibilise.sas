/* -------------------------------------------------------------------------------- */
/* NOM DU PROGRAMME : ETAPE10_FINALISATION_DTM.SAS							        */
/*																				    */
/* AUTEUR			: CM														    */
/*																				    */
/* DATE				: 01/08/2018												    */
/*																				    */
/* -------------------------------------------------------------------------------- */
/* DESCRIPTION :																    */
/* R�cup�ration de la date du commentaire IRIS pour calculer de d�lai entre la 		*/ 
/* mission et la r�ception du rapport REC.											*/
/* 																					*/
/* -------------------------------------------------------------------------------- */
/* Modifications :																	*/
/* FEV 2019 |		|- A cette �tape nous corrigeons la donn�e FLAG_IRSI suite 		*/
/* 					   � l'enrichissement du Datamart des diff�rents intervenants   */
/*					   sur le sinistre												*/
/* 																					*/
/* -------------------------------------------------------------------------------- */
/* MODIFICATIONS																    */
/* NOV	2019|	| - changement du chemin pour le r�f�rentiel des experts DARVA	    */
/* JAN  2020|	|- le fait d'avoir ajouter lee Num du message IRSI � g�n�rer des	*/
/*				   doublons sur le message de d�p�t du rapport IRSI => il faut 		*/
/*				   supprimer les doublons											*/
/* -------------------------------------------------------------------------------- */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;
/* -------------------------------------------------------------------------------- */
/* ETAPE 1: R�cup�ration du r�f�rentiel des cabinets d'expert					  */
/* -------------------------------------------------------------------------------- */
proc import datafile = "\\bureautique.ca-pacifica.fr\bureautique\DSIN\POLORGA\EP\02-Productions r�currentes\03-MENS\06-Suivis techniques\02-Documentation\REF_EXPERTS_DARVANA_V2.xlsx"
			out = REF_EXPERT
			dbms = xlsx replace ; 
			sheet = "REF_EXPERT" ; 
run ;

/* -------------------------------------------------------------------------------- */
/* ETAPE 2 : RECUPERATION DES COMMENTAIRES SD99 IRSI  								*/
/* -------------------------------------------------------------------------------- */

%LET annee_vis=25;  
%LET mois_vis=12;

%Macro COMPIL_TABLE;

				Data COMMENTAIRE_IRSI (drop=NOMSG NOLCOMMENT); 
				Set
					%Do i=24 %To &annee_vis.; /* &an. */
							date&mois_vis.&i..sin_suivomt (where =  (TYPECO ='IR'))
					%End;

;
Run;

%Mend COMPIL_TABLE;
%COMPIL_TABLE

/* Nous prenons le dernier commentaire IRSI re�u */
proc sort data=COMMENTAIRE_IRSI;
by sin dtref numordremiss dtrecep;
run;

data COMMENTAIRE_IRSI2;
set COMMENTAIRE_IRSI;
by sin dtref numordremiss dtrecep;
if last.numordremiss;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3 : RECUPERATION REGLEMENTS PARTENAIRES ELEC 								*/
/* -------------------------------------------------------------------------------- */

DATA REG;
SET histo2.archi_SIN_REG;
IF &MOISSEUL. > dtouv >= "01JAN17"d;/* dtsurv non pr�sent dans SIN_REG */
IF DTANN =.;
IF PRODUIT in ("NH","HA","MR");
IF GTIESIN IN ("DDE","INC");
IF TYPEMONT in ("PA" "RE") and modergl not in ('CV' 'CG' 'CS');
IF TYPEMONT = "RE" then MTRGGTIE = -MTRGGTIE;
IF ETATGTIE NOT IN ("A");
IF (REFBENEF IN ("DARTY","BOUL","CLIC","LMK","SUP"));
RUN;

/* On met toutes les garanties et tous les r�glements sur la m�me ligne */

PROC SORT DATA = REG;	
BY SIN GTIESIN REFBENEF dtrg;
RUN;

* 1 ligne par sin/gtiesin;
DATA REG_ELEC_LMK;
	SET REG;
	BY SIN GTIESIN REFBENEF dtrg;
	format GARANTIE $8. MTRELECLMK 16.2 ENTREPRISE $50.;
	RETAIN ENTREPRISE GARANTIE MTRELECLMK;
	IF FIRST.SIN THEN DO;
							  GARANTIE = GTIESIN;
							  MTRELECLMK = MTRGGTIE;
							  ENTREPRISE = REFBENEF;
					  END;
	else do;
		    MTRELECLMK  = MTRELECLMK+MTRGGTIE;
			if index(GARANTIE,GTIESIN) = 0 and GARANTIE ne '' then GARANTIE = trim(GARANTIE)||"/"||GTIESIN;
			else if index(GARANTIE,GTIESIN) > 0 then  GARANTIE = GTIESIN;
		    else GARANTIE = GARANTIE;
			if index(ENTREPRISE,REFBENEF) = 0 and ENTREPRISE ne '' then  ENTREPRISE = trim(ENTREPRISE)||"/"||REFBENEF;
			else if index(ENTREPRISE,REFBENEF) > 0 then  ENTREPRISE = REFBENEF;
		    else ENTREPRISE = ENTREPRISE;
		 END;
	
    IF LAST.SIN;
	keep sin produit GARANTIE etatgtie ENTREPRISE MTRELECLMK DTRG;
RUN;

proc sort data=REG_ELEC_LMK nodupkey out=ssdd dupout=doub;
by sin; 
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 4 : INTEGRATION AU DATAMART IRSI									  	    */
/* -------------------------------------------------------------------------------- */

data PERIMETRE_IRSIFFA9;
set temp.PERIMETRE_IRSIFFA9;
if MTREPNAT = . then MTREPNAT = 0;
else MTREPNAT = MTREPNAT;
if mt_total_cp = . then mt_total_cp = 0;
else mt_total_cp = mt_total_cp;
if mtrg_CI = . then mtrg_CI=0;
else mtrg_CI = mtrg_CI;
if enc_CI = . then enc_CI = 0;
else enc_CI =enc_CI;

MT_REG_DEGAT = mt_total_cp+MTREPNAT;
run;

proc sql;
create table temp.PERIMETRE_IRSIFFA10 as 
select a.*,
	   b.EXPERT as EXPERT_RAPPORT,
	   case when b.expert = c.code_ce then c.expert
	   when b.expert = d.nouv_code_ce  then d.expert
	   else c.expert end as groupe_EXPERTRAPP,
	   b.DATEVISITE,
	   b.DTRECEP,
	   case when e.MTRELECLMK = . then 0
	   else e.MTRELECLMK end as MTRELECLMK2,

	   case when a.BAREME = '951' then "HORS CONVENTIONS"
	   else a.FLAG_IRSI end as FLAG_IRSI2 format $40.,
	   /* Calcul de l'assiette protocolaire pour les non PNO */
	   case when a.qualite not in ("PNO","PRON") then a.MT_REG_DEGAT+calculated MTRELECLMK2 
		else 0 end as MT_NON_PNO,
	   /* Cas g�n�ral */
	   case when a.BAREME = '800' then 'Tranche 2'
	   /* Tous sauf propri�taire non occupants */
	   when a.BAREME in ('901','911') and 0 <=  calculated MT_NON_PNO < 1761 
			and a.qualite not in ("PNO","PRON","")  then 'Tranche 1'
	   when a.BAREME in ('901','911') and 1761 <= calculated MT_NON_PNO  < 5501 
			and a.qualite not in ("PNO","PRON") then 'Tranche 2'
	   when a.BAREME in ('00X','00Y') and a.qualite not in ("PNO","PRON")  then 'Tranche 1'
	   when a.BAREME not in ('00X','00Y','901','911','800','951','') and a.qualite not in ("PNO","PRON")  
			and 0 <= calculated MT_NON_PNO+mtrg_CI < 1761    then 'Tranche 1'
	   when a.BAREME not in ('00X','00Y','901','911','800','951','') and a.qualite not in ("PNO","PRON")  
			and 1761 <= calculated MT_NON_PNO+mtrg_CI < 5501  then 'Tranche 2'
	   /* Uniquement pour les propri�taire non occupants */
	   when a.BAREME in ('901','911') and 0 <= a.RPCORG_GTIESIN < 1761 
			and a.qualite in ("PNO","PRON")  then 'Tranche 1'
	   when a.BAREME in('901','911') and 1761 <= a.RPCORG_GTIESIN < 5501 
			and a.qualite in ("PNO","PRON") then 'Tranche 2'
	   when a.BAREME in ('00X','00Y') and a.qualite in ("PNO","PRON")  then 'Tranche 1'	   
	   when a.BAREME not in ('00X','00Y','901','911','800','951','') and a.qualite  in ("PNO","PRON")  
			and  0 <= a.RPCORG_GTIESIN <1761  then 'Tranche 1'
	   when a.BAREME not in ('00X','00Y','901','911','800','951','') and a.qualite in ("PNO","PRON")  
			and  1761 <= a.RPCORG_GTIESIN <5501  then 'Tranche 2'
		else "" end as Tranche format $9.

from PERIMETRE_IRSIFFA9 as a 
left join COMMENTAIRE_IRSI2 as b 
on a.sin = b.sin and index(a.missionsexpert,b.NUMORDREMISS)
left join REF_EXPERT as c
on b.expert=c.code_ce
left join REF_EXPERT as d
on b.expert=d.nouv_code_ce and d.nouv_code_ce ne ""
left join REG_ELEC_LMK as e
on a.sin = e.sin  
;
quit;

data tables.DM_IRSI_FFA20&an0.;
set temp.PERIMETRE_IRSIFFA10 /*(where=(etatsin ne 'S'))*/;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 4: Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */

proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE10) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";