/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE11_PREM_DER_RGT_PRINC.SAS						      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 27/02/2023												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION:																	  */
/* r�cup�ration de la date du premier et du dernier r�glement en principal faits  */
/* au client ou � un partenaire													  */
/* ------------------------------------------------------------------------------ */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;
/* -------------------------------------------------------------------------------- */
/* ETAPE 1: r�cup�ration des r�glement en principal fait au client ou un partenaire */
/* -------------------------------------------------------------------------------- */

DATA REG;
SET histo2.archi_sin_reg;
IF &MOISSEUL. > dtouv >= "01JAN2017"d;/* dtsurv non pr�sent dans SIN_REG */
IF DTANN =.;
IF PRODUIT in ("NH",/*"MA",*/"HA","MR"/*,"MP"*/);
IF GTIESIN IN ("DDE","INC");
IF TYPEMONT in ("PA") and modergl not in ('CV' 'CG' 'CS');
IF ETATGTIE NOT IN ("A");
IF REFBENEF IN ("MULTI","VIAREN") or (REFBENEF = "SPEB" and dtrg < "01JAN2019"d) or typebenef ='CP' and imputation ='PR';
RUN;

proc sort data=REG;
by sin gtiesin dtrg;
run;

data REG2;
set REG;
by sin gtiesin dtrg;
retain nb;
if first.gtiesin then nb = 1;
else nb= nb+1;
if first.gtiesin or last.gtiesin;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 2: ajout des infos sur le 1er et dernier r�glements 						*/
/* -------------------------------------------------------------------------------- */

proc sql;
create table tables.DM_IRSI_FFA20&an0. as 
select a.*,
	   case when b.nb = 1 then b.dtrg
	   else . end as PREM_RGLT format date7.,
	   case when c.nb not in (.,1) then c.dtrg
	   else . end as DERN_RGLT format date7.

from tables.DM_IRSI_FFA20&an0. as a 
left join REG2 as b 
on a.sin = b.sin and a.gtiesin = b.gtiesin and b.nb=1
left join REG2 as c 
on a.sin = c.sin and a.gtiesin = c.gtiesin and c.nb ne 1;
quit;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3: Lib�ration de l'espace work											    */
/* -------------------------------------------------------------------------------- */

proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE11) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";

