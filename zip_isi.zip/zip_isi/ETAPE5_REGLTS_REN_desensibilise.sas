	/* ------------------------------------------------------------------------------ */
	/* NOM DU PROGRAMME : ETAPE5_REGLTS_REN.SAS									      */
	/*																				  */
	/* AUTEUR			: CM														  */
	/*																				  */
	/* DATE				: 23/02/2023												  */
	/*																				  */
	/* ------------------------------------------------------------------------------ */
	/* DESCRIPTION :																  */
	/* Rajouter les donn�es de placement et de co�t des r�parateurs en nature 		  */ 
	/* 																				  */
	/* ------------------------------------------------------------------------------ */

	%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
	option nofmterr;
	option  compress = yes;

	/* -------------------------------------------------------------------------------- */
	/* ETAPE 1 : INTEGRATION DES REGLEMENTS AUX REPARATEURS EN NATURE				    */
	/* -------------------------------------------------------------------------------- */

	/* que nous utilisions ARCHI_SIn_REG ou DATEMMAA.SIN_REG nous obtenons le m�me r�sultat */
	/* 19/11/2018 : choix de prendre DATEMMAA.SIN_REG gain de temps et m�me r�sultat */ 
	DATA REG;
	SET histo2.archi_sin_reg;
	IF &MOISSEUL. > dtouv >= "01JAN2017"d;/* dtsurv non pr�sent dans SIN_REG */
	IF DTANN =.;
	IF PRODUIT in ("NH",/*"MA",*/"HA","MR"/*,"MP"*/);
	IF GTIESIN IN ("DDE","INC");
	IF TYPEMONT in ("PA" "RE") and modergl not in ('CV' 'CG' 'CS');
	IF TYPEMONT = "RE" then MTRGGTIE = -MTRGGTIE;
	IF ETATGTIE NOT IN ("A");
	IF REFBENEF IN ("MULTI","VIAREN") or (REFBENEF = "SPEB" and dtrg < "01JAN2019"d);
	RUN;

	/* On met toutes les garanties et tous les r�glements sur la m�me ligne */

	PROC SORT DATA = REG;	
	BY SIN GTIESIN REFBENEF dtrg;
	RUN;

	* 1 ligne par sin/gtiesin;
	DATA REG_REN;
		SET REG;
		BY SIN GTIESIN REFBENEF dtrg;
		format GARANTIE $8. MTREPNAT 16.2 REPNAT $50.;
		RETAIN REPNAT GARANTIE MTREPNAT;
		IF FIRST.SIN THEN DO;
								  GARANTIE = GTIESIN;
								  MTREPNAT = MTRGGTIE;
								  REPNAT = REFBENEF;
						  END;
		else do;
			    MTREPNAT  = MTREPNAT+MTRGGTIE;
				if index(GARANTIE,GTIESIN) = 0 and GARANTIE ne '' then GARANTIE = trim(GARANTIE)||"/"||GTIESIN;
				else if index(GARANTIE,GTIESIN) > 0 then  GARANTIE = GTIESIN;
			    else GARANTIE = GARANTIE;
				if index(REPNAT,REFBENEF) = 0 and REPNAT ne '' then  REPNAT = trim(REPNAT)||"/"||REFBENEF;
				else if index(REPNAT,REFBENEF) > 0 then  REPNAT = REFBENEF;
			    else REPNAT = REPNAT;
			 END;
		
	    IF LAST.SIN;
		keep sin produit GARANTIE etatgtie REPNAT MTREPNAT DTRG;
	RUN;

	/* -------------------------------------------------------------------------------- */
	/* ETAPE 2 : INTEGRATION AU DATAMART IRSI										    */
	/* -------------------------------------------------------------------------------- */

	proc sql;
	create table temp.PERIMETRE_IRSIFFA5 as 
	select a.*,
			b.GARANTIE as GARANTIE_REN,
			b.REPNAT,
			b.MTREPNAT,
			b.dtrg as datedernier_RG_REN,
		   case when b.REPNAT ne '' then 'O'
		   else 'N' end as REN

	from temp.PERIMETRE_IRSI_ETAPE4  as a  /* temp.PERIMETRE_IRSIFFA4 ancien nom de table => KO ? */
	left join REG_REN as b 
	on a.sin = b.sin;
	quit;

	/* -------------------------------------------------------------------------------- */
	/* ETAPE 3 : Lib�ration de l'espace work										    */
	/* -------------------------------------------------------------------------------- */
	proc datasets library = work 
	kill;
	quit;

	%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
	%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

	%put "DUREE DE TRATEMENT (ETAPE5) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";

