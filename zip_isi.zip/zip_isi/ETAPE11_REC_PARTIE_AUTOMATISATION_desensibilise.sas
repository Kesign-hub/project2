/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE11_REC_PARTIE.SAS								      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 05/09/2018												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION:																	  */
/* Afin de suivre l'impact de la convention IRSI qui s'applique sur les sinistres */
/* en habitation (NH, HA,MR),en PRO (MP) et en AGRI (MA) avec la garantie DDE ou  */
/* INC (hors ELEC et INC sinistr�es simultan�ment), nous construisons un datamart.*/
/* Ce dernier contient le p�rim�tre suivant :									  */
/* 			- Sinistres survenus depuis 01/06/2018								  */
/*			- hors les sinistres annul�s										  */
/*			- avec la garantie DDE et/ou INC non annul�							  */
/*			- pour les produits NH, HA, MR, MP, MA								  */
/*			- Aucun sinistre DDE ou INC ne sera ouvert en pr�d�claration		  */
/* Le principe est d'ajouter chaque mois les donn�es vision fin du mois pr�c�dent */
/* Dans cette �tape nous ajoutons les donn�es des REC que DARVA nous transmets    */
/* Plus pr�cis�ment les REC o� nous ne sommes pas assureur gestionnaire			  */
/* ------------------------------------------------------------------------------ */
/* MARS 2020	|		|- Migration du r�pertoire G:\ vers O:\					  */
/* ------------------------------------------------------------------------------ */


%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;
/* Emplacement des donn�es DARVA REC */
%let chemin =\\bureautique\bureautique\DSIN\POLORGA\EP\02-Productions r�currentes\03-MENS\03-Suivi IRSI\03-Fichiers sources\01-Donn�es externes\DARVA;


%let mois_deb = 1;
%let mois_fin = 12;

/* -------------------------------------------------------------------------------- */
/* ETAPE 1 : Import des fichiers mis � disposition par DARVA sur les donn�es REC    */
/* -------------------------------------------------------------------------------- */
/* INFORMATIONS SUR LE SINISTRE */
;
%put &an0;
%Macro SINISTREDARVA;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

        data IRSI_SINISTRE_&i_format.20&j.;
        %let _EFIERR_ = 0; /* set the ERROR detection macro variable */
        infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_SINISTRE_A20&j.M&i_format..csv"
            dlm=';'
            missover dsd lrecl=32767 firstobs=2;

        informat ID_MSG best12.;
        informat ASSU_CALCUL_STATS $8.;
        informat DATE_REC date9.;
        informat NAT_SINISTRE $2.;
        informat SOURCE $1.;
        informat EXPERT $55.;
        informat REF_EXPERT $12.;
        informat MAIL_EXPERT $50.;
        informat RAISON_SOCIALE $30.;
        informat NUM_DOC $2.;
        informat NUM_DOSS_DARVA $12.;
        informat DTOM date9.;
        informat DT_VISITEXP date9.;
        informat DTENVREC date9.;
        informat TYP_EXP $1.;
        informat ASSUREUR_GEST $30.;
        informat CODE_GTA $3.;
        informat ASSU_ACPR $10.;
        informat NUMORDREMISS $11.;
        informat SIN $17.;
        informat NUM_CONTRAT $17.;
        informat CP_ASSURE $5.;
        informat VILLE_ASSURE $50.;
        informat QUALASSUR $2.;
        informat USAGE $2.;
        informat CP_SINISTRE $5.;
        informat VILLE_SINISTRE $50.;
        informat DATE_SINISTRE date9.;
        informat HEURE_SINISTRE best8.;
        informat REPETITIF $1.;
        informat IMMAT_IMMEUBLE $20.;
        informat STATUT_IMMEUBLE $2.;
        informat TOTAL_ASSIETTE_DU_LOCAL_HT best8.;
        informat TOTAL_RECOURS_PO_TTC best8.;
        informat TOTAL_RECOURS_OCCUPANT_TTC best8.;
        informat TOTAL_RECOURS_PNO_CNP_TTC best8.;
        informat TOTAL_RECOURS_IMMEUBLE_TTC best8.;

        format ID_MSG best12.;
        format ASSU_CALCUL_STATS $8.;
        format DATE_REC date9.;
        format NAT_SINISTRE $2.;
        format SOURCE $1.;
        format EXPERT $55.;
        format REF_EXPERT $12.;
        format MAIL_EXPERT $50.;
        format RAISON_SOCIALE $30.;
        format NUM_DOC $2.;
        format NUM_DOSS_DARVA $12.;
        format DTOM date9.;
        format DT_VISITEXP date9.;
        format DTENVREC date9.;
        format TYP_EXP $1.;
        format ASSUREUR_GEST $30.;
        format CODE_GTA $3.;
        format ASSU_ACPR $10.;
        format NUMORDREMISS $11.;
        format SIN $17.;
        format NUM_CONTRAT $17.;
        format CP_ASSURE $5.;
        format VILLE_ASSURE $50.;
        format QUALASSUR $2.;
        format USAGE $2.;
        format CP_SINISTRE $5.;
        format VILLE_SINISTRE $50.;
        format DATE_SINISTRE date9.;
        format HEURE_SINISTRE best8.;
        format REPETITIF $1.;
        format IMMAT_IMMEUBLE $20.;
        format STATUT_IMMEUBLE $2.;
        format TOTAL_ASSIETTE_DU_LOCAL_HT best8.;
        format TOTAL_RECOURS_PO_TTC best8.;
        format TOTAL_RECOURS_OCCUPANT_TTC best8.;
        format TOTAL_RECOURS_PNO_CNP_TTC best8.;
        format TOTAL_RECOURS_IMMEUBLE_TTC best8.;

        input
            ID_MSG
            ASSU_CALCUL_STATS $
            DATE_REC
            NAT_SINISTRE $
            SOURCE $
            EXPERT $
            REF_EXPERT $
            MAIL_EXPERT $
            RAISON_SOCIALE $
            NUM_DOC $
            NUM_DOSS_DARVA $
            DTOM
            DT_VISITEXP
            DTENVREC
            TYP_EXP $
            ASSUREUR_GEST $
            CODE_GTA $
            ASSU_ACPR $
            NUMORDREMISS $
            SIN $
            NUM_CONTRAT $
            CP_ASSURE $
            VILLE_ASSURE $
            QUALASSUR $
            USAGE $
            CP_SINISTRE $
            VILLE_SINISTRE $
            DATE_SINISTRE
            HEURE_SINISTRE
            REPETITIF $
            IMMAT_IMMEUBLE $
            STATUT_IMMEUBLE $
            TOTAL_ASSIETTE_DU_LOCAL_HT
            TOTAL_RECOURS_PO_TTC
            TOTAL_RECOURS_OCCUPANT_TTC
            TOTAL_RECOURS_PNO_CNP_TTC
            TOTAL_RECOURS_IMMEUBLE_TTC
        ;
        if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
        run;



	data IRSI_SINISTRE_&i_format.20&j. (drop= DATE_REC DTOM DT_VISITEXP DTENVREC DATE_SINISTRE);
	set IRSI_SINISTRE_&i_format.20&j.;

	format DATE_REC2 DTOM2 DT_VISITEXP2 DTENVREC2 DATE_SINISTRE2 ddmmyy10.;

	DATE_REC2 = DATE_REC;
	DTOM2 =DTOM;
	DT_VISITEXP2 =DT_VISITEXP;
	DTENVREC2 =DTENVREC;
	DATE_SINISTRE2 =DATE_SINISTRE;
	run;
		%end;
	
    %End;
	%end;
%Mend SINISTREDARVA;
%SINISTREDARVA;

;
/* CAUSE DU SINISTRE */
;
%Macro CAUSEDARVA;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

	data IRSI_CAUSE_&i_format.20&j.   ;
	%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
	 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_CAUSE_A20&j.M&i_format..csv"
	 delimiter = ';'
	   missover dsd firstobs=2 ;


	   informat ID_MSG best12. ;
	   informat ASSU_CALCUL_STATS $8. ;
	   informat CAUSE_MULTIPLE $2. ;
	   informat CAS_DE_BAREME $2. ;
	   informat CAUSE_BAREME $2. ;
	   informat CAUSE_SINISTRE $2. ;
	   informat CAUSE_SUPPRIMEE $1. ;
	   informat RECHERCHE_FUITE $1. ;
	   
	   
	                                                                         
	   format ID_MSG best12. ;
	   format ASSU_CALCUL_STATS $8. ;
	   format CAUSE_MULTIPLE $2. ;
	   format CAS_DE_BAREME $2. ;
	   format CAUSE_BAREME $2. ;
	   format CAUSE_SINISTRE $2. ;
	   format CAUSE_SUPPRIMEE $1. ;
	   format RECHERCHE_FUITE $1. ;
	   
	input
	            ID_MSG
	            ASSU_CALCUL_STATS $
	            CAUSE_MULTIPLE $
	            CAS_DE_BAREME $
	            CAUSE_BAREME $
	            CAUSE_SINISTRE $
	            CAUSE_SUPPRIMEE $
	            RECHERCHE_FUITE $
	           
	;
	if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
	run;



	proc sql;
			create table IRSI_CAUSE_&i_format.20&j.0 as 
					select a.ID_MSG,
						  a.CAUSE_MULTIPLE,
						  a1.Libelles as casbareme,
						  a2.Libelles as causebareme,
						  a3.libelles as cause_sinistre,
						  a4.libelles as CAUSE_SUPPRIMEE,
						  a.RECHERCHE_FUITE
					from IRSI_CAUSE_&i_format.20&j. as a

					 left join REF.REF_BAREME as a1
					  on a.CAS_DE_BAREME = a1.codes
					left join REF.REF_CAUSEBAREME as a2
					  on a.CAUSE_BAREME = a2.codes
					  left join REF.REF_TYPRISQ as a3
					  on a.CAUSE_SINISTRE = a3.codes
					left join ref.REF_CAUSSUPP as a4
						on a.CAUSE_SUPPRIMEE = a4.codes
	;
	quit;



	proc sort data =IRSI_CAUSE_&i_format.20&j.0;
	by ID_MSG CAUSE_MULTIPLE   RECHERCHE_FUITE;
	run;

	data IRSI_CAUSE_&i_format.20&j.1;
	set IRSI_CAUSE_&i_format.20&j.0;
	by ID_MSG  CAUSE_MULTIPLE   RECHERCHE_FUITE;
	retain Nb;
	if first.ID_MSG then nb = 1;
	else nb = nb+1;
	run;


	proc transpose data = IRSI_CAUSE_&i_format.20&j.1 
				    out = IRSI_CAUSE_&i_format.20&j.2 
	 ;
	by ID_MSG CAUSE_MULTIPLE RECHERCHE_FUITE Nb  ;
	var    casbareme  causebareme CAUSE_SINISTRE CAUSE_SUPPRIMEE  ;

	run;

	proc transpose data =  IRSI_CAUSE_&i_format.20&j.2
				delimiter = _
	 				out = IRSI_CAUSE_&i_format.20&j.3 (drop=_name_)
	;

	by ID_MSG  CAUSE_MULTIPLE RECHERCHE_FUITE;
	var  col1;
	id _name_ Nb;
	run;

	/* on sait combien de maxi causes supprim�es nous avons dans les fichiers*/
	/* Mettre en commentaire � l'�tape 3 sur les variables des causes supprim�es qui ne sont pas pr�sentes dans le fichier source*/
	proc sort  data = IRSI_CAUSE_&i_format.20&j.3 nodupkey out=ssdd dupout=dd;
	by ID_MSG;
	run;
	%end;
	%end;
	%end;
%Mend CAUSEDARVA;
%CAUSEDARVA




/* DOMMAGE IMMATERIEL PAR PARTIE */

%Macro DOMIMMAT;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		data IRSI_DOM_IMMA_&i_format.20&j.  ;
		%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
		 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_DOM_IMMA_A20&j.M&i_format..csv"
		 delimiter = ';'
		   missover dsd lrecl=32767 firstobs=2 ;

		    informat ID_MSG best12. ;
		    informat ID_PARTIE best12. ;
		    informat ASSU_CALCUL_STATS $8. ;
		    informat NAT_DOMMAGE_IMMAT $2. ;
		    informat TAUX_TVA_IMMAT best4. ;
		    informat MT_HT_DOMIMMAT best12. ;
		    informat MT_TTC_DOMIMMAT best32. ;
		    format ID_MSG best12. ;
		    format ID_PARTIE best12. ;
		    format ASSU_CALCUL_STATS $8. ;
		    format NAT_DOMMAGE_IMMAT $2. ;
		    format TAUX_TVA_IMMAT best4. ;
		    format MT_HT_DOMIMMAT best12. ;
		    format MT_TTC_DOMIMMAT best12. ;
		 input
		             ID_MSG
		             ID_PARTIE
		             ASSU_CALCUL_STATS $
		             NAT_DOMMAGE_IMMAT $
		             TAUX_TVA_IMMAT
		             MT_HT_DOMIMMAT
		             MT_TTC_DOMIMMAT

		           
		;
		if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
		run;
	%end;
	%end;
	%end;
%Mend DOMIMMAT;
%DOMIMMAT

/* DOMMAGE MATERIEL PAR PARTIE */
%Macro DOMMAT;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		data IRSI_DOM_MAT_&i_format.20&j.  ;
		%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
		 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_DOM_MAT_A20&j.M&i_format..csv"
		 delimiter = ';'
		   missover dsd lrecl=32767 firstobs=2 ;

		    informat ID_MSG best12. ;
		    informat ID_PARTIE best12. ;
			informat ID_PREJMAT best12.;
		    informat ASSU_CALCUL_STATS $8. ;
		    informat NATURE_DOMMAGE_MAT $2. ;
		    informat TAUX_TVA_MAT best4. ;
		    informat VAN_HT_DOMMAT best12. ;
		    informat VAN_TTC_DOMMAT best32. ;
			informat VD_HT_DOMMAT best12. ;
		    informat VD_TTC_DOMMAT best32. ;


		    format ID_MSG best12. ;
		    format ID_PARTIE best12. ;
			format ID_PREJMAT best12.;
		    format ASSU_CALCUL_STATS $8. ;
		    format NATURE_DOMMAGE_MAT $2. ;
		    format TAUX_TVA_MAT best4. ;
		    format VAN_HT_DOMMAT best12. ;
		    format VAN_TTC_DOMMAT best12. ;
			format VD_HT_DOMMAT best12. ;
		    format VD_TTC_DOMMAT best12. ;

		 input
		              ID_MSG
					  ID_PARTIE
					  ID_PREJMAT
					  ASSU_CALCUL_STATS $
					  NATURE_DOMMAGE_MAT $
					  TAUX_TVA_MAT
					  VAN_HT_DOMMAT
					  VAN_TTC_DOMMAT
					  VD_HT_DOMMAT
		              VD_TTC_DOMMAT
		;
		if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
		run;
	%end;
	%end;
	%end;
%mend DOMMAT;
%DOMMAT


/* FRAIS AFFERENT LIE AUX DOM MAT PAR PARTIE */

%Macro FRAIS;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		data IRSI_FRAIS_AF_&i_format.20&j.  ;
		%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
		 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_FRAIS_AF_A20&j.M&i_format..csv"
		 delimiter = ';'
		   missover dsd lrecl=32767 firstobs=2 ;

		    informat ID_MSG best12. ;
		    informat ID_PARTIE best12. ;
			informat ID_PREJMAT best12.;
		    informat ASSU_CALCUL_STATS $8. ;
		    informat NATURE_FRAIS_AFFERENTS $2. ;
		    informat TAUX_TVA_FRAI best4. ;
		    informat VAN_HT_FRAI best12. ;
		    informat VAN_TTC_FRAI best32. ;

		    format ID_MSG best12. ;
		    format ID_PARTIE best12. ;
			format ID_PREJMAT best12.;
		    format ASSU_CALCUL_STATS $8. ;
		    format NATURE_FRAIS_AFFERENTS $2. ;
		    format TAUX_TVA_FRAI best4. ;
		    format VAN_HT_FRAI best12. ;

		 input
		              ID_MSG
					  ID_PARTIE
					  ID_PREJMAT
					  ASSU_CALCUL_STATS $
					  NATURE_FRAIS_AFFERENTS $
					  TAUX_TVA_FRAI
					  VAN_HT_FRAI
					  VAN_TTC_FRAI
					  
		;
		if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
		run;
	%end;
	%end;
	%end;
%mend FRAIS;
%FRAIS

%Macro PARTIE;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		data IRSI_PARTIE_&i_format.20&j.  ;
		%let _EFIERR_ = 0; /* set the ERROR detection macro variable */
		 Infile "&chemin.\20&j.\&i_format.20&j.\CSV_IRSI_PACIFICA_PARTIE_A20&j.M&i_format..csv"
		 delimiter = ';'
		   missover dsd lrecl=32767 firstobs=2 ;
		 informat ID_MSG best12. ;
		   informat ID_PARTIE best12. ;
		   informat ASSU_CALCUL_STATS $8. ;
		   informat QUALITE_PARTIE $2. ;
		   informat NOM_PARTIE $50. ;
		   informat ADRESSE $55. ;
		   informat CP_PARTIE $5. ;
		   informat VILLE_PARTIE $50. ;
		   informat GTA_PARTIE $3. ;
		   informat NUM_CONTRAT $15. ;
		   informat SIN_PARTIE $11. ;
		   informat LRAR $1. ;
		   informat PRESENCE_PARTIE $1. ;
		   informat LESE_AUTEUR $2. ;
		   informat ASSUJETTI_TVA best12. ;
		   informat ACCORD_OCCUPANT $1. ;
		   informat ACCORD_NON_OCCUPANT $1. ;
		   informat ACCORD $1.;
		   
		                                                                         
		   format ID_MSG best12. ;
		   format ID_PARTIE best12. ;
		   format ASSU_CALCUL_STATS $8. ;
		   format QUALITE_PARTIE $2. ;
		   format NOM_PARTIE $50. ;
		   format ADRESSE $55. ;
		   format CP_PARTIE $5. ;
		   format VILLE_PARTIE $50. ;
		   format GTA_PARTIE $3. ;
		   format NUM_CONTRAT $15. ;
		   format SIN_PARTIE $11. ;
		   format LRAR $1. ;
		   format PRESENCE_PARTIE $1. ;
		   format LESE_AUTEUR $2. ;
		   format ASSUJETTI_TVA best12. ;
		   format ACCORD_OCCUPANT $1. ;
		   format ACCORD_NON_OCCUPANT $1. ;
		   format ACCORD $1. ;
		input
		            ID_MSG
		            ID_PARTIE
		            ASSU_CALCUL_STATS $
		            QUALITE_PARTIE $
		            NOM_PARTIE $
		            ADRESSE $
		            CP_PARTIE $
		            VILLE_PARTIE $
		            GTA_PARTIE $
		            NUM_CONTRAT $
		            SIN_PARTIE $
		            LRAR $
		            PRESENCE_PARTIE $
		            LESE_AUTEUR $
		            ASSUJETTI_TVA
		            ACCORD_OCCUPANT $
		            ACCORD_NON_OCCUPANT $
		            ACCORD $
		;
		if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
		run;

				proc sql;
				create table IRSI_PARTIE_&i_format.20&j.0 as 
						select a.ID_MSG,
							   a.ID_PARTIE,
							   a1.sin,
							   a1.ASSUREUR_GEST,
							   a.NUM_CONTRAT,
							   a.NOM_PARTIE,
							   a.CP_PARTIE,
							   a.VILLE_PARTIE,
							   a.LRAR,
							   case when  a.GTA_PARTIE ="446" then "ASSURE"
							   when  a.GTA_PARTIE = "" AND A.SIN_PARTIE = "" 
							   and a.NUM_CONTRAT = "" then "ASSURE" 
							   else "TIERS" end as IDENTIFICATION_PARTIE,
							   a.GTA_PARTIE, 
							   a.PRESENCE_PARTIE,
							   a.ASSUJETTI_TVA,
							   a.ACCORD_OCCUPANT,
							   a.ACCORD_NON_OCCUPANT,
							   a.ACCORD,
							   case when a.QUALITE_PARTIE in ("01","06","99") then b1.Libelles 
							   else b3.Libelles end as QUALITE_PARTIE,
							   b2.libelles  as LESE_AUTEUR,
							   d1.Libelles as DOM_IMMAT,
							   d.MT_HT_DOMIMMAT,
							   d.MT_TTC_DOMIMMAT,
							   e1.Libelles as DOM_MAT,
							   e.VAN_HT_DOMMAT,
							   e.VAN_TTC_DOMMAT,
							   e.VD_HT_DOMMAT,
							   e.VD_TTC_DOMMAT,
							   f1.libelles as frais,
							   f.VAN_HT_FRAI,
							   f.VAN_TTC_FRAI

						from IRSI_PARTIE_&i_format.20&j. as a
						inner join IRSI_SINISTRE_&i_format.20&j. as a1
							on a.ID_MSG = a1.ID_MSG

						left join REF.REF_QUALLESE as b1
						  on a.QUALITE_PARTIE = b1.Codes 
						left join REF.REF_TYPELESE as b2
						  on a.LESE_AUTEUR = b2.Codes
						left join REF.REF_QUALASSUR as b3
						  on a.QUALITE_PARTIE = b3.Codes 

						left join IRSI_DOM_IMMA_&i_format.20&j. as d
						 	on a.ID_MSG = d.ID_MSG and a.ID_PARTIE = d.ID_PARTIE
						left join REF.REF_NATUREPREJUDICE as d1
						 	on d.NAT_DOMMAGE_IMMAT = d1.Codes
						
						/* Ajout des donn�es sur l'�valuation des dommages mat�riels du local de notre assur� */
						left join IRSI_DOM_MAT_&i_format.20&j. as e
						 on a.ID_MSG = e.ID_MSG and a.ID_PARTIE = e.ID_PARTIE
						left join REF.REF_NATUREDOM as e1
						 	on e.NATURE_DOMMAGE_MAT = e1.Codes

					    /* Ajout des donn�es sur l'�valuation des frais aff�rents du local de notre assur� */
						left join IRSI_FRAIS_AF_&i_format.20&j. as f
						on a.ID_MSG = f.ID_MSG and a.ID_PARTIE = f.ID_PARTIE and e.ID_PREJMAT=f.ID_PREJMAT
						left join  REF.REF_FRAISAFFERENT as f1
							on f.NATURE_FRAIS_AFFERENTS = f1.codes
						where a1.ASSUREUR_GEST ne "PACIFICA"
		;
		quit;
	%end;
	%end;
	%end;
%mend PARTIE;
%PARTIE


/* DEPUIS JANVIER 2019 */


%Macro CONSOLIDATION;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;
		proc sql;

				create table temp.DONNEES_REC_PARTIE_&i_format.20&j. as 
					select    case when month (a.DATE_REC2) in (4,6,9,11) then mdy(month (a.DATE_REC2),30,20&j.)	
								   when month (a.DATE_REC2) = 2 and 20&j. ne 2020	then mdy(month (a.DATE_REC2),28,20&j.)
								   when month (a.DATE_REC2) = 2 and 20&j. = 2020	then mdy(month (a.DATE_REC2),29,20&j.)
							  else mdy(month (a.DATE_REC2),31,20&j.)
							  end as DTREF 										length = 4 format ddmmyy10.,
							  a.sin,
							  a.ID_MSG,
							  a.DATE_REC2 as DT_REC format ddmmyy10.,
							  a.DTOM2 as DTOM format ddmmyy10.,
							  a.DT_VISITEXP2 as DT_VISITEXP format ddmmyy10.,
							  a.DTENVREC2 as DTENVREC format ddmmyy10.,
							  a3.Libelles as NATSIN,
							  a1.Libelles as type_expertise,
							  a2.libelles as QUALASSUR,
							  a4.Libelles as USAGE,
							  a.NUMORDREMISS,
							  a.CP_SINISTRE,
							  a.REPETITIF,
							  a.ASSUREUR_GEST,
							  a5.Libelles as TYP_IMMEUBLE,
							  a.TOTAL_ASSIETTE_DU_LOCAL_HT as ASSIETTE_TOTAL_HT,
							  a.TOTAL_RECOURS_PO_TTC,
							  a.TOTAL_RECOURS_OCCUPANT_TTC,
							  a.TOTAL_RECOURS_PNO_CNP_TTC,
							  a.TOTAL_RECOURS_IMMEUBLE_TTC,
							  c.*,
							  b.id_partie,
							  b.QUALITE_PARTIE,
							  b.NUM_CONTRAT,
							  b.NOM_PARTIE,
							  b.QUALITE_PARTIE,
							  b.CP_PARTIE,
							  b.VILLE_PARTIE,
							  b.IDENTIFICATION_PARTIE,
							  b.LRAR,
							  case when b.PRESENCE_PARTIE = "N" then "Personne pr�sente"
							  else "Non pr�sente" end as PRESENCE,
							  b.LESE_AUTEUR,
							  case when b.ACCORD_OCCUPANT="1" then "Non retourn�e"
							  when b.ACCORD_OCCUPANT="2" then "Refus" 
							  when b.ACCORD_OCCUPANT="3" then "Acceptation des dommages"
							  else "" end as ACCORD_OCCUPANT format $30.,
							  case when b.ACCORD_NON_OCCUPANT="1" then "Non retourn�e"
							  when b.ACCORD_NON_OCCUPANT="2" then "Refus" 
							  when b.ACCORD_NON_OCCUPANT="3" then "Acceptation des dommages"
							  else "" end as ACCORD_NON_OCCUPANT format $30.,
							  case when b.ACCORD="1" then "Non retourn�e"
							  when b.ACCORD="2" then "Refus" 
							  when b.ACCORD="3" then "Acceptation des dommages"
							  else "" end as ACCORD format $30.,					  				  
							  b.DOM_IMMAT,
							  b.MT_HT_DOMIMMAT,
							  b.MT_TTC_DOMIMMAT,
							  b.DOM_MAT,
							  b.VAN_HT_DOMMAT,
							  b.VAN_TTC_DOMMAT,
							  b.VD_HT_DOMMAT,
							  b.VD_TTC_DOMMAT,
							  b.frais,
							  b.VAN_HT_FRAI,
							  b.VAN_TTC_FRAI

						from IRSI_SINISTRE_&i_format.20&j. as a

						/* Ajout des informations sur les donn�es principale du l�s� PACIFICA */
						left join REF.REF_TYPEXP as a1
							on a.TYP_EXP = a1.codes
						left join REF.REF_QUALASSUR as a2
							on a.QUALASSUR = a2.Codes
						left join REF.REF_NATSIN as a3
							on a.NAT_SINISTRE = a3.codes
						left join REF.REF_USAGERIS as a4
							on a.USAGE = a4.codes
						left join REF.REF_STATUT_IMMEUBLE as a5
							on a.STATUT_IMMEUBLE = a5.codes
						
						/* Ajout d'information sur les parties concern�es par le sinistre : notre assur� et les tiers */	
						left join IRSI_PARTIE_&i_format.20&j.0  as b
						 on a.ID_MSG = b.ID_MSG
						
					
						/* ajout de l'information sur les causes du sinistre */
						left join IRSI_CAUSE_&i_format.20&j.3 as c
						  on a.ID_MSG = c.ID_MSG 
						  where a.ASSUREUR_GEST ne "PACIFICA"

		;
		quit;
	%end;
	%end;
	%end;
%mend CONSOLIDATION;
%CONSOLIDATION




/* -------------------------------------------------------------------------------- */
/* ETAPE 3: Rapprochement avec les donn�es sinistres de  l'�tape 2				    */
/* -------------------------------------------------------------------------------- */
/* retravaillent des informations des REC pour avoir 1 ligne par dtref et ID_MSG    */
/* -------------------------------------------------------------------------------- */


/* --------------------------------------- */
/* DONNEES GENERALES ASSIETTE PROTOCOLAIRE */
/* --------------------------------------- */
/* ces informations sont uniques par rapport => suppression des doublons li�es aux lignes de d�tails des dommages et pr�judices par partie
 et des rapports extraits sur 2 mois car � cheval entre extraction de 2 mois cons�cutifs */

%Macro GENERAL1;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		proc sort data=temp.DONNEES_REC_PARTIE_&i_format.20&j. nodupkey out= sansdd_&i_format.20&j. dupout= doublons0;
		by _all_;
		run;

		proc sql noprint;
		    /* Permet de trouver la variable qui commence par CAUSE_SUPPRIMEE_ la plus �lev� du dataset SANSDD */
		    select name into :stop_var
		    from sashelp.vcolumn
		    where libname="WORK" and memname="SANSDD_&i_format.20&j." and name like "CAUSE_SUPPRIMEE_%"
		    order by input(scan(name, -1, "_"), 8.) desc;
		quit;

		%put &stop_var;

		proc sql noprint;
		    /* � l"aide de la librairie SASHELP VCOLUMN on r�cup�re la position de cette variable */
		    select varnum into :stop_varnum
		    from sashelp.vcolumn
		    where libname="WORK" and memname="SANSDD_&i_format.20&j." and name = "&stop_var";

		    /* Et enfin on prend toutes les variables pr�sentes avant cette variable comprise */
		    select name into :keepvars separated by " "
		    from sashelp.vcolumn
		    where libname="WORK" and memname="SANSDD_&i_format.20&j." and varnum <= &stop_varnum;
		quit;

		%put &stop_varnum;
		%put &keepvars;

		proc sort data = sansdd_&i_format.20&j. (keep = &keepvars) nodupkey/* A modifier */
		   out = GENERAL_IRSI_&i_format.20&j.;
			by _all_;
		run;

		proc sort data= general_irsi_&i_format.20&j. ;
		by id_msg descending dt_rec;
		run;

		data general_irsi_&i_format.20&j.1;
		set general_irsi_&i_format.20&j. ;
		by id_msg descending dt_rec;
		if first.id_msg ;
		run;

		/* --------------------------------------- */
		/* DONNEES GENERALES PARTIES ASSURE		   */
		/* --------------------------------------- */

		proc sort data = sansdd_&i_format.20&j. (keep = DTREF ID_MSG id_partie dt_rec QUALITE_PARTIE IDENTIFICATION_PARTIE   
										LRAR PRESENCE LESE_AUTEUR ACCORD_OCCUPANT ACCORD_NON_OCCUPANT ACCORD
						 	            DOM_MAT VAN_HT_DOMMAT VAN_TTC_DOMMAT VD_HT_DOMMAT VD_TTC_DOMMAT 
										frais VAN_HT_FRAI VAN_TTC_FRAI 
										DOM_IMMAT MT_HT_DOMIMMAT MT_TTC_DOMIMMAT) nodupkey
				   out = PARTIE_IRSI_&i_format.20&j. dupout= doublons2;

		by _all_;
		run;

		proc sort data=PARTIE_IRSI_&i_format.20&j.  ;
		by id_msg id_partie descending dt_rec;
		run;
	%end;
	%end;
	%end;
%mend GENERAL1;
%GENERAL1


/* --------------------------------------- */
/* DONNEES DOMMAGES IMMAT 				   */
/* --------------------------------------- */

%Macro GENERAL2;

	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;
	
		proc sort data = PARTIE_IRSI_&i_format.20&j. (keep = DTREF ID_MSG dt_rec ID_PARTIE DOM_IMMAT MT_HT_DOMIMMAT MT_TTC_DOMIMMAT 
									 where = (DOM_IMMAT ne "")) nodupkey
		out = PARTIE_IRSI_&i_format.20&j.a;
		by  _all_;
		run;

		proc sort data=PARTIE_IRSI_&i_format.20&j.a;
		by  ID_MSG ID_PARTIE DOM_IMMAT ;
		data PARTIE_IRSI_&i_format.20&j.a1 (drop=MT_HT_DOMIMMAT MT_TTC_DOMIMMAT);
		set PARTIE_IRSI_&i_format.20&j.a;
		by  ID_MSG ID_PARTIE DOM_IMMAT ;
		retain nb;

		if first.ID_PARTIE then nb = 1;
		else NB = NB+1;
			 if DOM_IMMAT = "Les frais de garde-meubles" then do;
			 													MTHT_GARDEMEUBLE = MT_HT_DOMIMMAT ;
							   									MTTTC_GARDEMEUBLE=MT_TTC_DOMIMMAT;
															  end;
		else if DOM_IMMAT = "Les frais de relogement" then do;
		 													MTHT_RELOGEMENT = MT_HT_DOMIMMAT ;
						   									MTTTC_RELOGEMENT=MT_TTC_DOMIMMAT;
														   end;
		else if DOM_IMMAT = "La perte d�usage des locaux" then do;
				 												MTHT_PERTEUSAGELOC  = MT_HT_DOMIMMAT ;
								   								MTTTC_PERTEUSAGELOC = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "La perte de loyers"		 then do;
				 												MTHT_PERTELOYER  = MT_HT_DOMIMMAT ;
								   								MTTTC_PERTELOYER = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "Les frais d�huissier"		 then do;
				 												MTHT_HUISSIER  = MT_HT_DOMIMMAT ;
								   								MTTTC_HUISSIER = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "Les frais de reconstitution d�archives" then do;
							 												MTHT_ARCHIVES  = MT_HT_DOMIMMAT ;
											   								MTTTC_ARCHIVES = MT_TTC_DOMIMMAT;
																		   end;				   			  
		else if DOM_IMMAT = "Les pertes d�exploitation"	 then do;
				 												MTHT_PERTEEXPLOIT  = MT_HT_DOMIMMAT ;
								   								MTTTC_PERTEEXPLOIT = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "Les frais de gardiennage"	 then do;
				 												MTHT_GARDIENNAGE  = MT_HT_DOMIMMAT ;
								   								MTTTC_GARDIENNAGE = MT_TTC_DOMIMMAT;
															   end;
		else if DOM_IMMAT = "Les honoraires de ma�trise d��uvre"	 then do;
							 												MTHT_HONOMOE  = MT_HT_DOMIMMAT ;
											   								MTTTC_HONOMOE = MT_TTC_DOMIMMAT;
																		   end;

		else if DOM_IMMAT = "Autres"	 then do;
							 					MTHT_IMATAUT  = MT_HT_DOMIMMAT ;
												MTTTC_IMATAUT = MT_TTC_DOMIMMAT;
											   end;
											  
		run;

		proc transpose data = PARTIE_IRSI_&i_format.20&j.a1 
					    out = PARTIE_IRSI_&i_format.20&j.a2  
		 ;
		by ID_MSG ID_PARTIE  nb ;
		var   MTHT_GARDEMEUBLE MTTTC_GARDEMEUBLE MTHT_RELOGEMENT MTTTC_RELOGEMENT MTHT_PERTEUSAGELOC MTTTC_PERTEUSAGELOC 
			  MTHT_PERTELOYER MTTTC_PERTELOYER MTHT_HUISSIER MTTTC_HUISSIER MTHT_ARCHIVES MTTTC_ARCHIVES 
			  MTHT_PERTEEXPLOIT MTTTC_PERTEEXPLOIT MTHT_HONOMOE MTTTC_HONOMOE MTHT_IMATAUT MTTTC_IMATAUT ;

		run;

		proc sql;
			create table PARTIE_IRSI_&i_format.20&j.a2b as 
						select ID_MSG,
							   ID_PARTIE,
							   _NAME_,
							   sum(col1) as col1
					from PARTIE_IRSI_&i_format.20&j.a2
					group by ID_MSG, ID_PARTIE,_NAME_;
		quit;

		proc transpose data =  PARTIE_IRSI_&i_format.20&j.a2b
				
		 				out = PARTIE_IRSI_&i_format.20&j.a3 (drop=_name_)
		;

		by ID_MSG ID_PARTIE ;
		var  col1;
		id _name_ ;
		run;

		proc sort data = PARTIE_IRSI_&i_format.20&j. (keep=DTREF ID_MSG dt_rec ID_PARTIE DOM_MAT VAN_HT_DOMMAT VAN_TTC_DOMMAT VD_HT_DOMMAT
							  			VD_TTC_DOMMAT where=(DOM_MAT ne "")) 
		out = PARTIE_IRSI_&i_format.20&j.b;
		by  _all_;
		run;

		proc sort data=PARTIE_IRSI_&i_format.20&j.b;
		by  ID_MSG ID_PARTIE DOM_MAT ;
		data PARTIE_IRSI_&i_format.20&j.b1;
		set PARTIE_IRSI_&i_format.20&j.b;
		by  ID_MSG ID_PARTIE DOM_MAT ;
		retain nb;

		if first.ID_PARTIE then nb = 1;
		else NB = NB+1;
			if DOM_MAT = "EMBELLISSEMENT" then do;
												 VANHT_EMBELISSEMENT = VAN_HT_DOMMAT;
												 VANTTC_EMBELISSEMENT = VAN_TTC_DOMMAT;
												 VDHT_EMBELISSEMENT = VD_HT_DOMMAT;
												 VDTTC_EMBELISSEMENT = VD_TTC_DOMMAT;
												end;
		else 	if DOM_MAT = "MOBILIER" then do;
												 VANHT_MOBILIER = VAN_HT_DOMMAT;
												 VANTTC_MOBILIER = VAN_TTC_DOMMAT;										 
												 VDHT_MOBILIER = VD_HT_DOMMAT;
												 VDTTC_MOBILIER = VD_TTC_DOMMAT;
												end;
		else 	if DOM_MAT = "RECHERCHE DE FUITE DESTRUCTIVE" then do;
																	 VANHT_FUITEDESTRUC = VAN_HT_DOMMAT ;
																	 VANTTC_FUITEDESTRUC = VAN_TTC_DOMMAT;
																	 VDHT_FUITEDESTRUC = VD_HT_DOMMAT;
																	 VDTTC_FUITEDESTRUC = VD_TTC_DOMMAT;
																	end;
		else 	if DOM_MAT = "RECHERCHE DE FUITE NON DESTRUCTIVE" then do;
																		 VANHT_FUITENODESTRUC = VAN_HT_DOMMAT ;
																		 VANTTC_FUITENODESTRUC = VAN_TTC_DOMMAT;
																		 VDHT_FUITENODESTRUC = VD_HT_DOMMAT;
																		 VDTTC_FUITENODESTRUC = VD_TTC_DOMMAT;
																		end;
		else 	if DOM_MAT = "RECHERCHE DE FUITE PASSAGE EN APPARENT" then do;
																			 VANHT_FUITEAPPARENT = VAN_HT_DOMMAT ;
																			 VANTTC_FUITEAPPARENT = VAN_TTC_DOMMAT;
																			 VDHT_FUITEAPPARENT = VD_HT_DOMMAT;
																			 VDTTC_FUITEAPPARENT = VD_TTC_DOMMAT;
																			end;
		else 	if DOM_MAT = "PARTIES IMMOBILIERE PRIVATIVES" then do;
																	 VANHT_PIP = VAN_HT_DOMMAT ;
																	 VANTTC_PIP = VAN_TTC_DOMMAT;
																	 VDHT_PIP = VD_HT_DOMMAT;
																	 VDTTC_PIP = VD_TTC_DOMMAT;
																	end;
		else 	if DOM_MAT = "PARTIES COMMUNES" then do;
														 VANHT_PARTIECOMMUN = VAN_HT_DOMMAT ;
													 	VANTTC_PARTIECOMMUN = VAN_TTC_DOMMAT;
													 	VDHT_PARTIECOMMUN = VD_HT_DOMMAT;
													 	VDTTC_PARTIECOMMUN = VD_TTC_DOMMAT;
													 end;


		run;


		proc transpose data = PARTIE_IRSI_&i_format.20&j.b1 
					    out = PARTIE_IRSI_&i_format.20&j.b2 
		 ;
		by ID_MSG ID_PARTIE Nb  ;
		var VANHT_EMBELISSEMENT VANTTC_EMBELISSEMENT VDHT_EMBELISSEMENT VDTTC_EMBELISSEMENT
		    VANHT_MOBILIER VANTTC_MOBILIER VDHT_MOBILIER VDTTC_MOBILIER
		    VANHT_FUITEDESTRUC VANTTC_FUITEDESTRUC VDHT_FUITEDESTRUC VDTTC_FUITEDESTRUC
		    VANHT_FUITENODESTRUC VANTTC_FUITENODESTRUC VDHT_FUITENODESTRUC VDTTC_FUITENODESTRUC
			VANHT_FUITEAPPARENT VANTTC_FUITEAPPARENT VDHT_FUITEAPPARENT VDTTC_FUITEAPPARENT
			VANHT_PIP VANTTC_PIP VDHT_PIP VDTTC_PIP
			VANHT_PARTIECOMMUN VANTTC_PARTIECOMMUN VDHT_PARTIECOMMUN VDTTC_PARTIECOMMUN;
		run;

		proc sql;
			create table PARTIE_IRSI_&i_format.20&j.b2b as 
						select distinct ID_MSG,
							   ID_PARTIE,
							   _NAME_,
							   sum(col1) as col1
					from PARTIE_IRSI_&i_format.20&j.b2
					group by ID_MSG, ID_PARTIE,_NAME_;
		quit;

		proc transpose data =  PARTIE_IRSI_&i_format.20&j.b2b
					delimiter=_
		 				out = PARTIE_IRSI_&i_format.20&j.b3 (drop=_name_)
		;

		by ID_MSG ID_PARTIE;
		var  col1;
		id _name_ ;
		run;

		proc sort data=PARTIE_IRSI_&i_format.20&j.b3 nodupkey out=ss dupout=doublo;
		by ID_MSG ID_PARTIE;
		run;
	%end;
	%end;
	%end;
%mend GENERAL2;
%GENERAL2

/* --------------------------------------- */
/* DONNEES FRAIS AFFERENTS				   */
/* --------------------------------------- */


%Macro GENERAL3;

	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		proc sort data=PARTIE_IRSI_&i_format.20&j. (keep=DTREF ID_MSG ID_PARTIE dt_rec frais VAN_HT_FRAI VAN_TTC_FRAI
							  			 where=(frais ne ""))  
				   out=PARTIE_IRSI_&i_format.20&j.c;
		by  ID_MSG ID_PARTIE  descending dt_rec;
		run;
		data PARTIE_IRSI_&i_format.20&j.c1;
		set PARTIE_IRSI_&i_format.20&j.c;
		by  ID_MSG ID_PARTIE  descending dt_rec;
		retain nb;

		if first.ID_PARTIE then nb = 1;
		else NB = NB+1;
			if frais = "MESURES PROVISOIRES ET CONSERVATOIRES" then do;
																	  VANHT_MESUREPROVCONS = VAN_HT_FRAI;
																	  VANTTC_MESUREPROVCONS = VAN_TTC_FRAI;
																	end;
		else 	if frais = "MESURES DE SAUVETAGE" then do;
														 VANHT_MESURESAUV = VAN_HT_FRAI;
														 VANTTC_MESURESAUV = VAN_TTC_FRAI;					 
														end;
		else 	if frais = "FRAIS DE DEPLACEMENT DES OBJETS MOBILIERS" then do;
																				 VANHT_DEPLACTOBJET = VAN_HT_FRAI ;
																				 VANTTC_DEPLACTOBJET = VAN_TTC_FRAI;
																				end;
		else 	if frais = "FRAIS DE DEMOLITION ET DE DEBLAIEMENT, TRANSPORT DE DECOMBRES, TRAITEMENT DES DECHETS" then do;
																														 	VANHT_DEMOLDEBLAI = VAN_HT_FRAI ;
																														 	VANTTC_DEMOLDEBLAI = VAN_TTC_FRAI;
																														end;
		else 	if frais = "FRAIS DE MISE EN CONFORMITE" then do;
																 VANHT_MISECONFORM = VAN_HT_FRAI ;
															 	VANTTC_MISECONFORM = VAN_TTC_FRAI;
															  end;
		else 	if frais = "FRAIS DES DIAGNOSTICS OBLIGATOIRES LIMITES A LA ZONE SINISTREE" then do;
																									 VANHT_DIAGNOSTIC = VAN_HT_FRAI ;
																									 VANTTC_DIAGNOSTIC = VAN_TTC_FRAI;
																								 end;


		run;

		proc transpose data = PARTIE_IRSI_&i_format.20&j.c1 
					    out = PARTIE_IRSI_&i_format.20&j.c2 
		 ;
		by ID_MSG ID_PARTIE Nb  ;
		var VANHT_MESUREPROVCONS VANTTC_MESUREPROVCONS VANHT_MESURESAUV VANTTC_MESURESAUV
			VANHT_DEPLACTOBJET VANTTC_DEPLACTOBJET VANHT_DEMOLDEBLAI VANTTC_DEMOLDEBLAI
			VANHT_MISECONFORM VANTTC_MISECONFORM VANHT_DIAGNOSTIC VANTTC_DIAGNOSTIC;
		run;

		proc sql;
			create table PARTIE_IRSI_&i_format.20&j.c2b as 
						select distinct ID_MSG,
							   ID_PARTIE,
							   _NAME_,
							   sum(col1) as col1
					from PARTIE_IRSI_&i_format.20&j.c2
					group by ID_MSG, ID_PARTIE,_NAME_;
		quit;

		proc transpose data =  PARTIE_IRSI_&i_format.20&j.c2b
					delimiter=_
		 				out = PARTIE_IRSI_&i_format.20&j.c3 (drop=_name_)
		;

		by ID_MSG ID_PARTIE;
		var  col1;
		id _name_ ;
		run;


		/* --------------------------------------- */
		/* DONNEES DOMMAGES ASSURE				   */
		/* --------------------------------------- */
		data PARTIE_IRSI_&i_format.20&j.3;
		set PARTIE_IRSI_&i_format.20&j. (keep = DTREF ID_MSG dt_rec id_partie IDENTIFICATION_PARTIE QUALITE_PARTIE LRAR 
							    PRESENCE LESE_AUTEUR ACCORD_OCCUPANT ACCORD_NON_OCCUPANT ACCORD
						where=(IDENTIFICATION_PARTIE ="ASSURE"));
		by id_msg id_partie descending dt_rec;
		if first.ID_PARTIE;
		run;

		proc sql;
				create table ASSURE_&i_format.20&j. as 
					select 
						   a.*,
						   b.*,
						   c.*,
						   d.*

					from  PARTIE_IRSI_&i_format.20&j.3 as a
					left join PARTIE_IRSI_&i_format.20&j.a3 as b
						on a.id_msg = b.id_msg and a.id_partie = b.id_partie
					left join PARTIE_IRSI_&i_format.20&j.b3 as c
						on a.id_msg = c.id_msg and a.id_partie = c.id_partie
					left join PARTIE_IRSI_&i_format.20&j.c3 as d
						on a.id_msg = d.id_msg and a.id_partie = d.id_partie
				;
		quit;


/* --------------------------------------- */
/* DONNEES DOMMAGES IMMAT TIERS			   */
/* --------------------------------------- */

		data PARTIE_IRSI_&i_format.20&j.4;
		set PARTIE_IRSI_&i_format.20&j. (keep = DTREF ID_MSG dt_rec id_partie IDENTIFICATION_PARTIE QUALITE_PARTIE LRAR 
							    PRESENCE LESE_AUTEUR ACCORD_OCCUPANT ACCORD_NON_OCCUPANT ACCORD
						where=(IDENTIFICATION_PARTIE ="TIERS"));
		by id_msg id_partie descending dt_rec;
		/*retain nb;*/
		if first.ID_PARTIE/* then nb = 1;
		else NB = NB+1*/;
		run;
	%end;
	%end;
	%end;
%mend GENERAL3;
%GENERAL3


/* -------------------------------------------------------------------------------- */
/* ETAPE 4 : SAUVEGARDE DES DONNEES DES REC										    */
/* -------------------------------------------------------------------------------- */

%MACRO FINAL;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;

		proc sql;
				create table  GENERAL_IRSI_&i_format.20&j.3 as 
					select  a.*,
					        b.*

				from general_irsi_&i_format.20&j.1 as a				
				inner join assure_&i_format.20&j. as b
				on a.ID_MSG = b.ID_MSG and a.dtref = b.dtref 
			  ;
		quit;

		proc sort data=GENERAL_IRSI_&i_format.20&j.3 nodupkey out=ssdd2 dupout= doudou;
		by _all_;
		run;
	%end;
	%end;
	%end;
%MEND FINAL;
%FINAL




%MACRO SAUVEGARDE;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;
		data tables.REC_PARTIE;
		set tables.REC_PARTIE 
			GENERAL_IRSI_&i_format.20&j.3 ;
		run;
	%end;
	%end;
	%end;
%MEND SAUVEGARDE;
%SAUVEGARDE



proc freq data=tables.REC_PARTIE;
tables DTREF/list missing;
run;

/*             10:26 Friday, February 27, 2026   1

                                                         La proc�dure FREQ

                                                                           Fr�quence    Pourcentage
                                     DTREF    Fr�quence     Pourcentage     cumul�e        cumul�
                                -------------------------------------------------------------------
                                30/06/2018           1          0.00              1         0.00   
                                31/07/2018          32          0.07             33         0.07   
                                31/08/2018          75          0.16            108         0.23   
                                30/09/2018         148          0.32            256         0.55   
                                31/10/2018         263          0.57            519         1.12   
                                30/11/2018         241          0.52            760         1.64   
                                31/12/2018         234          0.50            994         2.14   
                                31/01/2019         345          0.74           1339         2.88   
                                28/02/2019         329          0.71           1668         3.59   
                                31/03/2019         351          0.76           2019         4.35   
                                30/04/2019         388          0.84           2407         5.18   
                                31/05/2019         349          0.75           2756         5.93   
                                30/06/2019         375          0.81           3131         6.74   
                                31/07/2019         373          0.80           3504         7.54   
                                31/08/2019         273          0.59           3777         8.13   
                                30/09/2019         375          0.81           4152         8.94   
                                31/10/2019         456          0.98           4608         9.92   
                                30/11/2019         354          0.76           4962        10.68   
                                31/12/2019         384          0.83           5346        11.51   
                                31/01/2020         410          0.88           5756        12.39   
                                29/02/2020         387          0.83           6143        13.23   
                                31/03/2020         443          0.95           6586        14.18   
                                30/04/2020         335          0.72           6921        14.90   
                                31/05/2020         258          0.56           7179        15.46   
                                30/06/2020         468          1.01           7647        16.46   
                                31/07/2020         506          1.09           8153        17.55   
                                31/08/2020         329          0.71           8482        18.26   
                                30/09/2020         568          1.22           9050        19.49   
                                31/10/2020         559          1.20           9609        20.69   
                                30/11/2020         586          1.26          10195        21.95   
                                31/12/2020         629          1.35          10824        23.31   
                                31/01/2021         527          1.13          11351        24.44   
                                28/02/2021         524          1.13          11875        25.57   
                                31/03/2021         605          1.30          12480        26.87   
                                30/04/2021         561          1.21          13041        28.08   
                                31/05/2021         497          1.07          13538        29.15   
                                30/06/2021         569          1.23          14107        30.37   
                                31/07/2021         445          0.96          14552        31.33   
                                31/08/2021         382          0.82          14934        32.15   
                                30/09/2021         510          1.10          15444        33.25   
                                31/10/2021         562          1.21          16006        34.46   
                                30/11/2021         525          1.13          16531        35.59   
                                31/12/2021         591          1.27          17122        36.87   
                                31/01/2022         583          1.26          17705        38.12   
                                28/02/2022         617          1.33          18322        39.45   
                                31/03/2022         625          1.35          18947        40.80   
                                30/04/2022         551          1.19          19498        41.98   
                                31/05/2022         548          1.18          20046        43.16   
                                30/06/2022         576          1.24          20622        44.40   
                                31/07/2022         441          0.95          21063        45.35   
                                31/08/2022         373          0.80          21436        46.15   
                                30/09/2022         523          1.13          21959        47.28   
                                                                                                 10:26 Friday, February 27, 2026   2

                                                         La proc�dure FREQ

                                                                           Fr�quence    Pourcentage
                                     DTREF    Fr�quence     Pourcentage     cumul�e        cumul�
                                -------------------------------------------------------------------
                                31/10/2022         561          1.21          22520        48.49   
                                30/11/2022         613          1.32          23133        49.81   
                                31/12/2022         616          1.33          23749        51.13   
                                31/01/2023         667          1.44          24416        52.57   
                                28/02/2023         643          1.38          25059        53.96   
                                31/03/2023         727          1.57          25786        55.52   
                                30/04/2023         541          1.16          26327        56.69   
                                31/05/2023         545          1.17          26872        57.86   
                                30/06/2023         590          1.27          27462        59.13   
                                31/07/2023         510          1.10          27972        60.23   
                                31/08/2023         430          0.93          28402        61.15   
                                30/09/2023         490          1.06          28892        62.21   
                                31/10/2023         698          1.50          29590        63.71   
                                30/11/2023         603          1.30          30193        65.01   
                                31/12/2023         505          1.09          30698        66.10   
                                31/01/2024         630          1.36          31328        67.45   
                                28/02/2024         637          1.37          31965        68.82   
                                31/03/2024         655          1.41          32620        70.24   
                                30/04/2024         643          1.38          33263        71.62   
                                31/05/2024         538          1.16          33801        72.78   
                                30/06/2024         686          1.48          34487        74.26   
                                31/07/2024         652          1.40          35139        75.66   
                                31/08/2024         444          0.96          35583        76.61   
                                30/09/2024         606          1.30          36189        77.92   
                                31/10/2024         791          1.70          36980        79.62   
                                30/11/2024         689          1.48          37669        81.11   
                                31/12/2024         648          1.40          38317        82.50   
                                31/01/2025         677          1.46          38994        83.96   
                                28/02/2025         686          1.48          39680        85.44   
                                31/03/2025         758          1.63          40438        87.07   
                                30/04/2025         725          1.56          41163        88.63   
                                31/05/2025         667          1.44          41830        90.07   
                                30/06/2025         605          1.30          42435        91.37   
                                31/07/2025         681          1.47          43116        92.83   
                                31/08/2025         485          1.04          43601        93.88   
                                30/09/2025         635          1.37          44236        95.25   
                                31/10/2025         769          1.66          45005        96.90   
                                30/11/2025         669          1.44          45674        98.34   
                                31/12/2025         770          1.66          46444       100.00  
								31/01/2026		   619 			1.27 		  48654 	  100.00 
     */


/* HISTORISATION DES DONNEES Recherche de fuite par dataobs */

%let annnee_deux = 24;



%MACRO RDF;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;
		data RDF_PARTIE_&i_format.20&j.;
		set GENERAL_IRSI_&i_format.20&j.3 ;
		dateobs = "&mois_deb.20&j.";
		run;
	%end;
	%end;
	%end;
%MEND RDF;
%RDF



%MACRO SAUVEGARDE2;
	%let stop=0;
	%DO j= &an0. %to &annee_vis.;
    %Do i=&mois_deb. %To &mois_fin.;
		%if &stop=0 %then %do;
				%put &i.;
				%put &annee_vis.;
				%if &i = 1 and &j.=&annee_vis. %then %let stop=1;
	        	%if &i < 10 %then %let i_format = 0&i;
        		%else %let i_format = &i;
		data tables.RDF_PARTIE;
		set tables.RDF_PARTIE 
			RDF_PARTIE_&i_format.20&j. ;
		run;
	%end;
	%end;
	%end;
%MEND SAUVEGARDE2;
%SAUVEGARDE2


proc freq data=tables.RDF_PARTIE;
tables DTREF/list missing;
run;

  /* Ann�es assurance et cotisation acquises calcul�es � partir des MVTPR                               2
                                               12 mois glissants � fin septembre 2023

La proc�dure FREQ

                                                                           Fr�quence    Pourcentage
                                     DTREF    Fr�quence     Pourcentage     cumul�e        cumul�
                                -------------------------------------------------------------------
                                30/06/2018          13          0.01             13         0.01   
                                31/07/2018         416          0.43            429         0.45   
                                31/08/2018         975          1.02           1404         1.47   
                                30/09/2018        1924          2.01           3328         3.48   
                                31/10/2018        3419          3.57           6747         7.05   
                                30/11/2018        3133          3.27           9880        10.32   
                                31/12/2018        3042          3.18          12922        13.49   
                                31/01/2019        4485          4.68          17407        18.18   
                                28/02/2019        4277          4.47          21684        22.64   
                                31/03/2019        4563          4.76          26247        27.41   
                                30/04/2019        4656          4.86          30903        32.27   
                                31/05/2019        3839          4.01          34742        36.28   
                                30/06/2019        3750          3.92          38492        40.20   
                                31/07/2019        3357          3.51          41849        43.70   
                                31/08/2019        2184          2.28          44033        45.98   
                                30/09/2019        2250          2.35          46283        48.33   
                                31/10/2019        3192          3.33          49475        51.66   
                                30/11/2019        1770          1.85          51245        53.51   
                                31/12/2019        1536          1.60          52781        55.12   
                                31/01/2020        1230          1.28          54011        56.40   
                                29/02/2020         774          0.81          54785        57.21   
                                31/03/2020         443          0.46          55228        57.67   
                                30/04/2020         335          0.35          55563        58.02   
                                31/05/2020         258          0.27          55821        58.29   
                                30/06/2020         468          0.49          56289        58.78   
                                31/07/2020         506          0.53          56795        59.31   
                                31/08/2020         329          0.34          57124        59.65   
                                30/09/2020         568          0.59          57692        60.24   
                                31/10/2020         559          0.58          58251        60.83   
                                30/11/2020         586          0.61          58837        61.44   
                                31/12/2020         629          0.66          59466        62.10   
                                31/01/2021         527          0.55          59993        62.65   
                                28/02/2021         524          0.55          60517        63.19   
                                31/03/2021         605          0.63          61122        63.83   
                                30/04/2021         561          0.59          61683        64.41   
                                31/05/2021         497          0.52          62180        64.93   
                                30/06/2021         569          0.59          62749        65.53   
                                31/07/2021         445          0.46          63194        65.99   
                                31/08/2021         382          0.40          63576        66.39   
                                30/09/2021         510          0.53          64086        66.92   
                                31/10/2021         562          0.59          64648        67.51   
                                30/11/2021         525          0.55          65173        68.06   
                                31/12/2021         591          0.62          65764        68.67   
                                31/01/2022         583          0.61          66347        69.28   
                                28/02/2022         617          0.64          66964        69.93   
                                31/03/2022         625          0.65          67589        70.58   
                                30/04/2022         551          0.58          68140        71.15   
                                31/05/2022         548          0.57          68688        71.73   
                                30/06/2022         576          0.60          69264        72.33   
                                31/07/2022         441          0.46          69705        72.79   
                                31/08/2022         373          0.39          70078        73.18   
                                30/09/2022         523          0.55          70601        73.72   
                                                                                                 10:26 Friday, February 27, 2026   2

                                                         La proc�dure FREQ

                                                                           Fr�quence    Pourcentage
                                     DTREF    Fr�quence     Pourcentage     cumul�e        cumul�
                                -------------------------------------------------------------------
                                31/10/2022         561          0.59          71162        74.31   
                                30/11/2022         613          0.64          71775        74.95   
                                31/12/2022         616          0.64          72391        75.59   
                                31/01/2023         667          0.70          73058        76.29   
                                28/02/2023         643          0.67          73701        76.96   
                                31/03/2023         727          0.76          74428        77.72   
                                30/04/2023         541          0.56          74969        78.29   
                                31/05/2023         545          0.57          75514        78.86   
                                30/06/2023         590          0.62          76104        79.47   
                                31/07/2023         510          0.53          76614        80.00   
                                31/08/2023         430          0.45          77044        80.45   
                                30/09/2023         490          0.51          77534        80.96   
                                31/10/2023         698          0.73          78232        81.69   
                                30/11/2023         603          0.63          78835        82.32   
                                31/12/2023         505          0.53          79340        82.85   
                                31/01/2024         630          0.66          79970        83.51   
                                28/02/2024         637          0.67          80607        84.17   
                                31/03/2024         655          0.68          81262        84.86   
                                30/04/2024         643          0.67          81905        85.53   
                                31/05/2024         538          0.56          82443        86.09   
                                30/06/2024         686          0.72          83129        86.81   
                                31/07/2024         652          0.68          83781        87.49   
                                31/08/2024         444          0.46          84225        87.95   
                                30/09/2024         606          0.63          84831        88.58   
                                31/10/2024         791          0.83          85622        89.41   
                                30/11/2024         689          0.72          86311        90.13   
                                31/12/2024         648          0.68          86959        90.81   
                                31/01/2025        1354          1.41          88313        92.22   
                                28/02/2025         686          0.72          88999        92.94   
                                31/03/2025         758          0.79          89757        93.73   
                                30/04/2025         725          0.76          90482        94.49   
                                31/05/2025         667          0.70          91149        95.18   
                                30/06/2025         605          0.63          91754        95.81   
                                31/07/2025         681          0.71          92435        96.52   
                                31/08/2025         485          0.51          92920        97.03   
                                30/09/2025         635          0.66          93555        97.69   
                                31/10/2025         769          0.80          94324        98.50   
                                30/11/2025         669          0.70          94993        99.20   
                                31/12/2025         770          0.80          95763       100.00


 */






/* -------------------------------------------------------------------------------- */
/* ETAPE 6 : Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */
proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE11) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";