/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE7_RECOURS_SUBIS.SAS								      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 27/02/2023												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION :																  */
/* Rajouter les donn�es li�es aux r�glements faits aux compagnies adverses 	  	  */ 
/* 																				  */
/* ------------------------------------------------------------------------------ */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;

/* -------------------------------------------------------------------------------- */
/* ETAPE 1 : INTEGRATION DES REGLEMENTS 										  */
/* -------------------------------------------------------------------------------- */

DATA REG_DDE;
SET  histo2.archi_SIN_REG;
IF &MOISSEUL.> dtouv >= "01JAN17"d;
IF DTANN = .;
IF PRODUIT in ("NH",/*"MA",*/"HA","MR"/*,"MP"*/);
IF GTIESIN IN ("DDE","INC");
IF TYPEMONT IN ("PA") and modergl not in ('CV' 'CG' 'CS');
IF ETATGTIE NOT IN ("A");
IF TYPEBENEF IN ("CI");
RUN;

proc sort data = REG_DDE; 
by SIN produit gtiesin DTRG; 
run;

data reglement_CI;
set REG_DDE;
by SIN produit gtiesin DTRG; 
format GARANTIE $100.;
retain GARANTIE mtrg_CI;
if first.gtiesin  then do;
							GARANTIE = gtiesin;
							mtrg_CI = MTRGGTIE;
					end;
else do;
			GARANTIE = trim(GARANTIE)||"/"||GTIESIN;
			mtrg_CI = mtrg_CI+ MTRGGTIE;
end;
if last.gtiesin;
keep sin produit GARANTIE DTRG etatgtie mtrg_CI;

run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 2 : INTEGRATION AU DATAMART IRSI									  	    */
/* -------------------------------------------------------------------------------- */

proc sql;
create table temp.PERIMETRE_IRSIFFA7 as 
select a.*,
	   b.mtrg_CI,
	   b.DTRG as DATEDERN_REG_CIE

from temp.PERIMETRE_IRSIFFA6 as a 
left join reglement_CI as b 
on a.sin = b.sin ;
quit;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3 : Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */
proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE7) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";
