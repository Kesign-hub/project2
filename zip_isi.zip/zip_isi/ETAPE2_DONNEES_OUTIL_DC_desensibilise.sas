/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE2_DONNEES_OUTIL_DC.SAS							      */
/*																				  */
/* AUTEUR			: LF														  */
/*																				  */
/* DATE				: 27/02/2023												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION :																  */
/* importer des donn�es des outils de gr� � gr� entrant dans la gestion des 	  */
/* sinistres DDE et INC.														  */
/* Il s'agit de : L'outil D.D.E, AGRICOLE, ETAT DE PERTE, Devis Artisan			  */
/* ------------------------------------------------------------------------------ */

/* macro pour avoir les dates jusqu'a N-5 */
data _null_;
	dt1A=INTNX('MONTH',&MOISSEUL,-13);
	dt2A=INTNX('MONTH',&MOISSEUL,-25);
	dt3A=INTNX('MONTH',&MOISSEUL,-37);
	dt4A=INTNX('MONTH',&MOISSEUL,-49);
	dt5A=INTNX('MONTH',&MOISSEUL,-61);
	dt6A=INTNX('MONTH',&MOISSEUL,-73);
  	call symput('ANNEE_1ANS', put(dt1A,mmyyn4.)!!".");
	call symput('ANNEE_2ANS', put(dt2A,mmyyn4.)!!".");
	call symput('ANNEE_3ANS', put(dt3A,mmyyn4.)!!".");
	call symput('ANNEE_4ANS', put(dt4A,mmyyn4.)!!".");
	call symput('ANNEE_5ANS', put(dt5A,mmyyn4.)!!".");
	call symput('ANNEE_6ANS', put(dt6A,mmyyn4.)!!".");
run;

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;

/***** changement annuel ******/
/* ajouter dnas le programme lanceur 27/02/2026 */
%LET annee_vis=25;  
%LET mois_vis=12;

%Macro COMPIL_TABLE;

				Data SIN_ESTIMGB_OUTIL0; 
				Set
					%Do i=24 %To &annee_vis.;
							date&mois_vis.&i..SIN_ESTIMGB_OUTIL
					%End;

;
Run;

%Mend COMPIL_TABLE;
%COMPIL_TABLE

/*   !   *\

/* ajout nouvelle table NEMO a partir de 2025 */

/*   !   *\

*/

proc sort data= SIN_ESTIMGB_OUTIL0 ;
by sin typ_estim no_estim_glb num_version numreg ;
run;

/* 28/10/24 Rajout de la variable typ_estim puis changement last.no_estim_glb */

data SIN_ESTIMGB_OUTIL;
set SIN_ESTIMGB_OUTIL0;
by sin typ_estim no_estim_glb num_version numreg;
if last.no_estim_glb;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 1 : RECUPERATION DE LA DERNIERE ESTIMATION GLOBALE DES DONNEES ANG A ANG	*/
/* -------------------------------------------------------------------------------- */

proc sort data= SIN_ESTIMGB_OUTIL 
(
where= 
(
typ_estim in ('DDE') and 
TYP_DEV ='C' and 
(
(STATUT_ESTIM ne 'A' and typ_estim ne "NEMO") or (STATUT_ESTIM = 'T' and typ_estim = "NEMO")
)
)
)
out=ESTIMATION_GLOBALE2;
by sin no_estim_glb num_version ;
run;
/* 
Pour STATUT_ESTIM dans SIN_ESTIMGB_OUTIL, voici la correspondance dans NEMO :
A = EN ATTENTE
B = ABANDONNE
E = DOUBLE NAVIGATION - MIS ELEC
T = TERMINE
U = ?
Z = EN COURS DE TRAITEMENT
*/

DATA DERNIERE_ESTIMATION;

set ESTIMATION_GLOBALE2;
by sin no_estim_glb num_version ;
retain LIST_NUMREG nb_estim;
length LIST_NUMREG $40.;
format DATE_OBS ddmmyy10.;
if first.sin then do;
					if numreg ne "" then LIST_NUMREG = numreg;
					else LIST_NUMREG = "";
					nb_estim = 1;
				 end;
else do;
		if numreg ne ""  and LIST_NUMREG ne "" and index (LIST_NUMREG,numreg) = 0 then LIST_NUMREG = trim(compress(LIST_NUMREG)||"/"||compress(numreg));
		else if numreg ne ""  and LIST_NUMREG = "" then LIST_NUMREG = numreg;
		else LIST_NUMREG =LIST_NUMREG;
		nb_estim = nb_estim+1;
	 end;

/* s�lection de la derni�re estimation */
if last.sin;

if month (&MOISSEUL.) in (4,6,9,11) then DATE_OBS = mdy(month (&MOISSEUL.),30,&annee.)	;
else if  month (&MOISSEUL.) = 2 and &annee. ne 2020	then DATE_OBS = mdy(month (&MOISSEUL.),28,&annee.);
else if month (&MOISSEUL.) = 2 and &annee. = 2020	then DATE_OBS = mdy(month (&MOISSEUL.),29,&annee.);
else DATE_OBS = mdy(month (&MOISSEUL.),31,&annee.);

run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3 : INTEGRATION AU DATAMART IRSI										  */
/* -------------------------------------------------------------------------------- */

proc sql;
create table temp.PERIMETRE_IRSI_ETAPE2 as 
select a.*,
	   b.TYP_ESTIM,
	   b.TYP_DEV,
	   b.NO_ESTIM_GLB,
	   b.num_version,
	   b.DATE_ESTIM,
	   b.produit as produit_ESTIM,
	   b.gtiesin as gtiesin_ESTIM,
	   b.typbenef as typbenef_ESTIM,
	   b.refbenef as REFBENEF_ESTIM,
	   b.STATUT_ESTIM,
	   b.MT_FRCH as MT_FRCH_ESTIM,
	   b.MT_TOT_NEGO as MT_TOT_NEGO_ESTIM,
	   b.MT_ACOMPTE as MT_ACOMPTE_ESTIM,
	   b.MT_DEJA_TOT as MT_DEJA_TOT_ESTIM,
	   b.LIST_NUMREG,
	   b.MT_PRCH_TOT as MT_PRCH_TOT_ESTIM,
	   b.MT_TOT_RGLT as MT_TOT_RGLT_ESTIM,
	   b.MT_TOT_REST as MT_TOT_REST_ESTIM,
	   b.MOD_INDEMNIS as MOD_INDEMNIS_ESTIM,
	   b.U_FRCH as U_FRCH_ESTIM,
	   b.IND_TVA as IND_TVA_ESTIM,
	   b.COEF_REG as COEF_REG_ESTIM,
	   b.nb_estim

from temp.PERIMETRE_IRSIFFA as a /*1 336 318*/
left join DERNIERE_ESTIMATION as b 
	on a.sin = b.sin and a.gtiesin = b.gtiesin;
quit;

/* -------------------------------------------------------------------------------- */
/* ETAPE 4 : Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */

proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE2) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";