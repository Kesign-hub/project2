/* -------------------------------------------------------------------------------- */
/* NOM DU PROGRAMME : ETAPE6_REGLTS_CLIENT_IDENTIFICATION_DC.SAS			        */
/*																				    */
/* AUTEUR			: CM														    */
/*																				    */
/* DATE				: 23/02/2023												    */
/*																				    */
/* -------------------------------------------------------------------------------- */
/* DESCRIPTION :																    */
/* Rajouter les donn�es li�es aux r�glements faits � l�assur� 					    */ 
/* (li� ou non � l�outil DC ou DA ou EDP)											*/
/* 																					*/
/* 				R�gle d'identification sinistre r�gl� en gr�-�-gr� :				*/
/* 																					*/
/*	-	Code particularit� DC + outil DDE + r�glement								*/
/*	-	Ou 																			*/
/*	-	Code particularit� DC + r�glement dont le b�n�ficiaire est le client		*/
/* -------------------------------------------------------------------------------- */
/* MODIFICATION:																	*/
/* OCTOBRE 2019 :- Ajouter le parquet flottant pos� et Fa�ence/carrelage pour les 	*/
/* 				   PIP																*/
/* -------------------------------------------------------------------------------- */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;

/* -------------------------------------------------------------------------------- */
/* ETAPE 1 : IMPORT DES DONNEES OUTIL DDE  										    */
/* -------------------------------------------------------------------------------- */

%LET annee_vis=25;  
%LET mois_vis=12;

%Macro COMPIL_TABLE;

				Data SIN_ESTIMGB_OUTIL0; 
				Set
					%Do i=24 %To &annee_vis.;
							date&mois_vis.&i..SIN_ESTIMGB_OUTIL
					%End;

;
Run;

%Mend COMPIL_TABLE;
%COMPIL_TABLE

/*   !   *\

/* ajout nouvelle table NEMO a partir de 2025 */

proc sort data= SIN_ESTIMGB_OUTIL0 ;
by sin typ_estim no_estim_glb num_version ;
run;

data SIN_ESTIMGB_OUTIL;
set SIN_ESTIMGB_OUTIL0;
by sin typ_estim no_estim_glb num_version ;
if last.num_version;
where 
(
typ_estim in ('DDE') and 
TYP_DEV ='C' and 
(
(STATUT_ESTIM ne 'A' and typ_estim ne "NEMO") or (STATUT_ESTIM = 'T' and typ_estim = "NEMO")
)
);
run;

/* OUTIL DDE */

%Macro COMPIL_TABLE;

				Data SIN_OUTIL_DDE0; 
				Set
					%Do i=24 %To &annee_vis.;
							date&mois_vis.&i..SIN_OUTIL_DDE
					%End;

;
Run;

%Mend COMPIL_TABLE;
%COMPIL_TABLE

/*   !   *\

/* ajout nouvelle table NEMO a partir de 2025 */

proc sort data= SIN_OUTIL_DDE0 ;
by sin typ_estim no_estim_glb num_version ;
run;

data SIN_OUTIL_DDE;
set SIN_OUTIL_DDE0;
by sin typ_estim no_estim_glb num_version ;
if last.num_version;
where TYP_DEV ='C';
run;

data outil_DDEf;
set SIN_OUTIL_DDE0;

length TYPE_SURF2 $21. type_piece2 $15.;
	 if TYPE_PIECE = '2' then type_piece2 = 'Cuisine';
else if TYPE_PIECE = '0' then type_piece2 = 'Salle de bain';
else if TYPE_PIECE = '1' then type_piece2 = 'WC';
else if TYPE_PIECE = '3' then type_piece2 = 'Couloir';
else if TYPE_PIECE = '4' then type_piece2 = 'Chambre';
else if TYPE_PIECE = '5' then type_piece2 = 'Salle � manger';
else if TYPE_PIECE = '6' then type_piece2 = 'Salon';
else if TYPE_PIECE = '7' then type_piece2 = 'Bureau';
	 if TYPE_SURF = '2' then TYPE_SURF2 = 'Mur';
else if TYPE_SURF = '1' then TYPE_SURF2 = 'Plafond';
else if TYPE_SURF = '3' then TYPE_SURF2 = 'Peinture sur boiserie';
else if TYPE_SURF = '4' then TYPE_SURF2 = 'Sol';

run;

proc sql;

	create table /*temp.*/estimation_DC as
		select 		    case when month (&MOISSEUL.) in (4,6,9,11) then mdy(month (&MOISSEUL.),30,&annee.)	
				   		when month (&MOISSEUL.) = 2 and &annee. ne 2020	then mdy(month (&MOISSEUL.),28,&annee.)
				   		when month (&MOISSEUL.) = 2 and &annee. = 2020	then mdy(month (&MOISSEUL.),29,&annee.)
				   		else mdy(month (&MOISSEUL.),31,&annee.)
				   		end as DATE_OBS 		length = 4 format ddmmyy10.,
					   a.sin,
				       a.gtiesin,
					   b.typ_estim,  /* changement 08/11 */
				       a.no_estim_glb,
					   a.num_version,
					   a.typbenef,
					   a.refbenef,
					   a.NUMREG as NUMREG_ESTIM,
					   a.STATUT_ESTIM,
					   a.MT_TOT_NEGO,
					   a.MT_DEJA_TOT,
					   a.MT_PRCH_TOT,
					   a.COEF_REG,
					   b.TYPE_PIECE2,
					   b.TYPE_SURF2,
					   b.MT_MAT_PIECE,
					   b.MT_MO_PIECE,
					   b.IND_CAL_SUR,
					   case when b.MATERIAUX = 'P' then 'Peinture'
						    when b.MATERIAUX = 'EP' then "Entoilage/peinture"
						    when b.MATERIAUX = 'C' then 'Carrelage'
						    when b.MATERIAUX = 'L' then 'Lambris PVC ou bois'
						    when b.MATERIAUX = 'PP' then 'Papier peint'
						    when b.MATERIAUX = 'PFP' then 'Parquet flottant pos�'
						    when b.MATERIAUX = 'PLP' then 'Placoplatre'
						    when b.MATERIAUX = 'PM' then 'Parquet massif'
						    when b.MATERIAUX = 'PPE' then "Placo/peinture"
						    when b.MATERIAUX = 'PSB' then 'Peinture sur boiserie'
						    when b.MATERIAUX = 'RSC' then 'Rev�tement de sol coll�'
						    when b.MATERIAUX = 'RSP' then 'Rev�tement de sol pos�'
							when b.MATERIAUX = 'FC' then  'Fa�ence/carrelage'
					   else "" end as MATERIAUX2 format $50.,
					   b.SURFACE,
					   b.PERIMETRE,
					   b.UNIITE_MAT as UNITE_MAT,
					   b.MT_MAT_SURF,
					   b.MT_MO_SURF,
					   /* PIP 
					    Sol : Carrelage, Parquet Massif, Parquet flottant pos�
					   	Mur : fa�ence carrelage, Placopl�tre, placo/peinture
					    plafond : Placo/peinture */
					   /* Dans NEMO les PIP correspondent aux GAG avec un IMMO_INDEM_TOT > 0 */ 
					   case when b.MATERIAUX in ('C','PM','PLP','PFP','PPE','FC') then 1
					   else 0 end as TOP_PIP,
					   a.MTRECHFUITE
			from SIN_ESTIMGB_OUTIL as a
			inner join outil_DDEf as b
				on a.sin = b.sin and a.NO_ESTIM_GLB = b.NO_ESTIM_GLB and a.NUM_VERSION = b.NUM_VERSION;
quit;

/* -------------------------------------------------------------------------------- */
/* ETAPE 2 : Ajout des infos : Montant PIP - Surface totale - Nombre de pi�ces	    */
/* -------------------------------------------------------------------------------- */

/********* AJOUT DES INFOS PIP *********/

DATA estimation_DC2;
SET /*temp.*/estimation_DC;
VAR = trim(COMPRESS(SIN)||compress(no_estim_glb)||compress(num_version)||COMPRESS(type_piece2)||COMPRESS(SURFACE))||compress(num_version);
IF TOP_PIP = 1 THEN MT_TOT_PIP = (MT_MAT_SURF + MT_MO_SURF)*COEF_REG; ELSE MT_TOT_PIP = 0 ;
if TOP_PIP = 0 THEN MT_TOT_EMBEL_DC = (MT_MAT_SURF + MT_MO_SURF)*COEF_REG; ELSE MT_TOT_EMBEL_DC = 0 ;
RUN;

proc sort data=estimation_DC2; 
by VAR; 
run;
DATA estimation_DC2;
SET estimation_DC2;
BY VAR;
IF last.VAR THEN SURF_TOTALE = SURFACE ; ELSE SURF_TOTALE = " ";
IF last.VAR THEN NB_PIECE_TOTAL = 1 ; ELSE NB_PIECE_TOTAL = 0;
RUN;

/***** ETAPE INTERMEDIAIRE - CALCUL DU MONTANT PIP *****/ 

/* SANS REGLEMENT */
proc sort data=estimation_DC2 (where=(NUMREG_ESTIM = "000") 
							   keep = sin NO_ESTIM_GLB NUMREG_ESTIM NUM_VERSION MT_TOT_PIP COEF_REG MT_TOT_EMBEL_DC MTRECHFUITE) 
		   out= OUTILDC_SSRGT;
by sin no_estim_glb descending num_version;
run;

proc sql;
create table PIP_SSRG as 
	select distinct sin,		   
		   NO_ESTIM_GLB,
		   num_version,
		   sum(MT_TOT_PIP) as MT_PIP_DC ,
		   sum (MTRECHFUITE) as MTRECHFUITE_DC ,
		   sum (MT_TOT_EMBEL_DC) as MT_EMBELLISSEMENT_DC
from OUTILDC_SSRGT 
group by SIN,num_version
;
quit;
proc sort data=PIP_SSRG;
by sin descending num_version;

data PIP_SSRG2;
set PIP_SSRG;
by sin descending num_version;
if first.sin;
run;

/* Avec REGLEMENT */
proc sort data=estimation_DC2 (where=(NUMREG_ESTIM ne "000") keep=sin NO_ESTIM_GLB NUMREG_ESTIM NUM_VERSION MT_TOT_PIP COEF_REG MT_TOT_EMBEL_DC MTRECHFUITE) out= OUTILDC_AVRGT;
by sin no_estim_glb descending num_version;
run;
proc sql;
create table PIP_AVRG as 
	select distinct sin,		   
		   NO_ESTIM_GLB,
		   num_version,
		   sum(MT_TOT_PIP) as MT_PIP_DC ,
		   sum (MTRECHFUITE) as MTRECHFUITE_DC ,
		   sum (MT_TOT_EMBEL_DC) as MT_EMBELLISSEMENT_DC
from OUTILDC_AVRGT 
group by SIN
;
quit;

proc sort data=PIP_AVRG;
by sin descending num_version;

data PIP_AVRG2;
set PIP_AVRG;
by sin descending num_version;
if first.sin;
run;

/* s�lection de l'info pertinente DC */

proc sort data=PIP_AVRG2;
by sin;
proc sort data=PIP_SSRG2;
by sin;

data PIP_SSRG3;
merge PIP_SSRG2 (in=a)
	  PIP_AVRG2 (in=b);
by sin;
if a and not b;
run;

data PIP;
set PIP_AVRG2
	PIP_SSRG3;
run;

/****************** FIN D'ETAPE *******************/

PROC SQL;
create table estimation_DC3 as 
	select  a.sin, 
		    a.gtiesin,
			sum(a.SURF_TOTALE)/100 as SURFACE_TOTALE format best4.2, 
			sum(a.NB_PIECE_TOTAL) as NB_PIECE,
			b.MT_PIP_DC,
			b.MTRECHFUITE_DC,
			b.MT_EMBELLISSEMENT_DC
	from estimation_DC2 as a
	inner join PIP as b 
		on a.sin = b.sin and a.NO_ESTIM_GLB = b.NO_ESTIM_GLB and a.num_version = b.num_version
group by a.SIN;
QUIT; 

proc sort data=estimation_DC3 
NODUPKEY OUT = INFO_PIP; 
by SIN; 
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3 : Ajout des donn�es du nouveau mois d'observation � l'historique		    */
/* -------------------------------------------------------------------------------- */

/*PROC APPEND BASE = tables.estimation_DC 
			DATA = estimation_DC force; 
RUN;*/

/* -------------------------------------------------------------------------------- */
/* ETAPE 2 : RECUPERATION DES REGLEMENTS potentiellement faits depuis l'outil DC    */
/* -------------------------------------------------------------------------------- */

DATA REG_DDE;
SET histo2.archi_SIN_REG; /*(WHERE=(index(CPART,"DC")))*/;
IF &moisseul. > dtouv >= "01JUN18"d;
IF DTANN =.;
IF PRODUIT in ("NH",/*"MA",*/"HA","MR"/*,"MP"*/);
IF GTIESIN IN ("DDE","INC");
IF TYPEMONT IN ("PA") and modergl not in ('CV' 'CG' 'CS');
if typebenef in ("CP","IN","EN");
IF ETATGTIE NOT IN ("A");
RUN;

proc sql;
	create table reg_client as 
		select sin,
			   gtiesin,
				max(dtrg) as dtrgcp format ddmmyy10.,
			   sum(MTRGGTIE) as mt_total_cp,
			   count(MTRGGTIE) as nb_reg
		from REG_DDE
		where typebenef = "CP"
	group by 1,2;
quit;

/* -------------------------------------------------------------------------------- */
/* ETAPE 4 : rapprochement des r�glements avec les donn�es de l'outil DC		    */
/* -------------------------------------------------------------------------------- */
/* rapprochement avec outils DC */

proc sql;
	create table RGL_DC as	
		select distinct a.sin,
						a.gtiesin,
						a.no_estim_glb,
						a.num_version,
						a.typbenef,
						a.refbenef,
						a.NUMREG_ESTIM,			
				        b.dtrg,
					    b.MTRGGTIE

		from /*temp.*/ESTIMATION_DC as a
		inner join REG_DDE as b
			on a.sin = b.sin and a.gtiesin = b.gtiesin and a.NUMREG_ESTIM = b.NUMREG and a.typbenef = b.typebenef and a.refbenef = b.nobenef 
		where a.STATUT_ESTIM = 'R';
quit;

/* -------------------------------------------------------------------------------- */
/* ETAPE 5 : INTEGRATION AU DATAMART IRSI										    */
/* -------------------------------------------------------------------------------- */

proc sql;
create table temp.PERIMETRE_IRSIFFA6 as 
		select  a.*,
		        case when  index(a.cpart,'DC') > 0 and b.MTRGGTIE ne . 
					       and b.typbenef = 'CP' and a.no_estim_glb ne "" then b.dtrg
				when (index(a.cpart,'DC') > 0) and c.mt_total_cp  ne . 
					 and a.no_estim_glb ne "" then c.dtrgcp
				when index(a.cpart,'DC') > 0 and c.mt_total_cp ne . 
					 and a.no_estim_glb = "" then c.dtrgcp
				else c.dtrgcp end as dtrg_CP format ddmmyy10.,

				case when d.SURFACE_TOTALE ne . then d.SURFACE_TOTALE
				else 0 end as SURFACE_TOTALE,
			    case when d.MT_PIP_DC ne . then d.MT_PIP_DC
				else 0 end as MT_PIP_DC ,
				case when d.MTRECHFUITE_DC ne . then d.MTRECHFUITE_DC
				else 0 end as MTRECHFUITE_DC ,
				case when d.MT_EMBELLISSEMENT_DC ne . then d.MT_EMBELLISSEMENT_DC
				else 0 end as MT_EMBELLISSEMENT_DC ,
					case when d.NB_PIECE ne . then d.NB_PIECE
				else 0 end as NB_PIECE ,
			    case when (index(a.cpart,'DC') > 0) and b.MTRGGTIE  ne . 
						  and b.typbenef = 'CP' and a.no_estim_glb ne "" then 'O'
				when (index(a.cpart,'DC') > 0) and c.mt_total_cp  ne . 
					  and a.no_estim_glb ne "" then 'O'
				when (index(a.cpart,'DC') > 0) and c.mt_total_cp ne . 
					  and a.no_estim_glb = "" then 'O'
			    else 'N' end as GRE_A_GRE,
				case when c.sin ne "" then c.mt_total_cp
				when b.sin ne "" then b.MTRGGTIE
				else 0 end as mt_total_cp

		from temp.PERIMETRE_IRSIFFA5 as a 
		/* remonter les r�glements faits depuis l'outil DC */
		left join RGL_DC as b 
			on a.sin = b.sin 
			  and a.gtiesin = b.gtiesin 
			  and a.no_estim_glb = b.no_estim_glb
			  and a.num_version = b.num_version
			  and a.typbenef_ESTIM = b.typbenef
			  and a.REFBENEF_ESTIM = b.refbenef
			  and index(compress(a.LIST_NUMREG),b.NUMREG_ESTIM)
			  and b.typbenef = 'CP'

		/* remonter les r�glements clients quand CPART = DC mais pas de trace outil DC */
		left join reg_client as c
			on a.sin = c.sin 
			  and a.gtiesin = c.gtiesin 
			  /*and a.no_estim_glb = ""*/

		left join info_pip as d
			on a.sin = d.sin 
			and a.gtiesin = d.gtiesin 
			
		;
quit;

proc sort data = temp.PERIMETRE_IRSIFFA6 out= ssdoublons nodupkey dupout= doublons;
by sin gtiesin;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 6 : Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */
proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE6) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";

