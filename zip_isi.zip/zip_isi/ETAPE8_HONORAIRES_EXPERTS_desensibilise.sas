/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE8_HONORAIRES_EXPERTS.SAS							      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 27/02/2023												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION:																	  */
/* Afin de suivre l'impact de la convention IRSI qui s'applique sur les sinistres */
/* en habitation (NH, HA,MR),en PRO (MP) et en AGRI (MA) avec la garantie DDE ou  */
/* INC (hors ELEC et INC sinistr�es simultan�ment), nous construisons un datamart.*/
/* Ce dernier contient le p�rim�tre suivant :									  */
/* 			- Sinistres survenus depuis 01/06/2018								  */
/*			- hors les sinistres annul�s										  */
/*			- avec la garantie DDE et/ou INC non annul�							  */
/*			- pour les produits NH, HA, MR, MP, MA								  */
/*			- Aucun sinistre DDE ou INC ne sera ouvert en pr�d�claration		  */
/* ------------------------------------------------------------------------------ */
/* MODIFICATIONS																  */
/* NOV	2019|	| - changement du chemin pour le r�f�rentiel des experts DARVA	  */
/* ------------------------------------------------------------------------------ */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));

option nofmterr;
option  compress = yes;

/* -------------------------------------------------------------------------------- */
/* ETAPE 1: R�cup�ration du r�f�rentiel des cabinets d'expert					  	*/
/* -------------------------------------------------------------------------------- */
proc import datafile = "\\bureautique.ca-pacifica.fr\bureautique\DSIN\POLORGA\EP\02-Productions r�currentes\03-MENS\06-Suivis techniques\02-Documentation\REF_EXPERTS_DARVANA_V2.xlsx"
			out = REF_EXPERT
			dbms = xlsx replace ; 
			sheet = "REF_EXPERT" ; 
run ;

/* -------------------------------------------------------------------------------- */
/* ETAPE 2: R�cup�ration des r�glements faits aux experts DARVA					  */
/* -------------------------------------------------------------------------------- */

proc sql;
	create table reglement_expert as 
				select a.sin,
					   a.produit,
					   a.gtiesin,
					   a.dtrg,
					   case when a.typemont = 'RE' then -a.mtrggtie
					   else a.mtrggtie end as reg,
					   month(a.dtrg) as moisreg,
					   year(a.dtrg) as anneereg,
					   case when a.iniemet = 'SCT' then 'O'
					  else 'N' end as rgautoEX,
					  a.refbenef as expert,
					  case when compress(a.refbenef)=compress(b.code_ce) and c.nouv_code_ce = "" then b.expert
				   	  when compress(a.refbenef)=compress(b.code_ce) and c.nouv_code_ce ne "" then c.expert
				      when compress(a.refbenef)=compress(c.nouv_code_ce) and b.code_ce = "" then c.expert
				      else a.refbenef end as groupe
			from histo2.archi_SIN_REG as a
				left join REF_EXPERT as b
			 on compress(a.refbenef)=compress(b.code_ce)
			 left join REF_EXPERT as c
			 on compress(a.refbenef) = compress(c.nouv_code_ce)

			where a.PRODUIT in ("NH",/*"MA",*/"HA","MR"/*,"MP"*/) 
				and a.DTANN = . 
				and a.typebenef = "EX"
				and a.profexp in ('NA')
				and a.typemont in ('RE' 'PA')
				and a.modergl not in ('CV' 'CG' 'CS')
				and &MOISSEUL.> a.dtouv >= "01JAN17"d
;

quit;

proc sort data = reglement_expert; 
by sin gtiesin expert dtrg;
run;

data reglement_expert2;
 set reglement_expert  ;
by sin gtiesin expert dtrg;
length NB_REG_EXP 8. MONTANT_REG_EXP 8  experts groupe2 $100;
retain NB_REG_EXP MONTANT_REG_EXP experts groupe2;
if first.gtiesin then do;
	NB_REG_EXP = 1;
	MONTANT_REG_EXP = reg;
	experts = expert;
	groupe2=groupe;
end;
else do;
		NB_REG_EXP = NB_REG_EXP +1;
		MONTANT_REG_EXP = MONTANT_REG_EXP + reg;
			  if index (experts,expert) = 0 then experts = trim(experts)||'/'||expert;
			   else if index (experts,expert) > 0 then experts = experts;
			 if index (groupe2,groupe) = 0 then groupe2 = trim(groupe2)||'/'||groupe;
			  else if index (groupe2,groupe) > 0 then groupe2 = groupe2;
end;
if last.gtiesin;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3: Rapprochement avec les donn�es sinistres de  l'�tape 2				  */
/* -------------------------------------------------------------------------------- */

proc sql;
		create table temp.PERIMETRE_IRSIFFA8 as 
			select a.*,
				   b.dtrg as dernier_regexp,
				   b.NB_REG_EXP,
				   b.MONTANT_REG_EXP,
				   b.experts as expertreg,
				   b.groupe2 as grpexptreg

			from  temp.PERIMETRE_IRSIFFA7 as a
			left join reglement_expert2 as b
				on a.sin = b.sin and a.gtiesin = b.gtiesin;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE8) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";
