/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE3_MISSION_EXPERT.SAS								      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 27/02/2023												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION:																	  */
/* Afin de suivre l'impact de la convention IRSI qui s'applique sur les sinistres */
/* en habitation (NH,HA,MR),en PRO (MP) et en AGRI (MA) avec la garantie DDE ou   */
/* INC (hors ELEC et INC sinistr�es simultan�ment), nous construisons un datamart.*/
/* Ce dernier contient le p�rim�tre suivant :									  */
/* 			- Sinistres survenus depuis 01/06/2018								  */
/*			- hors les sinistres annul�s										  */
/*			- avec la garantie DDE et/ou INC non annul�							  */
/*			- pour les produits NH, HA, MR, MP, MA								  */
/*			- Aucun sinistre DDE ou INC ne sera ouvert en pr�d�claration		  */
/* Dans ce programme, nous r�cup�rons toutes les missions DARVA avec la garantie  */
/* DDE ou INC missionn�e.														  */
/* ------------------------------------------------------------------------------ */
/* MODIFICATIONS																  */
/* NOV	2019|	| - changement du chemin pour le r�f�rentiel des experts DARVA	  */
/* ------------------------------------------------------------------------------ */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;

/* -------------------------------------------------------------------------------- */
/* ETAPE 1: R�cup�ration du r�f�rentiel des cabinets d'expert					  */
/* -------------------------------------------------------------------------------- */
proc import datafile = "\\bureautique.ca-pacifica.fr\bureautique\DSIN\POLORGA\EP\02-Productions r�currentes\03-MENS\06-Suivis techniques\02-Documentation\REF_EXPERTS_DARVANA_V2.xlsx"
			out = REF_EXPERT
			dbms = xlsx replace ; 
			sheet = "REF_EXPERT" ; 
run ;

/* -------------------------------------------------------------------------------- */
/* ETAPE 2: R�cup�ration des missions envoy�es									  */
/* -------------------------------------------------------------------------------- */

/*%LET annee_vis=25;  
%LET mois_vis=12;*/

%Macro COMPIL_TABLE;

				Data sin_omt; 
				Set
					%Do i=24 %To &annee_vis.;
							date&mois_vis.&i..sin_omt
					%End;

;
Run;

%Mend COMPIL_TABLE;
%COMPIL_TABLE

proc sort data=sin_omt;
by sin NUMORDREMISS descending DTREF DTOM;
run;

data sin_omt1;
set sin_omt;
by sin NUMORDREMISS descending DTREF DTOM;
if first.NUMORDREMISS;
run;

proc sql;
		create table MISSION as 
			select case when month (&MOISSEUL.) in (4,6,9,11) then mdy(month (&MOISSEUL.),30,&annee.)	
				   when month (&MOISSEUL.) = 2 and &annee. ne 2020	then mdy(month (&MOISSEUL.),28,&annee.)
				   when month (&MOISSEUL.) = 2 and &annee. = 2020	then mdy(month (&MOISSEUL.),29,&annee.)
				   else mdy(month (&MOISSEUL.),31,&annee.)
				   end as DATE_OBS 		length = 4 format ddmmyy10.,
				   a.SIN,
				   a.contrat,
				   formule,
				   month(a.dtom) as moismiss,
				   year(a.dtom) as anneemiss,
			       a.PRODUIT,
				   a.GTIEOMT,			       
				   a.NUMORDREMISS,
				   a.DTOM,
				   a.ETATOMT,
				   a.EXPERT,
				   case when a.expert=b.code_ce  then b.expert
				   
				   when a.expert=c.nouv_code_ce  then c.expert
				   else a.expert end as groupe,
				   a.SPECIALITE_MP, 
				   a.SPECIALITE_NA,
				   a.TYPE_MISSION,
				   a.NOMDEST,
				   a.RGAUTO,	 
				   a.initiale,
				   a.UGS

            from sin_omt1 as a
			left join REF_EXPERT as b
			 on a.expert=b.code_ce
			 left join REF_EXPERT as c
			 on a.expert=c.nouv_code_ce and c.nouv_code_ce ne ""
			where a.ETATOMT ne 'A' and &MOISSEUL. > a.DTSURV > "01JAN2017"d
			and a.PRODUIT in ("NH",/*"MA",*/"HA","MR"/*,"MP","M9"*/) and a.type in ("DARVA","SINAP")
			and (index(GTIEOMT,"DDE") > 0 or
				 index(GTIEOMT,"INC") > 0);
quit;

proc sort data = MISSION; 
by sin numordremiss DTOM;
run;

data mission2;
set  MISSION; 
by sin numordremiss DTOM;
retain missionsexpert NOM_EXPERTS CABINETS_EXPERT nb_mission;
length missionsexpert NOM_EXPERTS $70. CABINETS_EXPERT $100.;
if first.sin then do;
					missionsexpert = numordremiss;
					NOM_EXPERTS = EXPERT;
					CABINETS_EXPERT = GROUPE;
					nb_mission = 1;
				  end;
else do;
		missionsexpert = trim(compress(missionsexpert)||"/"||compress(numordremiss));
		if index ( NOM_EXPERTS,EXPERT) > 0 and EXPERT ne "" then NOM_EXPERTS = EXPERT;
		else 	NOM_EXPERTS = trim(compress(NOM_EXPERTS)||"/"||compress(EXPERT));
		if index ( CABINETS_EXPERT,GROUPE) > 0 and GROUPE ne "" then CABINETS_EXPERT = CABINETS_EXPERT;
		else 	CABINETS_EXPERT = trim(compress(CABINETS_EXPERT)||"/"||compress(GROUPE));
		nb_mission =nb_mission+1;
	end;
if last.sin;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3: Rapprochement avec les donn�es sinistres de  l'�tape 2				    */
/* -------------------------------------------------------------------------------- */

proc sql;
		create table temp.PERIMETRE_IRSI_ETAPE3 as 
			select a.*,
				   b.dtom,
				   b.NUMORDREMISS,
				   b.missionsexpert,
				   b.NOM_EXPERTS,
				   b.CABINETS_EXPERT,
				   b.nb_mission

			from  temp.PERIMETRE_IRSI_ETAPE2 as a
			left join mission2 as b
				on a.sin = b.sin;
quit;

proc sort data=temp.PERIMETRE_IRSI_ETAPE3 out=dd nodupkey;
by _all_;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 4 : Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */
proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE3) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";