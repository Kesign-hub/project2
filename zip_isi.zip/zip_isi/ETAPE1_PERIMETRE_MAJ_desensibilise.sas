/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE1_PERIMETRE_MAJ.SAS								      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 27/02/2023												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION:																	  */
/* Afin de suivre l'impact de la convention IRSI qui s'applique sur les sinistres */
/* en habitation (NH, HA,MR),en PRO (MP) et en AGRI (MA) avec la garantie DDE ou  */
/* INC (hors ELEC et INC sinistr�es simultan�ment), nous construisons un datamart.*/
/* Ce dernier contient le p�rim�tre suivant :									  */
/* 			- Sinistres survenus depuis 01/01/2017 jusqu'au 31/12/2022			  */
/*			- hors les sinistres annul�s										  */
/*			- avec la garantie DDE et/ou INC non annul�							  */
/*			- pour les produits NH, HA, MR, MP, MA								  */
/*			- Aucun sinistre DDE ou INC ne sera ouvert en pr�d�claration		  */
/* Le principe est d'ajouter chaque mois les donn�es vision fin du mois pr�c�dent */
/* ------------------------------------------------------------------------------ */
/* MODIFICATIONS:																  */
/* NOV 2018|		|- apr�s �change avec la DPART, nous ne remontons plus les 	  */
/*					   donn�es qualit� et type de batiment pour les sinistres MA  */
/*					   cette information ne leur est pas utile pour les �vol	  */
/*					   tarifaires. Pour le suivi des sinistres, l'information     */
/*					   n'est pas exploitable.									  */
/* DEC 2018|		|- Mise en place des nouvelles r�gles de gestion pour la	  */
/*					   variable FLAG_IRSI										  */
/* JAN 2019|		|- R�vision de la d�finition du FLAG_IRSI suite au point du	  */
/*					   22 Janvier 2019 avec les RTN Habitation.					  */
/* MAR 2019|		|-  Ajout des donn�escontrats MRA et AFIARD avant migration   */
/* OCT 2019|		| - Ajout UGS et INITIALE									  */
/* MAR 2020|		| - Ajout du lieu du sinistre								  */
/* ------------------------------------------------------------------------------ */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;

/* -------------------------------------------------------------------------------- */
/* ETAPE 1 : R�cup�ration des sinistres r�pondants � notre p�rim�tre			  */
/* -------------------------------------------------------------------------------- */

proc sql;
		
			create table temp.PERIMETRE_IRSIFFA	as 
					select case when month (&MOISSEUL.) in (4,6,9,11) then mdy(month (&MOISSEUL.),30,&annee.)	
								when month (&MOISSEUL.) = 2 and &annee. ne 2020	then mdy(month (&MOISSEUL.),28,&annee.)
								when month (&MOISSEUL.) = 2 and &annee. = 2020	then mdy(month (&MOISSEUL.),29,&annee.)
						   else mdy(month (&MOISSEUL.),31,&annee.)
						   end as DTREF 										length = 4 format ddmmyy10.,
							a.sin,
					        a.produit,
							a.formule,
						    a.dtsurv  format ddmmyy10.,
							a.dtouv   format ddmmyy10.,
							a.dtreouv format ddmmyy10.,
							a.dtclos  format ddmmyy10.,
							a.etatsin,
							b.gtiesin,
							b.etatgtie,
							a.cconv,
							a.bareme,							
						    a.GARANTIE_NON_ANNULE,							
							/* DDE */
							case when a.cconv = "IRSI" and b.gtiesin = "DDE" then "IRSI"
							when a.cconv = "CICO" then "CICOP"
							when a.cconv = "AUTR" and b.gtiesin = "DDE" then "HORS CONVENTIONS"							
							when a.etatsin in ("C","S") and a.cconv = "" and b.RPCORG + b.RFCORG <= 5500 and b.gtiesin = "DDE"  
								and  not (calculated qualite = "PRO" and (calculated HABITAT = "M" and a.produit not in ("MP" "M9"))) then "POTENTIEL IRSI"
							when a.etatsin in ("C","S") and a.cconv = "" and b.RPCORG + b.RFCORG > 5500 and b.gtiesin = "DDE"
								and not (calculated qualite = "PRO" and (calculated HABITAT = "M" and a.produit not in ("MP" "M9"))) then "NON RENSEIGNE"
							when a.etatsin in ("E","R","T") and a.cconv = "" and b.gtiesin = "DDE" 
								and not (calculated qualite = "PRO" and (calculated HABITAT = "M" and a.produit not in ("MP" "M9"))) then "POTENTIEL IRSI"
							/* INC */
							when a.cconv = "IRSI" and b.gtiesin = "INC" then "IRSI"
							when a.cconv = "AUTR" and b.gtiesin = "INC" then "AUTRES CONVENTIONS"
							when (index ( a.GARANTIE_NON_ANNULE,'INC')> 0 
								 and index ( a.GARANTIE_NON_ANNULE,'ELEC')> 0 ) and b.gtiesin = "INC" then "HORS CONVENTIONS"
							when a.etatsin in ("C","S") and  a.cconv = "" and b.gtiesin = "INC" and not (index ( a.GARANTIE_NON_ANNULE,'INC')> 0 
								 and index ( a.GARANTIE_NON_ANNULE,'ELEC')> 0 )and b.RPCORG + b.RFCORG <= 5500
								 and not (calculated qualite = "PRO" and (calculated HABITAT = "M" and a.produit not in ("MP" "M9"))) then "POTENTIEL IRSI"
							when a.etatsin in ("C","S") and  a.cconv = "" and b.gtiesin = "INC" and not (index ( a.GARANTIE_NON_ANNULE,'INC')> 0 
								 and index ( a.GARANTIE_NON_ANNULE,'ELEC')> 0 )and b.RPCORG + b.RFCORG > 5500 
								 and not (calculated qualite = "PRO" and (calculated HABITAT = "M" and a.produit not in ("MP" "M9"))) then "NON RENSEIGNE"
							when a.etatsin  in ("E","R","T") and  a.cconv = "" and b.gtiesin = "INC" and not (index ( a.GARANTIE_NON_ANNULE,'INC')> 0 
								 and index ( a.GARANTIE_NON_ANNULE,'ELEC')> 0 )and b.RPCORG + b.RFCORG <= 5500
								 and not (calculated qualite = "PRO" and (calculated HABITAT = "M" and a.produit not in ("MP" "M9"))) then "POTENTIEL IRSI"
							when a.etatsin in ("E","R","T") and  a.cconv = "" and b.gtiesin = "INC" and not (index ( a.GARANTIE_NON_ANNULE,'INC')> 0 
								 and index ( a.GARANTIE_NON_ANNULE,'ELEC')> 0 )and b.RPCORG + b.RFCORG > 5500 
								 and not (calculated qualite = "PRO" and (calculated HABITAT = "M" and a.produit not in ("MP" "M9")))then "HORS CONVENTIONS"
							/* Pour les propri�taires de Maisons */
						    when calculated qualite = "PRO" and (calculated HABITAT = "M" and a.produit not in ("MP" "M9")) then "HORS CONVENTIONS"
							else "NON RENSEIGNE" end as FLAG_IRSI format $40.,
							case when a.contrat = c.contrat and a.image = c.image and c.contrat ne '' then c.qualite
							when a.contrat = d.contrat and a.image = d.image and d.contrat ne '' then d.qualite
							when a.contrat = e.contrat and a.image = e.image and e.contrat ne '' then e.qualite
							when a.contrat = f.contrat and a.image = f.image and f.contrat ne '' then f.qualite
	/*						when a.contrat = g.contrat and a.image = g.image and g.contrat ne '' then g.qualite*/
							when a.contrat = h.contrat and a.image = h.image and h.contrat ne '' then h.qualite
							else "" end as qualite,
							case when a.contrat = c.contrat and a.image = c.image and c.contrat ne '' then c.habitat
							when a.contrat = d.contrat and a.image = d.image and d.contrat ne '' then d.habitat
							when a.contrat = e.contrat and a.image = e.image and d.contrat ne '' then e.habitat
	/*						when a.contrat = g.contrat and a.image = g.image and g.contrat ne '' then g.TYPBAT */
							when a.contrat = f.contrat and a.image = f.image and f.contrat ne '' then f.habitat 
							when a.contrat = h.contrat and a.image = h.image and h.contrat ne '' then h.habitat 
							else "" end as HABITAT length = 20,
							b.evr  as evr_gtiesin,
							b.evrr as evrr_gtiesin,
							a.evr  as evr_sin,
							a.evrr as evrr_sin,	
							b.RPCORG as RPCORG_GTIESIN,
							b.RFCORG as RFCORG_GTIESIN,	
							a.cpart,
							a.recours,
							a.topmh,
							a.UGS,
							a.initiale,
							a.lieu,
							substr(a.lieu,1,2) as depsin

					from histo2.archi_sin_dgl as a
					inner join   histo2.archi_sin_gtie as b
					    on a.sin = b.sin
					left join temp2.MVTPRMH as c
						on a.contrat = c.contrat and a.image = c.image 
					left join temp2.MVTPRHA as d
						on a.contrat = d.contrat and a.image = d.image
					left join temp2.mvtprmr as e
					    on a.contrat = e.contrat and a.image = e.image 
/*					left join temp2.mvtprmp as g
					    on a.contrat = g.contrat and a.image = g.image*/
					left join temp2.mvtprmh_mra as f
						on a.contrat = f.contrat and a.image = f.image
					left join temp2.mvtprmh_af as h
						on a.contrat = h.contrat and a.image = h.image

						
					where a.etatsin ne 'A' 
					and &MOISSEUL. > a.dtsurv > "01JAN2017"d
					and a.produit in ("NH",/*"MA",*/"HA","MR"/*,"MP"*/) /* On ne prend pas les pros donc pas M9 */
					and b.gtiesin in ('DDE','INC') 
					and b.etatgtie ne 'A'
;
quit;

proc sort data=temp.PERIMETRE_IRSIFFA nodupkey out=dd;
by sin gtiesin;
run;

proc freq data=temp.PERIMETRE_IRSIFFA (where=(qualite = "PRO" and HABITAT = "M" and produit ne "MP" ));
tables gtiesin*cconv*FLAG_IRSI/list missing;
run;


proc freq data = temp.PERIMETRE_IRSIFFA (where=(index (GARANTIE_NON_ANNULE,'INC')> 0 
								 					  and index (GARANTIE_NON_ANNULE,'ELEC')> 0));
tables gtiesin*cconv*FLAG_IRSI/list missing;
run;

proc freq data = temp.PERIMETRE_IRSIFFA/* (where=(index (GARANTIES_NON_ANNULE,'INC')> 0 
								 					  and index (GARANTIES_NON_ANNULE,'ELEC')> 0))*/;
tables gtiesin*cconv*FLAG_IRSI/list missing;
run;


proc sort data = TEMP.PERIMETRE_IRSIFFA nodupkey out =  ss_dd dupout= doublons;
by sin GARANTIE_NON_ANNULE gtiesin;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3 : Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */
proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE1) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";

/* les vides */
proc freq data = temp.PERIMETRE_IRSIFFA/* (where=(index (GARANTIES_NON_ANNULE,'INC')> 0 
								 					  and index (GARANTIES_NON_ANNULE,'ELEC')> 0))*/;
tables HABITAT qualite/list missing;
run;

data vide;
set temp.PERIMETRE_IRSIFFA (where=(HABITAT=""));
run;

proc freq data= vide;
tables dtclos produit/list missing;
run;

proc freq data = temp.PERIMETRE_IRSIFFA(where=(produit ='MR' and HABITAT=""));
tables dtclos/list missing;
run;

data temp.PERIMETRE_IRSIFFA;
set temp.PERIMETRE_IRSIFFA;
if dtref="31JAN2026"d then dtref="31DEC2025"d;
run;

proc sort nodupkey data=temp.PERIMETRE_IRSIFFA;
by _all_;
run;
*/