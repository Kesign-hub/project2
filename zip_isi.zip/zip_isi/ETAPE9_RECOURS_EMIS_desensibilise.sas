/* -------------------------------------------------------------------------------- */
/* NOM DU PROGRAMME : ETAPE9_RECOURS_EMIS.SAS								        */
/*																				    */
/* AUTEUR			: CM														    */
/*																				    */
/* DATE				: 27/02/2023												    */
/*																				    */
/* -------------------------------------------------------------------------------- */
/* DESCRIPTION :																    */
/* Rajouter les donn�es li�es aux encaissements re�us des compagnies adverses 		*/ 
/* 																					*/
/* -------------------------------------------------------------------------------- */
/* MODIFICATION:																	*/
/* OCTOBRE 2019 : Suppression du regroupement des garanties et jointure avec la		*/
/*				  table via les variables SIN et GTIESIN							*/
/* -------------------------------------------------------------------------------- */

%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;

/* -------------------------------------------------------------------------------- */
/* ETAPE 1 : INTEGRATION DES REGLEMENTS 										    */
/* -------------------------------------------------------------------------------- */

DATA ENC_DDE;
SET histo2.archi_SIN_REG;
IF &MOISSEUL. > DTOUV >= "01JAN17"d;
IF DTANN = .;
IF PRODUIT in ("NH",/*"MA",*/"HA","MR"/*,"MP"*/);
IF GTIESIN IN ("DDE","INC");
IF TYPEMONT IN ("RE") and modergl not in ('CV' 'CG' 'CS');
IF ETATGTIE NOT IN ("A");
IF TYPEBENEF IN ("CI");
RUN;

/* je ne fais pas tourner le reste du programme le 01 aout 2018 */
proc sort data = ENC_DDE; 
by SIN produit gtiesin DTRG; 
run;

data encais_CI;
set ENC_DDE ;
by SIN produit gtiesin DTRG; 
/*format GARANTIE $100.;*/
retain /*GARANTIE*/ enc_CI;
if first.gtiesin  then /*do;
							GARANTIE = gtiesin;*/
							enc_CI = MTRGGTIE;
				/*	end;*/
else /*do;
			GARANTIE = trim(GARANTIE)||"/"||GTIESIN;*/
			enc_CI = enc_CI+ MTRGGTIE;
/*end;*/
if last.gtiesin;
keep sin produit gtiesin DTRG etatgtie enc_CI;

run;

proc sort data = encais_CI nodupkey out=ssdd dupout=dbl;
by sin gtiesin;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 2 : INTEGRATION AU DATAMART IRSI									  	    */
/* -------------------------------------------------------------------------------- */

proc sql;
create table temp.PERIMETRE_IRSIFFA9 as 
select a.*,
	   b.enc_CI,
	   b.DTRG as DATEDERN_enc_CIE

from temp.PERIMETRE_IRSIFFA8 as a 
left join encais_CI as b 
on a.sin = b.sin and a.gtiesin = b.gtiesin ;
quit;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3 : Lib�ration de l'espace work										    */
/* -------------------------------------------------------------------------------- */
proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE9) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";