/* ------------------------------------------------------------------------------ */
/* NOM DU PROGRAMME : ETAPE12_RDF_REN.SAS									      */
/*																				  */
/* AUTEUR			: CM														  */
/*																				  */
/* DATE				: 17/03/2023												  */
/*																				  */
/* ------------------------------------------------------------------------------ */
/* DESCRIPTION:																	  */
/* r�cup�ration de l'ensemble des factures RDF des RENEURS Re�us depuis 2019 	  */
/* ------------------------------------------------------------------------------ */
%let temps_debut = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
option nofmterr;
option  compress = yes;

%let annee_vis= 25;
%let an0=25;
%let an3= 25;
%let an= 25;
%let mois= 12;

%macro RDF   (out  	  = , 
					librairie = ,
					mois	  = 
					
					);
%if %sysfunc (exist (&librairie..&out.)) %then %do;
	  proc datasets library = &librairie. nolist; delete &out; quit;
	%end;

%do i = &an3. %to &annee_vis.;

    title;
        footnote;

                %put %str(=====================================================================);
                %put %str(                       )Etape &i: DATE&&mois.&&an&i..	 				;
                %put %str(=====================================================================);
/* Extraction des r�glements � un partenaire REN rattach�es aux sinistres du p�rim�tre de l'analyse de co�ts */
proc sql;
		create table &out&i as 
				select a.sin,
				       a.NUMFACT,
					   a.DTFACT,
					   a.TYPFACT,
					   a.REFFOUR,
					   a.TVAFACT,
					   a.TOTBRUT,
					   a.TOTRECLI,
					   a.NETAPAY,
					   b.NATURE

				from DATE0&mois.&i..SIN_FOUR as a
							inner join DATE0&mois.&i..SIN_DET_FOUR as b
							  on a.sin = b.sin and a.NUMFACT = b.NUMFACT

				where b.NATURE in ("RECH DE FUITE","RECH. DE FUITE") and index(a.GTIE,"DDE") and a.PRODUIT in ("NH",/*"MA",*/"HA","MR"/*,"MP"*/)

						; 
quit;

			PROC APPEND BASE = &librairie..&out 
						DATA = &out&i; 
			RUN;

	   		PROC DELETE data = &out&i; 
			RUN;

%end;

%mend;

%RDF (out  			= reg_RDF_V2,
			  librairie = tables,
			  mois		= 1
			);

proc sort data= tables.reg_RDF_V2 nodupkey out=reg_RDF_V2;
by _all_;
run;

proc sort data= reg_RDF_V2;
by sin NUMFACT;
run;

 /* 20/01/2023 : pour SPEB il fau faire NETAPAY-TOTRECLI */
data reg_RDF_V3;
set reg_RDF_V2;
by sin NUMFACT;
retain nbintervention MTRDF TOTRECLI1;
if first.sin then do;
					 if REFFOUR='SPEB' then do;
									nbintervention = 1;
									 MTRDF = NETAPAY-TOTRECLI;
									 TOTRECLI1= TOTRECLI;
								  end;
					 else do;
					 		nbintervention = 1;
							MTRDF = NETAPAY;
							TOTRECLI1= TOTRECLI;
						  end;
				 end;
else do;
	if REFFOUR='SPEB' then do;
							nbintervention = nbintervention+1;
							MTRDF = MTRDF+NETAPAY-TOTRECLI;
							TOTRECLI1 =TOTRECLI1+TOTRECLI;
						   end;
else do;
		nbintervention = nbintervention+1;
		MTRDF = MTRDF+NETAPAY;
		TOTRECLI1 =TOTRECLI1+TOTRECLI;
		end;
end;
if last.sin;
run;

/* -------------------------------------------------------------------------------- */
/* ETAPE 2: ajout des informations relatives � la recherche de fuite				*/
/* -------------------------------------------------------------------------------- */
proc sql;
create table tables.DM_IRSI_FFA20&an0. as 
select a.*,
	   b.nbintervention,
	   b.MTRDF

from tables.DM_IRSI_FFA20&an0. as a  /* R�mi f�v 26 => tables.DM_IRSI_V2_FFA20&an. ??? */ /* tables.DM_IRSI_FFA20&an. cr�� dans le pgm 10 */
left join reg_RDF_V3 as b 
on a.sin =b.sin ;
quit;

/* -------------------------------------------------------------------------------- */
/* ETAPE 3: Lib�ration de l'espace work											    */
/* -------------------------------------------------------------------------------- */

proc datasets library = work 
kill;
quit;

%let temps_fin = %sysevalf(%sysfunc(today())*86400 + %sysfunc(time()));
%let duree     = %sysevalf(&temps_fin. - &temps_debut. );

%put "DUREE DE TRATEMENT (ETAPE12) : %sysfunc(round(%sysevalf(&duree./60),0.01)) minutes ";

proc freq data=tables.DM_IRSI_FFA20&an0. (where=(nbintervention ne .));
tables gtiesin/list missing;
run;

data controle;
set tables.DM_IRSI_FFA20&an. (where=(nbintervention ne . and gtiesin ='INC'));
run;
/* la garantie INC est li�e � des d�g�ts �lectriques */