#!/usr/bin/env python3
"""Copie contrôlée selon le plan; fichiers non classés copiés en archives à vérifier. Simulation par défaut; aucune suppression des sources.
Python 3.9+, bibliothèque standard. Les liens dans les programmes ne sont pas réécrits.
"""
import argparse
import collections
import csv
import hashlib
import json
import os
import shutil
import stat
import uuid
from datetime import datetime
from pathlib import Path, PureWindowsPath

BLOCK=4*1024*1024
MARKER='.organisation_pacifica.json'


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(BLOCK),b''):h.update(chunk)
    return h.hexdigest()


def relative_parts(value):
    p=PureWindowsPath(value)
    if not value or p.is_absolute() or p.drive or any(x in ('..','.') or ':' in x for x in p.parts):
        raise ValueError(f'Chemin relatif invalide: {value}')
    return p.parts


def no_links(root,parts):
    p=root
    for part in (None,)+tuple(parts):
        if part is not None:p=p/part
        if p.exists() or p.is_symlink():
            st=p.lstat()
            if stat.S_ISLNK(st.st_mode) or getattr(st,'st_file_attributes',0)&1024:
                raise ValueError(f'Lien/jonction non parcouru: {p}')
    return p


def fingerprint(st):return st.st_size,st.st_mtime_ns,st.st_ctime_ns


def metadata_matches(path,row):
    st=path.stat()
    if not stat.S_ISREG(st.st_mode):raise ValueError('La source n’est pas un fichier régulier')
    if st.st_size!=int(row['Taille_octets']):raise ValueError('Taille source modifiée depuis l’inventaire: actualiser le plan')
    expected=row.get('Derniere_modification','').strip()
    if expected:
        dt=datetime.fromisoformat(expected)
        actual=datetime.fromtimestamp(st.st_mtime,dt.tzinfo).replace(microsecond=0)
        if actual!=dt.replace(microsecond=0):raise ValueError('Date source modifiée depuis l’inventaire: actualiser le plan')
    return st


def publish(temp,target):
    # Windows rename refuses to replace an existing file. POSIX link is exclusive.
    if os.name=='nt':os.rename(temp,target)
    else:
        os.link(temp,target)
        temp.unlink()


def copy_verified(source,target,row):
    before=metadata_matches(source,row)
    if target.exists() or target.is_symlink():
        if not target.is_file() or target.is_symlink():raise FileExistsError('Destination existante incompatible')
        if source.samefile(target):raise ValueError('Source et destination désignent le même fichier')
        if target.stat().st_size!=before.st_size:raise FileExistsError('Destination différente: aucun écrasement')
        source_hash=digest(source);target_hash=digest(target)
        if fingerprint(source.stat())!=fingerprint(before):raise ValueError('Source modifiée pendant le contrôle')
        if source_hash!=target_hash:raise FileExistsError('Destination différente: aucun écrasement')
        return 'DEJA_IDENTIQUE',source_hash,target_hash
    target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_name('.pacifica_'+uuid.uuid4().hex+'.part')
    try:
        h=hashlib.sha256()
        with source.open('rb') as src,temp.open('xb') as dst:
            for chunk in iter(lambda:src.read(BLOCK),b''):
                dst.write(chunk);h.update(chunk)
            dst.flush();os.fsync(dst.fileno())
        if fingerprint(source.stat())!=fingerprint(before):raise ValueError('Source modifiée pendant la copie')
        copied=digest(temp)
        if temp.stat().st_size!=before.st_size or copied!=h.hexdigest():raise IOError('Vérification SHA-256 de la copie échouée')
        if fingerprint(source.stat())!=fingerprint(before):raise ValueError('Source modifiée pendant la vérification de la copie')
        shutil.copystat(source,temp,follow_symlinks=False)
        publish(temp,target)
        return 'COPIE_VERIFIEE',h.hexdigest(),copied
    finally:
        # Uniquement le temporaire créé par cette opération, jamais une source ou un fichier préexistant.
        if temp.exists():temp.unlink()


def load_plan(path):
    with path.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f,delimiter=';'))
    required={'ID','Action','Chemin_source_relatif','Chemin_cible_relatif','Taille_octets','Domaine','Circuit'}
    if not rows or not required<=rows[0].keys():raise ValueError('Plan vide ou colonnes attendues absentes')
    if len({r['ID'] for r in rows})!=len(rows):raise ValueError('ID dupliqué dans le plan')
    for r in rows:
        relative_parts(r['Chemin_source_relatif'])
        if r['Action'] not in ('COPIER','SIGNALER'):raise ValueError('Action inconnue dans le plan')
        if r['Action']=='COPIER':relative_parts(r['Chemin_cible_relatif']);int(r['Taille_octets'])
    # Aucun membre d’une collision n’est copié, y compris sur un système sensible à la casse.
    targets=collections.defaultdict(list);sources=collections.defaultdict(list)
    for r in rows:
        if r['Action']=='COPIER':
            targets[str(PureWindowsPath(r['Chemin_cible_relatif'])).casefold()].append(r)
            sources[str(PureWindowsPath(r['Chemin_source_relatif'])).casefold()].append(r)
    blocked=set()
    for group in list(targets.values())+list(sources.values()):
        if len(group)>1:blocked.update(r['ID'] for r in group)
    for name,group in targets.items():
        for parent in PureWindowsPath(name).parents:
            if str(parent).casefold() in targets:
                blocked.update(r['ID'] for r in group)
                blocked.update(r['ID'] for r in targets[str(parent).casefold()])
    for r in rows:
        if r['ID'] in blocked:r.update(Action='SIGNALER',Motif='Collision de chemins dans le plan: copie en archives à vérifier')
    return rows


def run(plan_path,architecture,source,target,reports,copy=False,domain=None,circuit=None,limit=None,all_lots=False,scan_new=None):
    rows=load_plan(plan_path)
    selected=[dict(r) for r in rows if (not domain or r['Domaine'].casefold()==domain.casefold()) and
              (not circuit or r['Circuit'].casefold()==circuit.casefold())]
    if not selected:raise ValueError('Aucune ligne ne correspond aux filtres')
    source=source.resolve();target=target.resolve();reports=reports.resolve()
    if target==source or source in target.parents or target in source.parents:
        raise ValueError('Cible à placer hors de la source et de ses dossiers parents')
    if reports==source or source in reports.parents or reports==target or target in reports.parents:
        raise ValueError('Rapport à placer hors de la source et de la cible')
    if copy:
        if not source.is_dir():raise FileNotFoundError(f'Source inaccessible: {source}')
        no_links(source,());no_links(target.parent,())
        if not target.parent.is_dir():raise FileNotFoundError('Dossier parent de la cible inaccessible')
        token=dict(source=str(source),outil='PACIFICA_COPIE_V1')
        if target.exists():
            no_links(target,())
            if not (target/MARKER).is_file() or json.loads((target/MARKER).read_text())!=token:
                raise ValueError('Cible existante non reconnue: choisir une racine nouvelle ou celle créée par le script précédent')
    reports.mkdir(parents=True,exist_ok=False)
    nouveaux=0;acces_erreurs=0
    if scan_new is None:scan_new=limit is None
    known={str(PureWindowsPath(r['Chemin_source_relatif'])).casefold() for r in rows}
    run_id=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    domain_names={'climatique':'Climatique','demandes':'Demandes','reporting':'Reporting',
                  'pilotage activité':'Pilotage_activite','satisfaction client':'Satisfaction_client'}
    with (reports/'nouveaux_fichiers_non_recenses.csv').open('w',encoding='utf-8-sig',newline='') as nf, \
         (reports/'acces_inventaire.csv').open('w',encoding='utf-8-sig',newline='') as ef:
        nw=csv.writer(nf,delimiter=';');nw.writerow(['Chemin','Traitement'])
        ew=csv.writer(ef,delimiter=';');ew.writerow(['Chemin','Erreur'])
        def scan_error(exc):
            nonlocal acces_erreurs
            acces_erreurs+=1;ew.writerow([str(getattr(exc,'filename','')),str(exc)])
        if scan_new and source.is_dir():
            print('Recherche des nouveaux fichiers (aucune copie pendant cette étape)...',flush=True)
            scanned=0
            for current,dirs,names in os.walk(source,onerror=scan_error,followlinks=False):
                kept=[]
                for d in dirs:
                    try:no_links(source,(Path(current)/d).relative_to(source).parts);kept.append(d)
                    except (OSError,ValueError) as exc:scan_error(exc)
                dirs[:]=kept
                for name in names:
                    scanned+=1
                    if scanned%1000==0:print(f'Scan: {scanned} fichiers examinés...',flush=True)
                    file=Path(current)/name
                    rel=str(PureWindowsPath(*file.relative_to(source).parts))
                    if rel.casefold() in known:continue
                    inferred=next((v for bit in PureWindowsPath(rel).parts for k,v in domain_names.items() if bit.casefold().startswith(k)),'Transverse')
                    if domain and inferred.casefold()!=domain.casefold():continue
                    if circuit:continue  # pas d’attribution de parcours aux nouveaux fichiers
                    nw.writerow([str(file),'VERS_ARCHIVES_A_VERIFIER']);nouveaux+=1
                    selected.append(dict(ID=f'NOUVEAU_{nouveaux:05d}',Domaine=inferred,Circuit='Commun_ou_non_identifie',
                        Action='SIGNALER',Chemin_source_relatif=rel,Chemin_cible_relatif='',Taille_octets='',
                        Derniere_modification='',Motif='Fichier apparu depuis l’inventaire: copie en archive à vérifier'))
        elif not scan_new:print('Essai limité: scan global ignoré; il sera effectué au lancement sans --limite.',flush=True)
    def archive_path(row,version=False):
        parts=('99_Archives','A_verifier','Lot_01')
        if version:parts+=('_Versions',run_id)
        return no_links(target,parts+relative_parts(row['Chemin_source_relatif']))
    # Contrôle d’espace: le besoin porte sur les cibles manquantes; vérifié aussi avant chaque copie.
    if copy:
        candidates=selected if limit is None else selected[:limit]
        need=0
        for r in candidates:
            try:
                src=no_links(source,relative_parts(r['Chemin_source_relatif']))
                dst=archive_path(r) if r['Action']=='SIGNALER' else no_links(target,relative_parts(r['Chemin_cible_relatif']))
                if not dst.exists():need+=src.stat().st_size
            except (OSError,ValueError):pass
        free=shutil.disk_usage(target.parent).free
        if free<need+50*1024*1024:raise OSError(f'Espace insuffisant pour copies et archives: environ {need/1e9:.2f} Go nécessaires, {free/1e9:.2f} Go libres. Rapport initial: {reports}')
        if not target.exists():
            target.mkdir()
            with (target/MARKER).open('x',encoding='utf-8') as f:json.dump(token,f)
        for value in architecture['dossiers']:
            parts=relative_parts(value)
            if not all_lots and len(parts)>1 and parts[0]=='Lots' and parts[1]!='Lot_01':continue
            no_links(target,parts).mkdir(parents=True,exist_ok=True)
        no_links(target,('99_Archives','A_verifier','Lot_01')).mkdir(parents=True,exist_ok=True)
    fields=['ID','Domaine','Circuit','Source','Destination_prevue','Destination','Statut','Motif','SHA256_source','SHA256_copie']
    counts=collections.Counter();attempts=0;total=len(selected)
    with (reports/'journal.csv').open('w',encoding='utf-8-sig',newline='') as f, \
         (reports/'fichiers_non_copies.csv').open('w',encoding='utf-8-sig',newline='') as g, \
         (reports/'archives_a_verifier.csv').open('w',encoding='utf-8-sig',newline='') as h:
        journal=csv.DictWriter(f,fieldnames=fields,delimiter=';');journal.writeheader()
        pending=csv.DictWriter(g,fieldnames=fields,delimiter=';');pending.writeheader()
        archives=csv.DictWriter(h,fieldnames=fields,delimiter=';');archives.writeheader()
        for i,r in enumerate(selected,1):
            archive=r['Action']=='SIGNALER'
            parts=relative_parts(r['Chemin_source_relatif'])
            desired=archive_path(r) if archive else target.joinpath(*relative_parts(r['Chemin_cible_relatif']))
            item=dict(ID=r['ID'],Domaine=r['Domaine'],Circuit=r['Circuit'],Source=str(source.joinpath(*parts)),
                Destination_prevue=str(desired),Destination=str(desired),Statut='',Motif=r.get('Motif',''),SHA256_source='',SHA256_copie='')
            if limit is not None and attempts>=limit:item['Statut']='NON_TRAITE_LIMITE'
            elif not copy:
                attempts+=1;item['Statut']='SIMULATION_ARCHIVE_PREVUE' if archive else 'SIMULATION_COPIE_PREVUE'
            else:
                attempts+=1
                print(f'[{i}/{total}] {"ARCHIVE" if archive else "CLASSEMENT"}: {r["Chemin_source_relatif"]}',flush=True)
                try:
                    src=no_links(source,parts)
                    dst=archive_path(r) if archive else no_links(target,relative_parts(r['Chemin_cible_relatif']))
                    def perform(dest,snapshot):
                        if not dest.exists() and shutil.disk_usage(target.parent).free<src.stat().st_size+50*1024*1024:
                            raise OSError('Espace cible insuffisant pour ce fichier')
                        return copy_verified(src,dest,snapshot)
                    snapshot=r
                    if archive:snapshot=dict(r,Taille_octets=src.stat().st_size,Derniere_modification='')
                    try:
                        status,h1,h2=perform(dst,snapshot)
                    except (ValueError,OSError) as exc:
                        # Conflit ou inventaire périmé: sauvegarder l’état actuel à vérifier sans remplacer la copie classée.
                        archive=True
                        item['Motif']+=' / Copie classée impossible: '+str(exc)
                        dst=archive_path(r)
                        snapshot=dict(r,Taille_octets=src.stat().st_size,Derniere_modification='')
                        try:status,h1,h2=perform(dst,snapshot)
                        except FileExistsError:
                            dst=archive_path(r,version=True)
                            status,h1,h2=perform(dst,snapshot)
                    if archive:status='ARCHIVE_DEJA_IDENTIQUE' if status=='DEJA_IDENTIQUE' else 'ARCHIVE_VERIFIEE'
                    item.update(Destination=str(dst),Statut=status,SHA256_source=h1,SHA256_copie=h2)
                    print(f'    {status} -> {dst}',flush=True)
                except Exception as exc:item.update(Statut='ERREUR_NON_COPIE',Motif=item['Motif']+' / '+str(exc))
            counts[item['Statut']]+=1;journal.writerow(item);f.flush()
            if 'ARCHIVE' in item['Statut']:archives.writerow(item);h.flush()
            if item['Statut'] in ('ERREUR_NON_COPIE','NON_TRAITE_LIMITE'):pending.writerow(item);g.flush()
    result=dict(mode='COPIE' if copy else 'SIMULATION',source=str(source),cible=str(target),archives=str(target/'99_Archives'/'A_verifier'/'Lot_01'),
        lignes=len(selected),nouveaux_fichiers=nouveaux,scan_nouveaux_effectue=bool(scan_new),erreurs_scan=acces_erreurs,
        plan_sha256=digest(plan_path),statuts=dict(counts))
    (reports/'resume.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2));print(f'Rapports: {reports}')
    return result


def main():
    here=Path(__file__).parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',type=Path,default=here/'plan_classement.csv')
    p.add_argument('--architecture',type=Path,default=here/'architecture.json')
    p.add_argument('--source',type=Path)
    p.add_argument('--cible',type=Path)
    p.add_argument('--rapport',type=Path,help='Nouveau dossier de rapport hors source et cible')
    p.add_argument('--copier',action='store_true',help='Effectuer réellement les copies; sans option: simulation')
    p.add_argument('--domaine',help='Exemple: Climatique, Reporting, Satisfaction_client')
    p.add_argument('--circuit',choices=['Usine','Onshore','Commun_ou_non_identifie'])
    p.add_argument('--limite',type=int,help='Limiter le nombre de fichiers prévus/examinés')
    p.add_argument('--tous-les-lots',action='store_true')
    a=p.parse_args()
    if a.limite is not None and a.limite<1:p.error('--limite doit être positif')
    arch=json.loads(a.architecture.read_text(encoding='utf-8'))
    reports=a.rapport or Path.home()/('Rapport_organisation_M_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    result=run(a.plan,arch,a.source or Path(arch['source']),a.cible or Path(arch['cible_proposee']),reports,a.copier,a.domaine,a.circuit,a.limite,a.tous_les_lots)
    if result['statuts'].get('ERREUR_NON_COPIE'):raise SystemExit(1)


if __name__=='__main__':
    main()
