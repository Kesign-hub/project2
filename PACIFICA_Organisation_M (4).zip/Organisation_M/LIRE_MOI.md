# PACIFICA — Classement et archives à vérifier

## Ce que fait cette version
- Les fichiers dont la destination est identifiée sont copiés dans la structure Lot / Domaine / cinq dossiers, avec les parcours Usine et Onshore.
- Les fichiers dont le classement est incertain (Action=SIGNALER dans le plan) sont maintenant COPIÉS en archives pour revue, y compris sauvegardes, venv et caches.
- Les fichiers trouvés depuis l’inventaire sont également copiés en archives lors d’un lancement complet.
- Aucun fichier source n’est déplacé ni supprimé. Les droits d’accès de la nouvelle racine sont à vérifier avant copie: les ACL Windows ne sont pas reproduites automatiquement.
- Une limite de 10 signifie que seuls 10 fichiers sont examinés pour copie. Les autres restent à traiter normalement au lancement suivant; ils ne sont pas archivés à cause de cette limite.

Source conservée: M:\DSIN\Lot 1
Cible: M:\DSIN\Migration_SAS_Python
Archives: M:\DSIN\Migration_SAS_Python\99_Archives\A_verifier\Lot_01

Les chemins peuvent être affichés sous leur équivalent UNC \\s00sas017\users$\DSIN dans les rapports. Le chemin d’origine est conservé sous les archives, ce qui permet de retrouver le contexte.

## Lancement sur ton poste
Dézipper la nouvelle version et remplacer le dossier LOCAL Organisation_M contenant le script, le plan et architecture.json. Ne pas toucher au dossier source Lot 1 ni à la cible déjà créée.

Depuis le même terminal qu’avant:

Simulation:
    python Organisation_M\reorganiser_M.py

Continuer le classement et copier les fichiers incertains dans les archives, sur tout le lot:
    python Organisation_M\reorganiser_M.py --copier

Limiter le lancement au domaine Climatique:
    python Organisation_M\reorganiser_M.py --copier --domaine Climatique

Un petit essai de dix fichiers (pas de scan global):
    python Organisation_M\reorganiser_M.py --copier --domaine Climatique --limite 10

Les fichiers déjà présents et identiques sont reconnus DEJA_IDENTIQUE (ou ARCHIVE_DEJA_IDENTIQUE). Une limite compte aussi ces contrôles; pour poursuivre l’ensemble, relancer SANS --limite.

Cible différente si besoin (ne pas la placer dans Lot 1):
    python Organisation_M\reorganiser_M.py --copier --cible "M:\DSIN\Migration_SAS_Python_organise"

La cible précédente reste reconnue par le marqueur créé par les versions antérieures. Les scripts n’exigent pas de recommencer les copies déjà identiques.

## Où trouver les fichiers
Exemple code classé:
    M:\DSIN\Migration_SAS_Python\Lots\Lot_01\Climatique\01_Codes\Communs\SAS_origine

Exemple fichier incertain conservé pour revue:
    M:\DSIN\Migration_SAS_Python\99_Archives\A_verifier\Lot_01\<son ancien chemin relatif>

Les sous-dossiers vides créés en avance sont normaux. Le journal donne les destinations exactes des fichiers réellement copiés. Le terminal affiche chaque fichier avant copie puis son statut et sa destination; un fichier volumineux peut prendre du temps.

## Rapports
Un dossier Rapport_organisation_M_* est créé sur le poste (profil utilisateur); son chemin est affiché à la fin.
- journal.csv: destinations prévues et effectives, statuts, raisons et empreintes SHA-256.
- archives_a_verifier.csv: fichiers archivés ou déjà identiques en archives; conserver ce tableau pour décider ultérieurement de garder ou supprimer.
- fichiers_non_copies.csv: erreurs et fichiers non traités en raison d’une limite. Les fichiers effectivement archivés n’y figurent plus comme non copiés.
- nouveaux_fichiers_non_recenses.csv: fichiers découverts depuis l’inventaire et dirigés vers les archives; consulter le journal pour confirmer leur copie.
- acces_inventaire.csv: erreurs d’accès ou jonctions non parcourues.
- resume.json: compteurs et chemins des résultats.

En simulation, les statuts SIMULATION_* décrivent ce qui serait fait; aucun fichier n’a alors été copié sur M:.

## Sources modifiées, conflits et archives antérieures
Une source dont la taille/date diffère de l’inventaire n’est pas recopiée dans sa destination classée sur la base d’un plan périmé: son état actuel est sauvegardé en archives et signalé.
Si une destination classée contient déjà un fichier différent, elle est conservée telle quelle et la source actuelle est copiée en archives pour comparaison.
Si l’archive contient elle-même une ancienne version différente, elle est conservée et une nouvelle version est rangée dans 99_Archives/A_verifier/Lot_01/_Versions/<date_heure>/<chemin_origine>.
Une source inaccessible, disparue, liée par jonction/symlink, changeant pendant la copie, ou une erreur disque peut empêcher même l’archivage: elle reste alors signalée ERREUR_NON_COPIE. Aucun succès d’archivage n’est annoncé sans vérification.

## Volume et fonctionnement
La copie complète du classement ET des archives peut approcher les 178 Go de l’inventaire, hors nouveaux fichiers et versions supplémentaires; les sources restent présentes, il faut donc de l’espace supplémentaire.
Le script vérifie l’espace libre, copie par blocs et compare les empreintes SHA-256. Il ne remplace aucun fichier préexistant. Seuls ses propres fichiers temporaires sont retirés en cas d’échec.
Les essais limités n’effectuent plus le scan de tout le lecteur pour aller plus vite. Le lancement sans limite recherche les nouveaux fichiers, avec une progression tous les 1 000 fichiers.
Avec --domaine, seuls le domaine demandé et les nouveaux fichiers dont le domaine est identifiable sont traités. Sans filtre, toute la source est traitée, outils et fichiers transverses compris.
Avec --circuit, les nouveaux fichiers sans parcours établi ne sont pas attribués à un circuit. Pour traiter l’ensemble, utiliser la commande sans filtre.

## Limites de la restructuration
Le script copie le contenu sans réécrire les chemins des programmes ni exécuter de traitement métier. Avant utilisation depuis la nouvelle racine, vérifier les configurations, imports Python, LIBNAME, FILENAME, %INCLUDE, paramètres du DOC et liens Excel/EGP.
L’inventaire couvre M:\DSIN\Lot 1 seulement. Un dossier DPO ou usine ne prouve pas une validation ou une livraison. Les ZIP de packages sont copiés sans modification de leur contenu.
Les fichiers sous Outils conservent leurs restrictions d’usage, notamment les référentiels et tables de tokenisation. Les archives ne constituent pas des packages à envoyer.

## Tests réalisés
Simulation, classement normal, copie des incertains et nouveaux fichiers en archives, conservation des sources, reprise des copies existantes, absence d’écrasement, conservation des versions d’archives, limitation sans archivage indu, source modifiée et source absente. Tests locaux sur fichiers synthétiques; accès au partage Windows à confirmer sur le poste Pacifica.
