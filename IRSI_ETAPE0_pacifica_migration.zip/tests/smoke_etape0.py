import sys, types, importlib.util
import pandas as pd

# Minimal stub of pacifica.sas_fonctions for targeted smoke testing.
sf = types.SimpleNamespace()
sf.blancs = lambda df: df.fillna("")
def trier(df, by, desc=None):
    desc = desc or set()
    return df.sort_values(by=by, ascending=[c not in desc for c in by], kind='mergesort', na_position='first').reset_index(drop=True)
sf.trier = trier
sf.nodupkey = lambda df, by: df.drop_duplicates(subset=by, keep='first').reset_index(drop=True)
def distinct(df):
    cols=list(df.columns)
    return df.drop_duplicates().sort_values(cols, kind='mergesort', na_position='first').reset_index(drop=True)
sf.distinct = distinct
sf.tronquer = lambda v,n: ("" if pd.isna(v) else str(v))[:n]

pacifica = types.ModuleType('pacifica')
pacifica.sas_fonctions = sf
sys.modules['pacifica'] = pacifica
sys.modules['pacifica.sas_fonctions'] = sf

spec = importlib.util.spec_from_file_location('etape0', '/mnt/data/irsi_new/programmes/irsi/etape0_suvi_irsi.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class Ctx:
    def __getitem__(self,k):
        return {'FICHIER':'1225'}[k]
    def lib(self,k):
        assert k=='TEMP2'; return 'TEMP2'

class Src:
    def __init__(self):
        self.tables = {
            ('DATE1225','MVTPRMH'): pd.DataFrame([
                {'CONTRAT':'C2','IMAGE':'1','QUALITE':'Q','HABITAT':'H','SITCONT':'A'},
                {'CONTRAT':'C2','IMAGE':'1','QUALITE':'Q2','HABITAT':'H2','SITCONT':'A'},
                {'CONTRAT':'C3','IMAGE':'1','QUALITE':'Q','HABITAT':'H','SITCONT':'F'},
                {'CONTRAT':'C4','IMAGE':'1','QUALITE':'Q','HABITAT':'H','SITCONT':'I'},
            ]),
            ('DATE1225','MVTPRHA'): pd.DataFrame([
                {'CONTRAT':'A2','IMAGE':'1','QUALITE':'Q','HABITAT':'H','SITCONT':'A'},
            ]),
            ('DATE1225','MVTPRMR'): pd.DataFrame([
                {'CONTRAT':'R2','SITCONT':'A','IMAGE':'1','QUALITE':'Q','HABITAT':'H'},
            ]),
            ('DATE1225','MVTPRMP'): pd.DataFrame([
                {'CONTRAT':'P2','SITCONT':'A','IMAGE':'1','QUALITE':'Q','TYPBAT':'T'},
            ]),
            ('DATE1225','MVTPRM9'): pd.DataFrame([
                {'CONTRAT':'M9','SITCONT':'A','IMAGE':'1','QUALITE':'Q'},
            ]),
            ('TEMP2','MVTPRMH'): pd.DataFrame([
                {'CONTRAT':'C1','IMAGE':'1','QUALITE':'Q','HABITAT':'H','SITCONT':'A'},
            ]),
            ('TEMP2','MVTPRHA'): pd.DataFrame([
                {'CONTRAT':'A1','IMAGE':'1','QUALITE':'Q','HABITAT':'H','SITCONT':'A'},
            ]),
            ('TEMP2','MVTPRMR'): pd.DataFrame([
                {'CONTRAT':'R1','SITCONT':'A','IMAGE':'1','QUALITE':'Q','HABITAT':'H'},
            ]),
            ('TEMP2','MVTPRMP'): pd.DataFrame([
                {'CONTRAT':'P1','SITCONT':'A','IMAGE':'1','QUALITE':'Q','TYPBAT':'OLD'},
            ]),
        }
    def lire(self, lib, table, colonnes=None):
        df=self.tables[(lib,table)].copy()
        return df[colonnes].copy() if colonnes else df
    def colonnes(self, lib, table):
        df=self.tables[(lib,table)]
        return [(c, 20 if df[c].dtype == object else None) for c in df.columns]

res=m.executer(Ctx(), Src(), object())
assert set(res)=={'MVTPRMH','MVTPRHA','MVTPRMR','MVTPRMP'}
# F excluded, I retained, duplicate C2 keeps first row after stable sort.
mh=res['MVTPRMH']
assert 'C3' not in set(mh.CONTRAT)
assert 'C4' in set(mh.CONTRAT)
assert len(mh[mh.CONTRAT=='C2'])==1
assert mh[mh.CONTRAT=='C2'].iloc[0].QUALITE=='Q'
# M9 is merged into MP and gets blank TYPBAT.
mp=res['MVTPRMP']
assert {'P1','P2','M9'} <= set(mp.CONTRAT)
assert mp[mp.CONTRAT=='M9'].iloc[0].TYPBAT==''
print('SMOKE_OK')
