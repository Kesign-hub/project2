# ETAPE0_SUVI_IRSI — notes de transcription

## Paramètres / bibliothèques
- `ctx["FICHIER"]` remplace `&fichier.` du lanceur.
- `ctx.lib("TEMP2")` désigne l'historique IRSI préexistant.

## Comportements SAS reproduits
- `SITCONT='I'` est conservé : il est commenté dans les exclusions du SAS.
- Snapshot courant : tri stable puis `NODUPKEY BY CONTRAT IMAGE`.
- MH/HA/MR : concaténation avec TEMP2 puis `NODUPKEY BY _ALL_`.
- MP : concaténation avec TEMP2 puis `NODUPKEY BY CONTRAT IMAGE`.
- M9 : `TYPBAT=""`, puis ajout à l'historique MP, pas à un historique M9 séparé.
- Les historiques TEMP2 doivent exister ; ils ne sont pas recréés automatiquement.
- L'ordre physique des colonnes de TEMP2 est utilisé quand les métadonnées sont disponibles pour reproduire `BY _ALL_`.

## Bloc commenté non transcrit
Les gros blocs `PROC IMPORT`, macros historiques et anciennes lectures multi-années sont entièrement commentés dans le SAS reçu. Ils ne font donc pas partie du traitement exécuté et n'ont pas été traduits.

## Point à valider dans le framework
Le SAS écrit directement dans `TEMP2` puis supprime WORK. Le contrat PACIFICA interdit l'écriture directe dans le module : la transcription retourne donc `MVTPRMH`, `MVTPRHA`, `MVTPRMR`, `MVTPRMP`. Le lanceur / environnement doit persister ces sorties dans le stockage historique équivalent à TEMP2 pour préserver l'incrémentalité entre exécutions.

## Tests exécutés
- `python -m py_compile` : OK.
- smoke test synthétique : OK (`SMOKE_OK`).
- Pas de comparaison réelle SAS/Python : nécessite les historiques TEMP2 et les snapshots du poste PACIFICA.
