# -*- coding: utf-8 -*-
"""ETAPE0_SUVI_IRSI_desensibilise.sas — alimentation des historiques contrats IRSI.

Paramètres / contexte utilisés :
  - ctx["FICHIER"] : suffixe de la bibliothèque DATE du snapshot courant (ex. "1225").
  - ctx.lib("TEMP2") : bibliothèque historique IRSI préexistante.

Sources du snapshot courant :
  DATE&FICHIER..MVTPRMH, MVTPRHA, MVTPRMR, MVTPRMP, MVTPRM9.

Historiques obligatoires :
  TEMP2.MVTPRMH, TEMP2.MVTPRHA, TEMP2.MVTPRMR, TEMP2.MVTPRMP.

Tables produites par cette transcription :
  MVTPRMH, MVTPRHA, MVTPRMR, MVTPRMP — contenu final des historiques TEMP2
  après ajout du snapshot courant. MVTPRM9 n'a pas d'historique propre : le SAS
  l'ajoute à TEMP2.MVTPRMP après avoir forcé TYPBAT="".

Comportements SAS reproduits volontairement :
  1. SITCONT='I' N'EST PAS exclu : la valeur est commentée dans le SAS.
  2. Le snapshot courant est d'abord PROC SORT NODUPKEY BY CONTRAT IMAGE.
  3. MVTPRMH/MVTPRHA/MVTPRMR sont ensuite concaténés à l'historique puis
     PROC SORT NODUPKEY BY _ALL_.
  4. MVTPRMP est concaténé à l'historique puis NODUPKEY BY CONTRAT IMAGE.
  5. MVTPRM9 est concaténé au MÊME historique MVTPRMP, avec TYPBAT="", puis
     NODUPKEY BY CONTRAT IMAGE.
  6. Les historiques TEMP2 doivent exister : le SAS d'origine ne les recrée pas.
  7. Pour BY _ALL_, l'ordre physique des colonnes de TEMP2 est conservé quand
     les métadonnées sont disponibles, car il influence le tri SAS.

Note d'intégration :
  Le SAS écrit dans la bibliothèque persistante TEMP2 puis détruit WORK. Le
  framework interdit toute écriture directe depuis le module ; ce module retourne
  donc les versions finales des quatre historiques. Le lanceur / environnement
  doit persister ces sorties vers l'équivalent cible de TEMP2. Ne pas les traiter
  comme de simples sorties éphémères si l'on veut conserver l'incrémentalité SAS.
"""
from __future__ import annotations

import pandas as pd

from pacifica import sas_fonctions as sf


EXCLUS_SITCONT = ["F", "J", "B", "W"]  # 'I' est volontairement conservé dans le SAS.

COLS_MH_HA = ["CONTRAT", "IMAGE", "QUALITE", "HABITAT", "SITCONT"]
COLS_MR = ["CONTRAT", "SITCONT", "IMAGE", "QUALITE", "HABITAT"]
COLS_MP = ["CONTRAT", "SITCONT", "IMAGE", "QUALITE", "TYPBAT"]
COLS_M9 = ["CONTRAT", "SITCONT", "IMAGE", "QUALITE"]


def _snapshot_courant(src, lib_date: str, table: str, colonnes: list[str]) -> pd.DataFrame:
    """DATA step + WHERE + PROC SORT NODUPKEY BY CONTRAT IMAGE."""
    df = sf.blancs(src.lire(lib_date, table, colonnes=colonnes))
    df = df[~df["SITCONT"].isin(EXCLUS_SITCONT)].copy()
    df = sf.trier(df, ["CONTRAT", "IMAGE"])
    return sf.nodupkey(df, ["CONTRAT", "IMAGE"])


def _ordre_historique(src, lib_hist: str, table: str, df: pd.DataFrame) -> pd.DataFrame:
    """Reproduit autant que possible l'ordre physique du PDV de l'historique SAS."""
    meta = src.colonnes(lib_hist, table) or []
    ordre = [c for c, _ in meta if c in df.columns]
    autres = [c for c in df.columns if c not in ordre]
    return df[ordre + autres] if ordre else df


def _tronquer_aux_longueurs_historiques(
    src,
    lib_hist: str,
    table: str,
    courant: pd.DataFrame,
) -> pd.DataFrame:
    """SET historique courant : les attributs du premier dataset pilotent les longueurs char SAS."""
    meta = dict(src.colonnes(lib_hist, table) or [])
    if not meta:
        return courant
    out = courant.copy()
    for col, longueur in meta.items():
        if longueur and col in out.columns:
            out[col] = out[col].map(lambda v, n=longueur: sf.tronquer(v, n))
    return out


def _concatener_sas(historique: pd.DataFrame, courant: pd.DataFrame) -> pd.DataFrame:
    """Équivalent DATA x; SET historique courant; RUN; avec manquants caractère SAS."""
    return sf.blancs(pd.concat([historique, courant], ignore_index=True, sort=False))


def _mettre_a_jour_by_all(src, lib_hist: str, table: str, courant: pd.DataFrame) -> pd.DataFrame:
    """SET TEMP2.<table> courant ; PROC SORT NODUPKEY BY _ALL_."""
    historique = sf.blancs(src.lire(lib_hist, table))
    courant = _tronquer_aux_longueurs_historiques(src, lib_hist, table, courant)
    fusion = _concatener_sas(historique, courant)
    fusion = _ordre_historique(src, lib_hist, table, fusion)
    return sf.distinct(fusion)


def _mettre_a_jour_by_contrat_image(
    src,
    lib_hist: str,
    table: str,
    historique: pd.DataFrame,
    courant: pd.DataFrame,
) -> pd.DataFrame:
    """SET historique courant ; PROC SORT NODUPKEY BY CONTRAT IMAGE."""
    courant = _tronquer_aux_longueurs_historiques(src, lib_hist, table, courant)
    fusion = _concatener_sas(historique, courant)
    fusion = sf.trier(fusion, ["CONTRAT", "IMAGE"])
    return sf.nodupkey(fusion, ["CONTRAT", "IMAGE"])


def executer(ctx, src, out) -> dict[str, pd.DataFrame]:
    """Transcrit ETAPE0_SUVI_IRSI.SAS sans accès fichier ni écriture directe."""
    del out  # ETAPE0 n'exporte aucun fichier ; la persistance est assurée par le lanceur.

    lib_date = f"DATE{ctx['FICHIER']}"
    lib_hist = ctx.lib("TEMP2")

    # ETAPE 1a : NH/MH
    mvtprmh = _snapshot_courant(src, lib_date, "MVTPRMH", COLS_MH_HA)
    hist_mh = _mettre_a_jour_by_all(src, lib_hist, "MVTPRMH", mvtprmh)

    # ETAPE 1b : HA
    mvtprha = _snapshot_courant(src, lib_date, "MVTPRHA", COLS_MH_HA)
    hist_ha = _mettre_a_jour_by_all(src, lib_hist, "MVTPRHA", mvtprha)

    # ETAPE 1c : MR
    mvtprmr = _snapshot_courant(src, lib_date, "MVTPRMR", COLS_MR)
    hist_mr = _mettre_a_jour_by_all(src, lib_hist, "MVTPRMR", mvtprmr)

    # ETAPE 1d : MP
    mvtprmp = _snapshot_courant(src, lib_date, "MVTPRMP", COLS_MP)
    hist_mp_initial = sf.blancs(src.lire(lib_hist, "MVTPRMP"))
    hist_mp = _mettre_a_jour_by_contrat_image(
        src, lib_hist, "MVTPRMP", hist_mp_initial, mvtprmp
    )

    # ETAPE 1e : M9 — le SAS l'ajoute à TEMP2.MVTPRMP et non à un historique M9.
    mvtprm9 = _snapshot_courant(src, lib_date, "MVTPRM9", COLS_M9)
    mvtprm9["TYPBAT"] = ""
    hist_mp = _mettre_a_jour_by_contrat_image(
        src, lib_hist, "MVTPRMP", hist_mp, mvtprm9
    )

    return {
        "MVTPRMH": hist_mh,
        "MVTPRHA": hist_ha,
        "MVTPRMR": hist_mr,
        "MVTPRMP": hist_mp,
    }
