# Restructuration proposée du lecteur M — PACIFICA

Ouvrir `organisation_M.html` pour le guide visuel et l’arborescence dépliable.

## Périmètre réellement analysé
L’inventaire reçu porte sur `M:\DSIN\Lot 1`, et non sur tout M:. Il contient 9 495 entrées: 8 723 fichiers et 772 dossiers. Volume cumulé des fichiers: 178,112 Go décimaux environ. Ce volume additionne les copies et archives existantes; il ne mesure pas l’espace récupérable. Aucun rapport d’erreurs du scan n’a été fourni: l’exhaustivité des accès n’est pas établie.

La destination proposée est `M:\DSIN\Migration_SAS_Python`. Ce choix est modifiable; aucun élément n’a été déplacé. Le plan est une proposition à vérifier à partir des noms, tailles et dates. Les fichiers source, DCP et programmes du lecteur n’ont pas été ouverts ni exécutés.

## Documents fournis
- plan_classement.csv: toutes les entrées de l’inventaire et leur destination proposée; les dossiers sont descriptifs, jamais des instructions de copie récursive. La colonne Validation est à A_VERIFIER.
- doublons_potentiels.csv: mêmes noms et mêmes tailles, sans vérification du contenu. Aucune suppression autorisée par ce seul constat.
- synthese_dossiers.csv: volumes et effectifs par dossier de premier niveau.
- chemins_longs_a_verifier.csv: destinations à partir de 260 caractères. La compatibilité Windows/SAS/Excel dépend des applications et de leur configuration.
- architecture.json: structure cible, chemins source/cible et domaines.
- modele_manifeste_package.csv: en-tête de registre pour suivre les validations et livraisons par programme.
- preparer_structure.py: simulation par défaut, création des dossiers sur option, et audit en lecture seule des anciennes racines dans les sources texte.

## Utilisation sur le poste Pacifica
Dézipper ce dossier sur le poste. Python 3.9+; aucune dépendance supplémentaire.

Simulation de la structure (aucune création sur M):
    python preparer_structure.py

Créer les dossiers du lot 1 dans une destination NOUVELLE:
    python preparer_structure.py --creer --cible "M:\DSIN\Migration_SAS_Python"

Inclure aussi les structures des lots 2 à 8:
    python preparer_structure.py --creer --tous-les-lots --cible "M:\DSIN\Migration_SAS_Python"

Auditer les chemins et imports à examiner dans les programmes existants:
    python preparer_structure.py --auditer-liens --source "M:\DSIN\Lot 1"

L’audit crée uniquement un rapport local horodaté. Il ne modifie aucun programme. La présence d’un ancien chemin dans une chaîne, un import ou une configuration est un point de contrôle, pas la preuve d’un lien cassé. L’audit textuel n’analyse pas les liens internes Excel, EGP ou les catalogues SAS.

## Ordre de bascule
1. Conserver l’existant et identifier la version faisant foi de chaque DCP, outil et pilote. Ne pas choisir la version sur son seul nom ou sa date.
2. Revoir les destinations, les chemins longs, les droits d’accès (données et tables de tokens incluses) et les doublons potentiels. Garder les référentiels et tables techniques dans le projet d’origine tant que ses chemins ne sont pas adaptés.
3. Auditer les racines absolues, imports Python, %INCLUDE, LIBNAME, FILENAME, chemins de sortie et paramètres du DOC. Conserver les noms des fichiers. Les imports locaux sont mieux préservés en gardant le projet migration_sas_python entier, sans fusion avec outils_inventaire.
4. Copier un périmètre pilote limité et de taille maîtrisée dans la nouvelle arborescence. Comparer les empreintes SHA-256 des copies. Ne pas copier tout le volume de 178 Go d’emblée. Aucun outil de déplacement automatique n’est inclus.
5. Adapter uniquement la configuration et les chemins justifiés, tester syntaxe et exécution ciblée dans l’environnement Pacifica (les chemins serveur SAS peuvent différer de M: côté poste).
6. Vérifier les DCP, logs, sorties et résultats de recette avant bascule des utilisateurs. Une sortie présente ou un dossier nommé usine ne signifie pas que le programme est conforme ou livré.
7. Référencer la nouvelle racine dans le guide d’équipe, geler les livraisons validées par version, puis décider séparément de l’archivage ou suppression après validation de la bascule.

## Règles d’équipe
- Un lot contient les mêmes étapes pour chacun des cinq domaines.
- Les outils partagés restent hors des lots. Conserver le venv historique sur place jusqu’à bascule; recréer l’environnement d’exécution localement à partir des dépendances validées.
- Les données et référentiels de tokenisation ne deviennent pas librement accessibles parce qu’ils sont rangés sous Outils. Conserver les restrictions existantes lors de toute copie.
- Une fiche programme doit relier code d’origine, DCP, jeux d’entrée, période, dépendances, logs, sorties de référence, traduction et comparaison.
- Les historiques completion_, OLD/OLD2, sauvegardes et .bak sont conservés. Le nom d’un dossier n’établit pas qu’une version est obsolète.
- Les dossiers DPO existants vont dans une zone de statut à confirmer. La zone Validations_DPO est alimentée seulement avec les preuves validées.
- Les ensembles sous Desensibilisation/synthese restent groupés dans la recette SAS à qualifier; les noms internes usine et ONSHORE sont conservés. Seule une vérification de contenu permettra de les répartir plus finement.
- Un package destiné à Accenture est assemblé depuis des éléments contrôlés, puis figé avec manifeste et empreinte. Ne jamais envoyer tout le répertoire de travail ni les tables de correspondance des tokens.
- Les programmes onshore suivent les mêmes étapes de données/validation selon les règles de l’environnement. Leur statut ne peut pas être déduit de l’inventaire.

## Structure d’un package validé
Dans 08_Packages/Domaine/01_Assemblage/<programme>/<version>/, prévoir Code_SAS, Lanceurs_Macros, DCP, Donnees_autorisees, Reference_SAS, Logs et Instructions. Ne changer la structure des packages attendue par Accenture qu’après confirmation du contrat de livraison. Le dossier 02_Valides conserve les versions approuvées et 03_Livres les ZIP effectivement envoyés avec preuve d’envoi. Le plan ne déplace aucun élément existant automatiquement vers ces statuts.
