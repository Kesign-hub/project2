# -*- coding: utf-8 -*-
"""Tests de inventorier_sources_sas_externes.py — sans SAS, sans réseau.
    python -m unittest 01_inventaire_cartographie\\tests\\test_sources_sas.py -v
"""
from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ICI = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ICI))

from openpyxl import load_workbook  # noqa: E402

import inventorier_sources_sas_externes as outil  # noqa: E402
from sources_sas.analyse import analyser_fichier, separer_ref  # noqa: E402


def ecrire(p: Path, texte: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(texte, encoding="latin-1")


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp())
        t = cls.tmp
        for d in ("ext", "temp", "Infocentre/DSIALI/data2025"):
            (t / d).mkdir(parents=True)
        for f in ("ext/clients.sas7bdat", "ext/contrats.sas7bdat", "ext/histo.sas7bdat", "ext/vue1.sas7bvew",
                  "Infocentre/DSIALI/data2025/sin_dgl.sas7bdat", "temp/inter.sas7bdat"):
            (t / f).write_bytes(b"x")
        prog = t / "Lot 3" / "Programmes"
        cls.prog = prog
        ecrire(prog / "Enquetes" / "lanceur.sas", f"""
%let REP={t}/ext;
libname EXT "&REP.";
libname INFO "{t}/Infocentre/DSIALI/data2025";
libname TMP "{t}/temp";
%include "{prog}/Enquetes/etape1.sas";
%include "{prog}/Enquetes/etape2.sas";
""")
        ecrire(prog / "Enquetes" / "etape1.sas", """
/* data x; set EXT.commentee; run; */
* set EXT.commentee2;
data TMP.inter;
  set INFO.sin_dgl(keep=sin where=(etat ne 'A'));
run;
data work.a;
  set EXT.clients;
run;
proc sql;
  create table TMP.res as
  select a.*, b.x from EXT.contrats as a left join work.a b on a.k = b.k;
quit;
data TMP.cree; x = 1; run;
data b; set TMP.cree; run;
data c; set EXT.vue1 EXT.absente; run;
""")
        ecrire(prog / "Enquetes" / "etape2.sas", """
data x;
  merge TMP.inter(in=a) EXT.clients;
  by k;
run;
proc sort data=NONRES.t out=work.s; run;
libname DYN "&INCONNU.\\x";
data y; set DYN.t; run;
data z; set &LIBX..&TAB.; run;
libname XL xlsx "c:\\temp\\f.xlsx";
data w; set XL.feuil1; run;
""")
        ecrire(prog / "Autre" / "isole.sas", f"""
libname EXT2 "{t}/ext";
data z; set EXT2.clients; run;
data h; set EXT2.histo; run;
proc append base=EXT2.histo data=h; run;
""")
        cls.sortie = t / "res" / "sources.xlsx"
        cls.carto = t / "carto"
        outil.main([str(prog), "--sortie", str(cls.sortie), "--infocentre", "infocentre",
                    "--cartographie", str(cls.carto), "--suffixe", "_test"])
        wb = load_workbook(cls.sortie)
        cls.detail = [dict(zip([c.value for c in wb["Detail"][1]], [c.value for c in r]))
                      for r in wb["Detail"].iter_rows(min_row=2)]
        cls.conso = [dict(zip([c.value for c in wb["Toutes_sources"][1]], [c.value for c in r]))
                     for r in wb["Toutes_sources"].iter_rows(min_row=2)]
        cls.externes = [dict(zip([c.value for c in wb["Sources_externes"][1]], [c.value for c in r]))
                        for r in wb["Sources_externes"].iter_rows(min_row=2)]

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def lecture(self, prog, lib, table):
        r = [d for d in self.detail if d["Programme"] == prog and d["LIBREF"] == lib and d["Table"] == table
             and d["Est_input"] == "OUI"]
        self.assertTrue(r, f"lecture {lib}.{table} absente dans {prog}")
        return r[0]


class TestClassification(Base):
    def test_infocentre_par_chemin(self):
        d = self.lecture("etape1.sas", "INFO", "SIN_DGL")
        self.assertEqual((d["Classification"], d["Regle"]), ("INFOCENTRE", "INFOCENTRE_PAR_CHEMIN"))

    def test_externe_set_via_lanceur_et_macro(self):
        d = self.lecture("etape1.sas", "EXT", "CLIENTS")
        self.assertEqual(d["Classification"], "EXTERNE_SAS")
        self.assertIn("lanceur.sas", d["Defini_dans"])
        self.assertEqual(d["Source_mapping"], "lanceur")
        self.assertIn("&REP=", d["Macro_resolue"])
        self.assertTrue(d["Chemin_physique_estime"].endswith("ext/clients.sas7bdat"))

    def test_sql_from_join(self):
        self.assertEqual(self.lecture("etape1.sas", "EXT", "CONTRATS")["Classification"], "EXTERNE_SAS")
        self.assertEqual(self.lecture("etape1.sas", "WORK", "A")["Classification"], "WORK_INTERMEDIAIRE")

    def test_work(self):
        self.assertEqual(self.lecture("etape1.sas", "WORK", "A")["Regle"], "EXCLU_WORK")

    def test_cree_puis_relue(self):
        d = self.lecture("etape1.sas", "TMP", "CREE")
        self.assertEqual((d["Classification"], d["Regle"]), ("SORTIE_PROGRAMME", "PRODUIT_DANS_MEME_PROGRAMME"))

    def test_programme_precedent_merge(self):
        d = self.lecture("etape2.sas", "TMP", "INTER")
        self.assertEqual((d["Classification"], d["Regle"]), ("SORTIE_PROGRAMME_PRECEDENT", "PRODUIT_DANS_PROGRAMME_PRECEDENT"))
        self.assertEqual(d["Programme_producteur"], "etape1.sas")
        self.assertEqual(d["Type_instruction"], "MERGE")

    def test_merge_externe(self):
        self.assertEqual(self.lecture("etape2.sas", "EXT", "CLIENTS")["Classification"], "EXTERNE_SAS")

    def test_libref_non_resolu(self):
        d = self.lecture("etape2.sas", "NONRES", "T")
        self.assertEqual((d["Classification"], d["Regle"]), ("NON_RESOLU", "LIBREF_NON_RESOLU"))

    def test_libname_macro_non_resoluble(self):
        d = self.lecture("etape2.sas", "DYN", "T")
        self.assertEqual((d["Classification"], d["Regle"]), ("NON_RESOLU", "CHEMIN_MACRO_NON_RESOLUE"))
        self.assertEqual(d["Chemin_physique_estime"] or "", "")          # aucun chemin inventé

    def test_nom_dynamique(self):
        d = self.lecture("etape2.sas", "&LIBX.", "&TAB.")
        self.assertEqual((d["Classification"], d["Regle"]), ("A_VERIFIER", "NOM_DYNAMIQUE_NON_RESOLU"))

    def test_excel(self):
        self.assertEqual(self.lecture("etape2.sas", "XL", "FEUIL1")["Regle"], "FICHIER_PLAT_EXCEL")

    def test_vue_et_absent(self):
        self.assertEqual(self.lecture("etape1.sas", "EXT", "VUE1")["Regle"], "VUE_SAS")
        self.assertEqual(self.lecture("etape1.sas", "EXT", "ABSENTE")["Regle"], "FICHIER_ABSENT")

    def test_commentaires_ignores(self):
        self.assertFalse([d for d in self.detail if d["Table"] in ("COMMENTEE", "COMMENTEE2")])

    def test_table_historisee(self):
        d = self.lecture("isole.sas", "EXT2", "HISTO")
        self.assertEqual((d["Classification"], d["Regle"]), ("A_VERIFIER", "TABLE_HISTORISEE"))

    def test_consolidation_plusieurs_programmes(self):
        c = [s for s in self.conso if (s["Chemin_fichier_sas7bdat"] or "").endswith("ext/clients.sas7bdat")]
        self.assertEqual(len(c), 1)
        self.assertEqual(c[0]["Nb_programmes"], 3)
        self.assertEqual(c[0]["Classification"], "EXTERNE_SAS")
        self.assertEqual(c[0]["Programmes_utilisateurs"], "etape1.sas, etape2.sas, isole.sas")

    def test_liste_finale(self):
        self.assertEqual(sorted(s["Table"] for s in self.externes), ["CLIENTS", "CONTRATS"])

    def test_domaine_et_lot(self):
        d = self.lecture("etape1.sas", "EXT", "CLIENTS")
        self.assertEqual((d["Lot"], d["Domaine"], d["Lanceur"]), ("Lot 3", "Enquetes", "lanceur.sas"))


class TestCartographie(Base):
    def test_inventaire_au_format_fichiers_plats(self):
        inv = self.carto / "inventaire_tables_sas_test.xlsx"
        wb = load_workbook(inv)
        self.assertEqual(wb.sheetnames[:2], ["Inventaire", "Fichiers_uniques"])
        ent = [c.value for c in wb["Inventaire"][1]]
        self.assertIn("chemin_resolu", ent)
        self.assertIn("source_direction", ent)
        lignes = list(wb["Fichiers_uniques"].iter_rows(min_row=2, values_only=True))
        self.assertEqual(len(lignes), 2)                       # clients + contrats

    def test_dcp_non_ecrase(self):
        # les fichiers de test ne sont pas de vraies tables : illisibles, aucun DCP créé, aucun plantage
        wb = load_workbook(self.carto / "inventaire_tables_sas_test.xlsx")
        statuts = [r[3] for r in wb["DCP_tables"].iter_rows(min_row=2, values_only=True)]
        self.assertTrue(all(s.startswith("illisible") for s in statuts))


class TestCircuitSchemaSAS(Base):
    """Même circuit que les fichiers plats : script SAS -> CSV de schéma -> DCP."""

    def test_script_puis_dcp(self):
        carto = self.tmp / "carto2"
        outil.main([str(self.prog), "--sortie", str(self.tmp / "res2" / "s.xlsx"), "--cartographie", str(carto),
                    "--suffixe", "_t", "--generate-schema-script"])
        sas = (carto / "extract_schema_tables_t.sas").read_text(encoding="latin-1")
        self.assertIn("access=readonly", sas)
        self.assertIn("memname='CLIENTS'", sas)
        self.assertIn("memname='CONTRATS'", sas)
        self.assertEqual(sas.count("libname _T"), 2)              # un LIBNAME par dossier + clear
        self.assertNotIn("set ", sas.lower())                      # aucune lecture de données
        # simulation de l'exécution SAS : CSV tel que PROC EXPORT le produit
        ext = self.tmp / "ext"
        lignes = ["SOURCE,NAME,TYPE,LENGTH,FORMAT,VARNUM,SOURCE_PATH,SHEET,LABEL"]
        for t, cols in (("clients", [("NO_CLI", "num", 8, "BEST12.", "Numéro client"), ("NOM", "char", 40, "$40.", "Nom")]),
                        ("contrats", [("CONTRAT", "char", 12, "", ""), ("DT_EFF", "num", 8, "DATE9.", "Date effet")])):
            for i, (n, ty, lg, fm, lb) in enumerate(cols, 1):
                lignes.append(f"{t}.sas7bdat,{n},{ty},{lg},{fm},{i},{ext}/{t}.sas7bdat,,{lb}")
        csvp = carto / "schema_tables_t.csv"
        csvp.write_text("\n".join(lignes), encoding="utf-8")
        outil.main([str(self.prog), "--sortie", str(self.tmp / "res2" / "s.xlsx"), "--cartographie", str(carto),
                    "--suffixe", "_t", "--schema-ref", str(csvp), "--date-effet", "01/12/2026"])
        dcps = sorted((carto / "DCP").rglob("DCP_*.xlsx"))
        self.assertEqual(sorted(p.parent.name for p in dcps), ["Autre", "Enquetes"])   # table partagée : 1er domaine
        from cartographie.dcp_generator import _nom_fichier_dcp
        self.assertIn(_nom_fichier_dcp(f"{ext}/clients.sas7bdat", ""), [p.name for p in dcps])
        wb = load_workbook([p for p in dcps if "clients" in p.name][0])
        rows = list(wb["Données"].iter_rows(min_row=2, values_only=True))
        self.assertEqual([(r[2], r[3], r[5], r[6], r[8]) for r in rows],
                         [("NO_CLI", "Numéro client", "N", 8, "BEST12."), ("NOM", "Nom", "C", 40, "$40.")])
        wb2 = load_workbook([p for p in dcps if "contrats" in p.name][0])
        r2 = list(wb2["Données"].iter_rows(min_row=2, values_only=True))
        self.assertEqual(r2[0][8], "$12.")                         # format déduit comme pour les fichiers plats
        self.assertEqual(r2[0][17], "01/12/2026")
        # relance : DCP conservés
        avant = {p: p.stat().st_mtime for p in dcps}
        outil.main([str(self.prog), "--sortie", str(self.tmp / "res2" / "s.xlsx"), "--cartographie", str(carto),
                    "--suffixe", "_t", "--schema-ref", str(csvp)])
        self.assertEqual(avant, {p: p.stat().st_mtime for p in dcps})


class TestAnalyse(unittest.TestCase):
    def test_separer_ref(self):
        self.assertEqual(separer_ref("&LIB..&TAB."), ("&LIB.", "&TAB."))
        self.assertEqual(separer_ref("lib.t_&an."), ("LIB", "T_&AN."))
        self.assertEqual(separer_ref("t"), ("WORK", "T"))
        self.assertIsNone(separer_ref("_null_"))

    def test_set_plusieurs_et_options(self):
        d = Path(tempfile.mkdtemp())
        p = d / "p.sas"
        p.write_text("data x; set A.T1(where=(y='a;b')) B.T2 end=fin; run;\n"
                     "proc sql; select * from L.T3 , L.T4 inner join L.T5 on 1=1 where z in (select k from L.T6); quit;\n"
                     "proc means data=L.T7; output out=L.T8; run;\n"
                     "data _null_; declare hash h(dataset:'L.T9'); run;\n", encoding="latin-1")
        f = analyser_fichier(p)
        lus = {f"{a.lib}.{a.table}" for a in f.acces if a.sens == "LIT"}
        ecrits = {f"{a.lib}.{a.table}" for a in f.acces if a.sens == "ECRIT"}
        self.assertEqual(lus, {"A.T1", "B.T2", "L.T3", "L.T4", "L.T5", "L.T6", "L.T7", "L.T9"})
        self.assertEqual(ecrits, {"WORK.X", "L.T8"})
        shutil.rmtree(d)


class TestDCP(unittest.TestCase):
    def test_dcp_depuis_description(self):
        try:
            import pandas as pd
            import pyreadstat
        except ImportError:
            self.skipTest("pyreadstat absent")
        from sources_sas import dcp_tables
        d = Path(tempfile.mkdtemp())
        x = d / "pop.xpt"
        pyreadstat.write_xport(pd.DataFrame({"NO_CLI": [1.0], "NOM": ["A"]}), str(x),
                               column_labels=["Numéro client", "Nom"], table_name="POP")
        meta = dcp_tables.lire_description(x)
        cols = dcp_tables.colonnes_dcp(meta)
        cible = d / "DCP" / dcp_tables.nom_dcp(x)
        dcp_tables.ecrire_dcp(x, meta, cols, cible, "01/12/2026")
        wb = load_workbook(cible)
        self.assertEqual(wb.sheetnames, ["Données", "_REF_CNIL", "Légende"])
        lignes = list(wb["Données"].iter_rows(min_row=2, values_only=True))
        self.assertEqual([l[2] for l in lignes], ["NO_CLI", "NOM"])
        self.assertEqual([l[5] for l in lignes], ["N", "C"])
        self.assertEqual(lignes[0][10], "OUI (pattern)")
        shutil.rmtree(d)


if __name__ == "__main__":
    unittest.main(verbosity=2)
