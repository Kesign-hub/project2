# -*- coding: utf-8 -*-
"""
cartographier_tables_sas.py
===========================
Recense des tables SAS (.sas7bdat) et prépare leurs DCP, au même format que les DCP des fichiers
plats (onglet « Données », listes déroulantes Catégorie CNIL / Méthode / Mode TOKEN, légende,
contrôle F99). Complément de generate_cartography.py, qui ne couvre que les fichiers plats.

AUCUNE DONNÉE N'EST LUE : seule la description des tables (colonnes, types, longueurs, formats,
libellés, nombre de lignes) est lue dans l'en-tête des fichiers.

Usage (venv activé, chemins entre apostrophes) :
    python 01_inventaire_cartographie\\cartographier_tables_sas.py ^
        --tables 'J:\\DSIN\\P_Perf\\10_ENQUETE\\15_ENQUETES_A_CHAUD\\DATA' ^
        --sortie 'C:\\Users\\<moi>\\outils_migration\\_donnees_locales\\carto_tables_EAC' ^
        --programmes 'M:\\DSIN\\Lot 1\\Programmes\\Satisfaction client'

    --tables      dossier de tables (ou une ou plusieurs tables .sas7bdat)
    --sortie      dossier où écrire l'inventaire et les DCP
    --programmes  (facultatif) dossier des programmes SAS : pour chaque table, indique quels
                  programmes la CRÉENT et lesquels la LISENT. Une table créée par nos programmes
                  est une table intermédiaire : elle n'a en général pas besoin d'être anonymisée.
    --recursif    parcourir aussi les sous-dossiers de --tables
    --date-effet  date de création à inscrire dans les DCP (jj/mm/aaaa)

Même circuit que les fichiers plats (recommandé) :
    1. --generate-schema-script : écrit extract_schema_tables.sas, à exécuter dans SAS -> schema_tables.csv
    2. --schema-ref schema_tables.csv : DCP construits à partir du schéma SAS réel
    Sans ces options : description lue directement par pyreadstat (dépannage).

Sorties :
    inventaire_tables_sas.xlsx   une ligne par table (+ onglet Utilisation si --programmes)
    DCP\\DCP_<table>__<empreinte>.xlsx   un DCP par table (même nommage que les fichiers plats). Un DCP déjà présent n'est JAMAIS
                                         écrasé (il a peut-être été rempli par le DPO).
"""
from __future__ import annotations

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI))
try:
    import pyreadstat  # noqa: F401
except ImportError:
    sys.exit("[ERREUR] pyreadstat absent : activer le venv (.\\venv\\Scripts\\activate) ou pip install pyreadstat")
from sources_sas.dcp_tables import (ENTETE_FILL, ENTETE_FONT, BASE_FONT, ROUGE,  # noqa: E402
                                    colonnes_dcp, ecrire_dcp, lire_description, nom_dcp)


# ---------------------------------------------------------------- utilisation par les programmes
def sans_commentaires(code: str) -> str:
    code = re.sub(r"/\*.*?\*/", " ", code, flags=re.S)
    return re.sub(r"(?m)^\s*\*[^;]*;", " ", code)


def utilisation(tables: list[str], dossier_prog: Path) -> dict[str, list[tuple[str, str, int]]]:
    """table -> [(programme, CRÉE|LIT, ligne)]"""
    res: dict[str, list] = {t: [] for t in tables}
    for sas in sorted(dossier_prog.rglob("*.sas")):
        if "desensibilis" in sas.name.lower():
            continue
        try:
            code = sans_commentaires(sas.read_text(encoding="latin-1", errors="replace"))
        except OSError:
            continue
        for t in tables:
            nom = re.escape(t)
            for m in re.finditer(rf"(?i)(?<![\w&])(\w+\.)?{nom}\b", code):
                avant = code[max(0, m.start() - 60):m.start()].lower()
                ligne = code.count("\n", 0, m.start()) + 1
                cree = bool(re.search(r"(\bdata\s+[\w.\s]*|\bcreate\s+table\s+|\bout\s*=\s*|\bbase\s*=\s*)$", avant))
                res[t].append((str(sas), "CRÉE" if cree else "LIT", ligne))
    return res


# ---------------------------------------------------------------- programme
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Recense des tables SAS et prépare leurs DCP (sans lire les données).")
    ap.add_argument("--tables", nargs="+", required=True)
    ap.add_argument("--sortie", required=True)
    ap.add_argument("--programmes")
    ap.add_argument("--recursif", action="store_true")
    ap.add_argument("--date-effet", default="")
    ap.add_argument("--generate-schema-script", action="store_true",
                    help="ÉTAPE 1 (comme les fichiers plats) : script SAS d'extraction du schéma")
    ap.add_argument("--schema-ref", help="ÉTAPE 2 : CSV produit par le script SAS -> DCP depuis le schéma SAS")
    a = ap.parse_args(argv)

    fichiers: list[Path] = []
    for t in a.tables:
        p = Path(t)
        if p.is_dir():
            motif = "**/*" if a.recursif else "*"
            fichiers += sorted(x for x in p.glob(motif) if x.suffix.lower() in (".sas7bdat", ".xpt"))
        elif p.is_file():
            fichiers.append(p)
        else:
            print(f"[ERREUR] Introuvable : {p}")
    if not fichiers:
        sys.exit("[ERREUR] Aucune table .sas7bdat trouvée.")
    import os
    fichiers = [Path(os.path.abspath(f)) for f in fichiers]     # même chemin dans le script SAS et au retour
    sortie = Path(a.sortie)
    dossier_dcp = sortie / "DCP"
    print(f"{len(fichiers)} table(s) à recenser -> {sortie}")
    from sources_sas.cartographie_tables import charger_schema, generer_script_schema
    from sources_sas.dcp_tables import MetaSchema, colonnes_depuis_schema
    if a.generate_schema_script:
        sas, csvp = sortie / "extract_schema_tables.sas", sortie / "schema_tables.csv"
        generer_script_schema([(f.stem, str(f)) for f in fichiers], sas, csvp)
        print(f"-> Script SAS : {sas}\n   1. Exécutez-le dans SAS (lecture seule)\n   2. Il produit : {csvp}"
              f"\n   3. Relancez avec : --schema-ref '{csvp}'")
        return 0
    schema = charger_schema(a.schema_ref) if a.schema_ref else None
    if schema is not None:
        from cartographie.dcp_generator import _cle_physique

    lignes = []
    for f in fichiers:
        st = f.stat()
        info = {"Table": f.stem, "Fichier": f.name, "Dossier": str(f.parent),
                "Taille (Mo)": round(st.st_size / 1024 ** 2, 2),
                "Modifiée le": datetime.fromtimestamp(st.st_mtime).strftime("%d/%m/%Y %H:%M")}
        try:
            if schema is not None:
                entrees = schema.get(_cle_physique(str(f), ""))
                if not entrees:
                    raise ValueError("absente du schéma SAS (script non exécuté ou table illisible côté SAS)")
                meta, cols = MetaSchema(f.stem.upper()), colonnes_depuis_schema(entrees)
                meta.file_label = meta.file_encoding = ""
            else:
                meta = lire_description(f)
                cols = colonnes_dcp(meta)
            cible = dossier_dcp / nom_dcp(f)
            if cible.exists():
                statut, alertes = "DCP déjà présent : conservé tel quel", []
            else:
                alertes = ecrire_dcp(f, meta, cols, cible, a.date_effet)
                statut = "DCP créé" + (f" ({len(alertes)} alerte(s) F99)" if alertes else "")
            info.update({"Lignes": meta.number_rows, "Colonnes": len(cols),
                         "Colonnes caractère": sum(c["type"] == "C" for c in cols),
                         "Libellé de la table": meta.file_label or "", "Encodage": meta.file_encoding or "",
                         "DCP": cible.name, "Statut": statut,
                         "Liste des colonnes": ", ".join(c["nom"] for c in cols)})
        except Exception as e:  # noqa: BLE001
            info.update({"Statut": f"ILLISIBLE : {type(e).__name__} {e}"})
        lignes.append(info)
        print(f"  {f.name:45s} {info.get('Statut')}")

    usage = utilisation([f.stem for f in fichiers], Path(a.programmes)) if a.programmes else None
    if usage is not None:
        for l in lignes:
            u = usage.get(l["Table"], [])
            cree = sorted({Path(p).name for p, k, _ in u if k == "CRÉE"})
            lit = sorted({Path(p).name for p, k, _ in u if k == "LIT"})
            l["Créée par"] = ", ".join(cree)
            l["Lue par"] = ", ".join(lit)
            l["Lecture"] = ("table intermédiaire (créée par nos programmes) : anonymisation a priori inutile"
                            if cree else "SOURCE (lue, jamais créée par nos programmes) : à anonymiser" if lit
                            else "non trouvée dans les programmes : demander qui la produit")

    wb = Workbook()
    ws = wb.active
    ws.title = "Tables_SAS"
    entetes = ["Table", "Fichier", "Dossier", "Lignes", "Colonnes", "Colonnes caractère", "Taille (Mo)",
               "Modifiée le", "Libellé de la table", "Encodage", "DCP", "Statut"]
    if usage is not None:
        entetes += ["Créée par", "Lue par", "Lecture"]
    entetes += ["Liste des colonnes"]
    for j, h in enumerate(entetes, 1):
        c = ws.cell(row=1, column=j, value=h)
        c.font, c.fill = ENTETE_FONT, ENTETE_FILL
        c.alignment = Alignment(horizontal="center", wrap_text=True)
    for i, l in enumerate(lignes, 2):
        for j, h in enumerate(entetes, 1):
            c = ws.cell(row=i, column=j, value=l.get(h, ""))
            c.font = BASE_FONT
            if str(l.get("Statut", "")).startswith("ILLISIBLE"):
                c.fill = ROUGE
    for j, h in enumerate(entetes, 1):
        ws.column_dimensions[get_column_letter(j)].width = {"Dossier": 50, "Statut": 30, "Lecture": 55,
                                                            "Liste des colonnes": 80, "DCP": 45,
                                                            "Créée par": 35, "Lue par": 35}.get(h, 14)
    ws.freeze_panes = "B2"
    if usage is not None:
        wu = wb.create_sheet("Utilisation")
        wu.append(["Table", "Programme", "Usage", "Ligne"])
        for t, occ in usage.items():
            for p, k, n in occ:
                wu.append([t, p, k, n])
        for j, w in enumerate([30, 90, 10, 8], 1):
            wu.column_dimensions[get_column_letter(j)].width = w
    sortie.mkdir(parents=True, exist_ok=True)
    cible = sortie / "inventaire_tables_sas.xlsx"
    if cible.exists():
        cible = sortie / f"inventaire_tables_sas_{datetime.now():%Y%m%d_%H%M}.xlsx"
    try:
        wb.save(cible)
    except PermissionError:
        sys.exit("[ERREUR] Inventaire ouvert dans Excel : le fermer et relancer.")
    print(f"\nInventaire : {cible}\nDCP : {dossier_dcp}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
