# -*- coding: utf-8 -*-
"""Lineage et classification des tables lues par les programmes.

Chaque lecture reçoit UNE classification et la RÈGLE qui l'a produite. En cas de doute : A_VERIFIER.
Ordre des règles (la première qui s'applique décide) :
  EXCLU_WORK                       bibliothèque WORK (ou nom à un niveau)
  EXCLU_BIBLIOTHEQUE_SYSTEME       SASHELP, SASUSER, MAPS...
  NOM_DYNAMIQUE_NON_RESOLU         &LIB..&TABLE non résolu                    -> A_VERIFIER
  PRODUIT_DANS_MEME_PROGRAMME      écrite plus haut dans le même programme     -> SORTIE_PROGRAMME
  LIBREF_NON_RESOLU                aucun LIBNAME trouvé                         -> NON_RESOLU
  CHEMIN_MACRO_NON_RESOLUE         chemin du LIBNAME avec macro inconnue        -> NON_RESOLU
  LIBNAME_COMPLEXE                 concaténation, moteur sans chemin            -> A_VERIFIER
  FICHIER_PLAT_EXCEL               LIBNAME XLSX/EXCEL : couvert par la carto des fichiers plats
  INFOCENTRE_PAR_CHEMIN            chemin du LIBNAME reconnu comme Infocentre   -> INFOCENTRE
  PRODUIT_DANS_PROGRAMME_PRECEDENT même fichier physique écrit par une étape antérieure du même lanceur
  PRODUIT_PAR_AUTRE_PROGRAMME      même fichier physique écrit par un programme du périmètre (ordre inconnu)
  PRODUIT_PAR_ETAPE_ULTERIEURE     écrit par une étape SUIVANTE : état d'une exécution précédente -> A_VERIFIER
  TABLE_HISTORISEE                 lue puis réécrite par le même programme (historique)          -> A_VERIFIER
  VUE_SAS                          seule une vue .sas7bvew existe               -> A_VERIFIER
  FICHIER_ABSENT / CHEMIN_INACCESSIBLE                                          -> A_VERIFIER
  EXTERNE_PAR_LIBNAME_RESOLU       tout le reste : table SAS externe            -> EXTERNE_SAS
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path

from .analyse import FichierSAS
from .resolution import Contexte, Resolveur, Valeur, cle_fichier, norm, resoudre_texte

BIBLIOTHEQUES_SYSTEME = {"SASHELP", "SASUSER", "MAPS", "MAPSSAS", "MAPSGFK", "SASMSG"}
MOTEURS_EXCEL = {"xlsx", "xls", "excel", "excelcs", "pcfiles"}
MOTEURS_SGBD = {"oracle", "odbc", "db2", "teradata", "sqlsvr", "oledb", "bigquery", "postgres", "mysql",
                "hadoop", "meta", "remote"}

REGLES = {
    "EXCLU_WORK": "Bibliothèque WORK (ou nom à un niveau) : table temporaire.",
    "EXCLU_BIBLIOTHEQUE_SYSTEME": "Bibliothèque système SAS (SASHELP, SASUSER...).",
    "NOM_DYNAMIQUE_NON_RESOLU": "Bibliothèque ou table construite par macro-variable non résolue.",
    "PRODUIT_DANS_MEME_PROGRAMME": "Table écrite plus haut dans le même programme, puis relue.",
    "ECRITURE": "Table écrite par le programme (sortie).",
    "LIBREF_NON_RESOLU": "Aucun LIBNAME trouvé (programme, %include, lanceur, configuration) : pré-assignée ou définie ailleurs.",
    "CHEMIN_MACRO_NON_RESOLUE": "Le chemin du LIBNAME contient une macro-variable de valeur inconnue.",
    "LIBNAME_COMPLEXE": "Bibliothèque concaténée ou moteur sans chemin : à examiner.",
    "FICHIER_PLAT_EXCEL": "LIBNAME sur un classeur Excel : relève de la cartographie des fichiers plats.",
    "SGBD_HORS_PERIMETRE": "LIBNAME vers une base de données (Oracle, ODBC...) : hors périmètre .sas7bdat.",
    "INFOCENTRE_PAR_CHEMIN": "Chemin du LIBNAME reconnu comme Infocentre (motifs --infocentre / configuration).",
    "PRODUIT_DANS_PROGRAMME_PRECEDENT": "Même fichier physique écrit par une étape ANTÉRIEURE du même lanceur.",
    "PRODUIT_PAR_AUTRE_PROGRAMME": "Même fichier physique écrit par un autre programme du périmètre.",
    "PRODUIT_PAR_ETAPE_ULTERIEURE": "Écrit par une étape SUIVANTE du lanceur : la lecture porte sur l'état d'une exécution précédente.",
    "TABLE_HISTORISEE": "Lue puis réécrite par le même programme (historique / mise à jour) : l'état initial est une source.",
    "VUE_SAS": "Seule une vue SAS (.sas7bvew) existe à cet emplacement.",
    "FICHIER_ABSENT": "Le dossier existe mais pas le fichier .sas7bdat.",
    "CHEMIN_INACCESSIBLE": "Dossier de la bibliothèque inaccessible depuis ce poste.",
    "EXTERNE_PAR_LIBNAME_RESOLU": "Table SAS lue, LIBNAME résolu hors Infocentre, non produite par le périmètre, fichier présent.",
    "EXTERNE_NON_VERIFIE_DISQUE": "Comme EXTERNE_PAR_LIBNAME_RESOLU, existence du fichier non vérifiée (--sans-test-disque).",
    "CLASSIFICATIONS_DIVERGENTES": "La même source reçoit des classifications différentes selon les programmes.",
}


@dataclass
class Ligne:
    lot: str
    domaine: str
    programme: str
    chemin_programme: str
    lanceur: str
    type_instruction: str
    ligne: int
    libref: str
    table: str
    chemin_librairie: str = ""
    chemin_physique: str = ""
    type_source: str = "SAS"
    classification: str = ""
    regle: str = ""
    est_infocentre: bool = False
    est_input: bool = False
    est_sortie: bool = False
    producteur: str = ""
    defini_dans: str = ""
    source_mapping: str = ""
    macro_resolue: str = ""
    statut_resolution: str = ""
    commentaire: str = ""

    @property
    def est_externe(self) -> bool:
        return self.classification == "EXTERNE_SAS"

    @property
    def a_desensibiliser(self) -> str:
        if self.classification == "EXTERNE_SAS":
            return "OUI"
        if self.classification in ("A_VERIFIER", "NON_RESOLU") and self.est_input and self.type_source in ("SAS", "VUE"):
            return "A VERIFIER"
        return "NON"


def joindre(dossier: str, fichier: str) -> str:
    sep = "\\" if ("\\" in dossier or re.match(r"^[A-Za-z]:", dossier)) else "/"
    return dossier.rstrip("\\/") + sep + fichier


class Analyseur:
    def __init__(self, racine: Path, fichiers: dict[str, FichierSAS], resolveur: Resolveur, lot: str,
                 motifs_infocentre: list[str], tester_disque: bool = True):
        self.racine, self.fichiers, self.res, self.lot = racine, fichiers, resolveur, lot
        self.motifs = [re.compile(m, re.I) for m in motifs_infocentre]
        self.tester = tester_disque
        self.lignes: list[Ligne] = []
        self._cache_disque: dict[str, str] = {}

    def domaine(self, chemin: Path) -> str:
        try:
            rel = chemin.relative_to(self.racine)
            return rel.parts[0] if len(rel.parts) > 1 else self.racine.name
        except ValueError:
            return ""

    # ---------------------------------------------------------------- passe 1 : accès résolus
    def collecter(self):
        for cle, f in sorted(self.fichiers.items()):
            ctx0, lanceurs = self.res.contexte_initial(cle)
            ctx = Contexte(macros=dict(ctx0.macros), libnames=dict(ctx0.libnames), dynamiques=set(ctx0.dynamiques))
            incl = {p: (c, ch) for p, c, ch in self.res.includes_resolus(f, ctx.macros)}
            ev = [(l.ligne, 0, "let", l) for l in f.lets] + [(lb.ligne, 0, "lib", lb) for lb in f.libnames]
            ev += [(lg, 0, "inc", incl.get(p)) for p, lg, _ in f.includes if incl.get(p)]
            ev += [(a.ligne, 1, "acc", a) for a in f.acces]
            for _, _, typ, obj in sorted(ev, key=lambda e: (e[0], e[1])):
                if typ == "let":
                    ctx.macros[obj.nom] = Valeur(obj.valeur, "programme", obj.fichier, obj.ligne)
                elif typ == "lib":
                    ref, _, _ = resoudre_texte(obj.ref, ctx.macros, ctx.dynamiques)
                    ctx.libnames[ref.upper()] = (obj, "programme")
                elif typ == "inc":
                    c, ch = obj
                    if c not in self.fichiers:
                        inc = self.res.fichier(c, ch)
                        if inc and inc.lisible:
                            self.res._absorber(ctx, inc, None, "include")
                else:
                    self.lignes.append(self._ligne(f, obj, ctx, lanceurs))

    def _ligne(self, f: FichierSAS, a, ctx: Contexte, lanceurs: list[str]) -> Ligne:
        lib, res_l, non_l = resoudre_texte(a.lib, ctx.macros, ctx.dynamiques)
        table, res_t, non_t = resoudre_texte(a.table, ctx.macros, ctx.dynamiques)
        l = Ligne(self.lot, self.domaine(f.chemin), f.chemin.name, str(f.chemin), ", ".join(lanceurs),
                  a.instruction, a.ligne, lib.upper(), table.upper(),
                  est_input=a.sens == "LIT", est_sortie=a.sens == "ECRIT",
                  macro_resolue="; ".join(res_l + res_t))
        l.type_source = "VUE" if a.vue else "SAS"
        if non_l or non_t:
            l.statut_resolution = "NOM_DYNAMIQUE_NON_RESOLU"
            l.commentaire = "macro-variable(s) non résolue(s) : " + ", ".join("&" + n for n in non_l + non_t)
            return l
        if l.libref in ("WORK", "USER") or l.libref in BIBLIOTHEQUES_SYSTEME:
            l.statut_resolution = "SANS_OBJET"
            return l
        r = self.res.resoudre_lib(l.libref, f, a.ligne, ctx, {})
        l.statut_resolution, l.defini_dans, l.source_mapping = r.statut, r.defini_dans, r.source_mapping
        l.chemin_librairie = r.chemin or r.chemin_brut
        if r.commentaire:
            l.macro_resolue = "; ".join(x for x in (l.macro_resolue, r.commentaire if r.statut == "RESOLU" else "") if x)
            if r.statut != "RESOLU":
                l.commentaire = r.commentaire
        if r.moteur in MOTEURS_EXCEL:
            l.type_source = "EXCEL"
        elif r.moteur in MOTEURS_SGBD:
            l.type_source = "SGBD"
        if r.statut == "RESOLU" and l.type_source in ("SAS", "VUE"):
            l.chemin_physique = joindre(r.chemin, l.table.lower() + ".sas7bdat")
        return l

    # ---------------------------------------------------------------- passe 2 : classification
    def ordre(self, l: Ligne) -> dict[str, int]:
        """lanceur -> rang du programme dans ce lanceur."""
        cle = cle_fichier(l.chemin_programme)
        return {self.fichiers[lc].chemin.name: rang for lc, rang in self.res.inclus_par.get(cle, [])}

    def classer(self):
        ecritures_phys: dict[str, list[Ligne]] = {}
        for l in self.lignes:
            if l.est_sortie and l.chemin_physique:
                ecritures_phys.setdefault(cle_fichier(l.chemin_physique), []).append(l)
        for l in self.lignes:
            if l.est_sortie:
                self._fixer(l, "SORTIE_PROGRAMME", "ECRITURE") if l.libref not in ("WORK", "USER") else \
                    self._fixer(l, "WORK_INTERMEDIAIRE", "EXCLU_WORK")
                continue
            self._classer_lecture(l, ecritures_phys)

    def _fixer(self, l: Ligne, classe: str, regle: str, comm: str = ""):
        l.classification, l.regle = classe, regle
        if comm:
            l.commentaire = "; ".join(x for x in (l.commentaire, comm) if x)

    def _classer_lecture(self, l: Ligne, ecritures_phys: dict[str, list[Ligne]]):
        if l.statut_resolution == "NOM_DYNAMIQUE_NON_RESOLU":
            return self._fixer(l, "A_VERIFIER", "NOM_DYNAMIQUE_NON_RESOLU")
        if l.libref in ("WORK", "USER"):
            return self._fixer(l, "WORK_INTERMEDIAIRE", "EXCLU_WORK")
        if l.libref in BIBLIOTHEQUES_SYSTEME:
            return self._fixer(l, "WORK_INTERMEDIAIRE", "EXCLU_BIBLIOTHEQUE_SYSTEME")
        meme = [e for e in self.lignes if e.est_sortie and e.chemin_programme == l.chemin_programme
                and e.libref == l.libref and e.table == l.table]
        if any(e.ligne < l.ligne for e in meme):
            return self._fixer(l, "SORTIE_PROGRAMME", "PRODUIT_DANS_MEME_PROGRAMME",
                               f"écrite ligne {min(e.ligne for e in meme)}")
        if l.statut_resolution == "NON_RESOLU":
            return self._fixer(l, "NON_RESOLU", "LIBREF_NON_RESOLU")
        if l.statut_resolution == "CHEMIN_MACRO_NON_RESOLUE":
            return self._fixer(l, "NON_RESOLU", "CHEMIN_MACRO_NON_RESOLUE")
        if l.statut_resolution == "COMPLEXE":
            return self._fixer(l, "A_VERIFIER", "LIBNAME_COMPLEXE")
        if l.type_source == "EXCEL":
            return self._fixer(l, "A_VERIFIER", "FICHIER_PLAT_EXCEL")
        if l.type_source == "SGBD":
            return self._fixer(l, "A_VERIFIER", "SGBD_HORS_PERIMETRE")
        if any(m.search(l.chemin_librairie) for m in self.motifs):
            l.est_infocentre = True
            return self._fixer(l, "INFOCENTRE", "INFOCENTRE_PAR_CHEMIN")
        autres = [e for e in ecritures_phys.get(cle_fichier(l.chemin_physique), []) if e.chemin_programme != l.chemin_programme]
        if autres:
            rangs = self.ordre(l)
            avant, apres, inconnu = [], [], []
            for e in autres:
                rangs_e = self.ordre(e)
                communs = set(rangs) & set(rangs_e)
                if not communs:
                    inconnu.append(e)
                elif all(rangs_e[lc] < rangs[lc] for lc in communs):
                    avant.append(e)
                else:
                    apres.append(e)
            nomsp = lambda xs: ", ".join(sorted({x.programme for x in xs}))  # noqa: E731
            if avant:
                l.producteur = nomsp(avant)
                return self._fixer(l, "SORTIE_PROGRAMME_PRECEDENT", "PRODUIT_DANS_PROGRAMME_PRECEDENT")
            if inconnu:
                l.producteur = nomsp(inconnu)
                return self._fixer(l, "SORTIE_PROGRAMME_PRECEDENT", "PRODUIT_PAR_AUTRE_PROGRAMME",
                                   "ordre d'exécution inconnu : vérifier que le producteur tourne avant")
            l.producteur = nomsp(apres)
            return self._fixer(l, "A_VERIFIER", "PRODUIT_PAR_ETAPE_ULTERIEURE")
        if any(e.ligne > l.ligne for e in [e for e in self.lignes if e.est_sortie and
                                           e.chemin_programme == l.chemin_programme and
                                           e.libref == l.libref and e.table == l.table]):
            return self._fixer(l, "A_VERIFIER", "TABLE_HISTORISEE")
        if not self.tester:
            return self._fixer(l, "EXTERNE_SAS", "EXTERNE_NON_VERIFIE_DISQUE")
        etat = self._disque(l.chemin_librairie, l.chemin_physique)
        if etat == "OK":
            return self._fixer(l, "EXTERNE_SAS", "EXTERNE_PAR_LIBNAME_RESOLU")
        if etat == "VUE":
            l.type_source = "VUE"
            return self._fixer(l, "A_VERIFIER", "VUE_SAS")
        return self._fixer(l, "A_VERIFIER", etat)

    def _disque(self, dossier: str, fichier: str) -> str:
        if fichier not in self._cache_disque:
            if os.path.isfile(fichier):
                r = "OK"
            elif os.path.isfile(fichier[:-len(".sas7bdat")] + ".sas7bvew"):
                r = "VUE"
            elif os.path.isdir(dossier):
                r = "FICHIER_ABSENT"
            else:
                r = "CHEMIN_INACCESSIBLE"
            self._cache_disque[fichier] = r
        return self._cache_disque[fichier]


# -------------------------------------------------------------------- consolidation
@dataclass
class Source:
    lot: str
    domaine: str
    libref: str
    table: str
    chemin_librairie: str
    chemin_fichier: str
    programmes: list[str] = field(default_factory=list)
    classification: str = ""
    regle: str = ""
    type_source: str = "SAS"
    statut: str = ""
    producteur: str = ""
    commentaire: str = ""

    @property
    def a_desensibiliser(self) -> str:
        if self.classification == "EXTERNE_SAS":
            return "OUI"
        if self.classification in ("A_VERIFIER", "NON_RESOLU") and self.type_source in ("SAS", "VUE"):
            return "A VERIFIER"
        return "NON"


def consolider(lignes: list[Ligne]) -> list[Source]:
    groupes: dict[str, list[Ligne]] = {}
    for l in lignes:
        if not l.est_input or l.classification in ("WORK_INTERMEDIAIRE",):
            continue
        cle = cle_fichier(l.chemin_physique) if l.chemin_physique else f"{l.libref}.{l.table}|{l.statut_resolution}|{l.chemin_librairie}"
        groupes.setdefault(cle, []).append(l)
    out = []
    for g in groupes.values():
        p = g[0]
        classes = sorted({x.classification for x in g})
        s = Source(p.lot, ", ".join(sorted({x.domaine for x in g})), ", ".join(sorted({x.libref for x in g})),
                   p.table, p.chemin_librairie,
                   p.chemin_physique, sorted({x.programme for x in g}), type_source=p.type_source,
                   producteur=", ".join(sorted({x.producteur for x in g if x.producteur})))
        if len(classes) == 1:
            s.classification = classes[0]
            s.regle = ", ".join(sorted({x.regle for x in g}))
        else:
            s.classification, s.regle = "A_VERIFIER", "CLASSIFICATIONS_DIVERGENTES"
            s.commentaire = " / ".join(f"{x.programme}: {x.classification} ({x.regle})" for x in g)
        s.statut = ", ".join(sorted({x.statut_resolution for x in g if x.statut_resolution}))
        coms = sorted({x.commentaire for x in g if x.commentaire})
        s.commentaire = "; ".join([s.commentaire] + coms if s.commentaire else coms)
        out.append(s)
    return sorted(out, key=lambda s: (s.classification, s.libref, s.table))
