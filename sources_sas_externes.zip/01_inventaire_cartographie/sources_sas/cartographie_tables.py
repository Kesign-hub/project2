# -*- coding: utf-8 -*-
"""Cartographie des tables SAS externes, À L'IDENTIQUE de la cartographie des fichiers plats :
  * DCP dans <cartographie>\\DCP\\<domaine>\\, nommés DCP_<table>__<empreinte du chemin physique>.xlsx
    (même fonction de nommage que generate_cartography.py) ;
  * inventaire au format de inventaire_fichiers_plats.xlsx (onglets Inventaire + Fichiers_uniques),
    pour que la suite de la chaîne (DPO, completer_dcp_ref_anonym, generer_anonym_liste_fic) fonctionne
    sans changement ;
  * un DCP déjà présent n'est jamais écrasé (il a peut-être été rempli par le DPO).
Aucune donnée n'est lue : seulement la description (en-tête) des tables."""
from __future__ import annotations

import os
import re
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook

from . import dcp_tables
from .lineage import Ligne, Source

try:
    from cartographie.reports import COLONNES_INVENTAIRE, COLONNES_UNIQUES
except ImportError:  # même ordre de colonnes que cartographie/reports.py
    COLONNES_INVENTAIRE = ["script", "chemin_script", "ligne", "type_acces", "source_direction", "table_sas_creee",
                           "chemin_brut", "chemin_resolu", "repertoire", "nom_fichier", "extension",
                           "extension_inferee", "dbms", "sheet", "sheet_resolu", "sheet_statut", "getnames",
                           "delimiter", "encoding", "macrovariables", "statut_macro", "fichier_existe",
                           "a_anonymiser", "commentaire"]
    COLONNES_UNIQUES = ["chemin_normalise", "nom_fichier", "extension", "scripts_consommateurs", "nb_utilisations",
                        "onglets", "tables_sas_creees", "statut_accessibilite"]


def _sas(texte: str) -> str:
    """Littéral SAS entre apostrophes : pas de résolution de & ni de % (chemins sûrs)."""
    return "'" + str(texte).replace("'", "''") + "'"


def generer_script_schema(tables: list[tuple[str, str]], chemin_sas: Path, chemin_csv: Path) -> int:
    """Même étape que generate_cartography.py --generate-schema-script, pour des tables SAS :
    un LIBNAME en lecture seule par dossier, dictionary.columns par table (aucune donnée lue),
    CSV consolidé au format attendu par --schema-ref (SOURCE, NAME, TYPE, LENGTH, FORMAT, VARNUM,
    SOURCE_PATH, SHEET, LABEL). tables = [(nom affiché, chemin du .sas7bdat)]."""
    try:
        from generate_cartography import _vers_unc_pour_sas as unc
    except Exception:  # noqa: BLE001
        def unc(c):
            return c
    par_dossier: dict[str, list[tuple[str, str]]] = {}
    for nom, chemin in tables:
        dossier, _, fichier = str(chemin).replace("/", "\\").rpartition("\\")
        par_dossier.setdefault(dossier, []).append((fichier.rsplit(".", 1)[0].upper(), chemin))
    l = ["/* ================================================================= */",
         "/* Script auto-généré par inventorier_sources_sas_externes.py        */",
         "/* Extrait le schéma (colonnes, types, longueurs, formats) des       */",
         "/* tables SAS externes. LECTURE SEULE, aucune donnée lue.            */",
         "/* Produit un CSV consolidé utilisable via --schema-ref              */",
         "/* ================================================================= */", "",
         "data WORK._SCHEMA_ALL; length SOURCE $200 NAME $50 TYPE $4 LENGTH 8 FORMAT $49 VARNUM 8 "
         "SOURCE_PATH $400 SHEET $200 LABEL $256; stop; run;", ""]
    for i, (dossier, liste) in enumerate(sorted(par_dossier.items()), 1):
        ref = f"_T{i}"
        l.append(f"libname {ref} {_sas(unc(dossier))} access=readonly;")
        l.append("proc sql;")
        for memname, chemin in liste:
            nomf = str(chemin).replace("/", "\\").rpartition("\\")[2]
            l += [f"  insert into WORK._SCHEMA_ALL (SOURCE, NAME, TYPE, LENGTH, FORMAT, VARNUM, SOURCE_PATH, SHEET, LABEL)",
                  f"  select {_sas(nomf)}, name, type, length, format, varnum, {_sas(chemin)}, '', label",
                  f"  from dictionary.columns where libname='{ref}' and memname={_sas(memname)} and memtype='DATA';"]
        l += ["quit;", f"libname {ref} clear;", ""]
    l += ["proc sort data=WORK._SCHEMA_ALL nodupkey; by SOURCE_PATH NAME VARNUM; run;",
          "proc sort data=WORK._SCHEMA_ALL; by SOURCE_PATH VARNUM; run;", "",
          "proc export data=WORK._SCHEMA_ALL", f"    outfile={_sas(unc(str(chemin_csv)))}", "    dbms=csv replace;", "run;", "",
          f"%put NOTE: Schema exporte : {len(tables)} table(s) demandee(s). Relancer Python avec --schema-ref;"]
    chemin_sas.parent.mkdir(parents=True, exist_ok=True)
    chemin_sas.write_text("\n".join(l), encoding="latin-1", errors="replace")
    return len(tables)


def charger_schema(chemin_csv: str) -> dict[str, list[dict]]:
    """CSV de schéma -> {clé physique: [colonnes]} (même lecteur que les fichiers plats)."""
    from cartographie.dcp_generator import _charger_schema_ref, _cle_physique
    entrees = _charger_schema_ref(chemin_csv) or []
    par_table: dict[str, list[dict]] = {}
    for e in entrees if isinstance(entrees, list) else []:
        if e.get("source_path"):
            par_table.setdefault(_cle_physique(e["source_path"], ""), []).append(e)
    # le libellé n'est pas repris par _charger_schema_ref : relu directement
    import csv
    with open(chemin_csv, encoding="utf-8", errors="replace", newline="") as fh:
        labels = {( _cle_physique(r.get("SOURCE_PATH", ""), ""), (r.get("NAME") or "").upper().strip()): r.get("LABEL", "")
                  for r in csv.DictReader(fh)}
    for cle, cols in par_table.items():
        for c in cols:
            c["label"] = labels.get((cle, c["name"]), "")
    return par_table


def cartographier(sources: list[Source], lignes: list[Ligne], dossier: Path, suffixe: str, date_effet: str,
                  schema_ref: str | None = None) -> dict:
    retenues = [s for s in sources if s.classification == "EXTERNE_SAS" and s.chemin_fichier]
    bilan = {"dcp_crees": 0, "dcp_existants": 0, "illisibles": 0, "absents": 0, "sans_schema": 0}
    schema = charger_schema(schema_ref) if schema_ref else None
    if schema is not None:
        from cartographie.dcp_generator import _cle_physique
    rapport = []
    for s in retenues:
        dom = re.sub(r'[<>:"/\\|?*]', "_", s.domaine.split(",")[0].strip() or "Sans_domaine")
        cible = dossier / "DCP" / dom / dcp_tables.nom_dcp(s.chemin_fichier)
        if cible.exists():
            bilan["dcp_existants"] += 1
            rapport.append([s.table, s.chemin_fichier, str(cible), "DCP déjà présent : conservé"])
            continue
        if schema is not None:                      # circuit des fichiers plats : schéma SAS réel
            cols_ref = schema.get(_cle_physique(s.chemin_fichier, ""))
            if not cols_ref:
                bilan["sans_schema"] += 1
                rapport.append([s.table, s.chemin_fichier, "", "absente du schéma SAS (script non exécuté, "
                                "table introuvable côté SAS ?) : DCP non créé"])
                continue
            alertes = dcp_tables.ecrire_dcp(s.chemin_fichier, dcp_tables.MetaSchema(s.table),
                                            dcp_tables.colonnes_depuis_schema(cols_ref), cible, date_effet)
            bilan["dcp_crees"] += 1
            rapport.append([s.table, s.chemin_fichier, str(cible), "DCP créé (schéma SAS)"
                            + (f" ({len(alertes)} alerte(s) F99)" if alertes else "")])
            continue
        if not os.path.isfile(s.chemin_fichier):
            bilan["absents"] += 1
            rapport.append([s.table, s.chemin_fichier, "", "fichier introuvable : DCP non créé"])
            continue
        try:
            meta = dcp_tables.lire_description(s.chemin_fichier)
            alertes = dcp_tables.ecrire_dcp(s.chemin_fichier, meta, dcp_tables.colonnes_dcp(meta), cible, date_effet)
            bilan["dcp_crees"] += 1
            rapport.append([s.table, s.chemin_fichier, str(cible),
                            "DCP créé (description lue par pyreadstat)" + (f" ({len(alertes)} alerte(s) F99)" if alertes else "")])
        except Exception as e:  # noqa: BLE001
            bilan["illisibles"] += 1
            rapport.append([s.table, s.chemin_fichier, "", f"illisible : {type(e).__name__} {e}"])

    # ---- inventaire au format des fichiers plats
    garde = {s.chemin_fichier.lower() for s in retenues}
    wb = Workbook()
    ws = wb.active
    ws.title = "Inventaire"
    ws.append(COLONNES_INVENTAIRE)
    for l in lignes:
        if l.chemin_physique.lower() not in garde or not l.est_input:
            continue
        rep, _, nom = l.chemin_physique.replace("/", "\\").rpartition("\\")
        v = {"script": l.programme, "chemin_script": l.chemin_programme, "ligne": l.ligne,
             "type_acces": "TABLE_SAS:" + l.type_instruction, "source_direction": "INPUT",
             "table_sas_creee": f"{l.libref}.{l.table}", "chemin_brut": l.chemin_physique,
             "chemin_resolu": l.chemin_physique, "repertoire": rep, "nom_fichier": nom, "extension": ".sas7bdat",
             "extension_inferee": "", "dbms": "SAS", "macrovariables": l.macro_resolue,
             "statut_macro": "RESOLU", "fichier_existe": "OUI" if os.path.isfile(l.chemin_physique) else "NON",
             "a_anonymiser": "A_COMPLETER", "commentaire": f"LIBNAME {l.libref} défini dans {l.defini_dans}"}
        ws.append([v.get(c, "") for c in COLONNES_INVENTAIRE])
    wu = wb.create_sheet("Fichiers_uniques")
    wu.append(COLONNES_UNIQUES)
    for s in retenues:
        v = {"chemin_normalise": s.chemin_fichier.lower(), "nom_fichier": Path(s.chemin_fichier.replace("\\", "/")).name,
             "extension": ".sas7bdat", "scripts_consommateurs": "; ".join(s.programmes),
             "nb_utilisations": len(s.programmes), "onglets": "(aucun)", "tables_sas_creees": f"{s.libref}.{s.table}",
             "statut_accessibilite": "ACCESSIBLE" if os.path.isfile(s.chemin_fichier) else "INTROUVABLE"}
        wu.append([v.get(c, "") for c in COLONNES_UNIQUES])
    wr = wb.create_sheet("DCP_tables")
    wr.append(["Table", "Fichier", "DCP", "Statut"])
    for r in rapport:
        wr.append(r)
    dossier.mkdir(parents=True, exist_ok=True)
    inv = dossier / f"inventaire_tables_sas{suffixe}.xlsx"
    if inv.exists():
        inv = dossier / f"inventaire_tables_sas{suffixe}_{datetime.now():%Y%m%d_%H%M}.xlsx"
    wb.save(inv)
    bilan["inventaire"] = str(inv)
    return bilan
