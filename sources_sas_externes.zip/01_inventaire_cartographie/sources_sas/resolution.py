# -*- coding: utf-8 -*-
"""Contexte de résolution d'un programme : macro-variables et LIBNAME visibles, avec leur origine
(programme, %include, lanceur, configuration, date.sas). Rien n'est deviné : une valeur non trouvée
reste non résolue."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path, PureWindowsPath

from .analyse import FichierSAS, Let, Libname, analyser_fichier

RE_MACRO = re.compile(r"&+([A-Za-z_]\w*)\.?")
RE_DYNAMIQUE = re.compile(r"%(sysfunc|eval|sysevalf|scan|substr|upcase|lowcase|qsysfunc|str|nrstr|bquote)|\btoday\s*\(", re.I)


def norm(chemin: str) -> str:
    """Clé de comparaison d'un chemin : minuscules, séparateurs \\, sans \\ final, serveur UNC court."""
    p = str(chemin or "").strip().replace("/", "\\").lower().rstrip("\\")
    m = re.match(r"^\\\\([^\\]+)(\\.*)?$", p)
    if m:
        p = "\\\\" + m.group(1).split(".")[0] + (m.group(2) or "")
    return re.sub(r"(?<!^)\\{2,}", r"\\", p)


def _unc(chemin: str) -> str:
    try:
        from generate_cartography import _vers_unc_pour_sas
        return _vers_unc_pour_sas(chemin)
    except Exception:  # noqa: BLE001
        return chemin


def cle_fichier(chemin: str) -> str:
    """Identité d'un fichier .sas : chemin absolu, lecteur mappé converti en UNC (M:\\ et \\\\serveur\\...
    désignent alors le même fichier), puis normalisé. Sert à relier un %include au programme inclus."""
    c = str(chemin)
    if not (c.startswith("\\\\") or re.match(r"^[A-Za-z]:", c)):
        c = os.path.abspath(c)
    return norm(_unc(c))


@dataclass
class Valeur:
    valeur: str
    source: str          # programme | include | lanceur | config | date.sas
    fichier: str
    ligne: int = 0


@dataclass
class Contexte:
    """Définitions visibles AVANT l'exécution du programme (config, date.sas, lanceur, includes)."""
    macros: dict[str, Valeur] = field(default_factory=dict)
    libnames: dict[str, tuple[Libname, str]] = field(default_factory=dict)   # REF -> (libname, source)
    dynamiques: set[str] = field(default_factory=set)


@dataclass
class ResolutionLib:
    ref: str
    statut: str                 # RESOLU | NON_RESOLU | CHEMIN_MACRO_NON_RESOLUE | COMPLEXE
    chemin: str = ""
    chemin_brut: str = ""
    moteur: str = ""
    defini_dans: str = ""
    source_mapping: str = "inconnu"
    commentaire: str = ""


def resoudre_texte(texte: str, valeurs: dict[str, Valeur], dynamiques: set[str]) -> tuple[str, list[str], list[str]]:
    """Remplace les &X. connus (valeurs statiques seulement). -> (texte, macros résolues, non résolues)."""
    resolues, non = [], []
    for _ in range(5):
        def sub(m):
            nom = m.group(1).upper()
            v = valeurs.get(nom)
            if v is None or nom in dynamiques or RE_DYNAMIQUE.search(v.valeur) or "&" in v.valeur and v.valeur == texte:
                return m.group(0)
            resolues.append(f"&{nom}={v.valeur} ({v.source}: {Path(v.fichier).name if v.fichier else ''})")
            return v.valeur
        nouveau = RE_MACRO.sub(sub, texte)
        if nouveau == texte:
            break
        texte = nouveau
    non = sorted({m.upper() for m in RE_MACRO.findall(texte)})
    return texte, list(dict.fromkeys(resolues)), non


class Resolveur:
    """Construit le contexte de chaque programme à partir des fichiers analysés, des lanceurs et de la config."""

    def __init__(self, fichiers: dict[str, FichierSAS], config: dict, macros_externes: dict[str, str],
                 dynamiques_externes: set[str], fichier_externe: str = "date.sas"):
        self.fichiers = fichiers                      # norm(chemin) -> FichierSAS (programmes du périmètre)
        self.externes: dict[str, FichierSAS] = {}     # %include hors périmètre, lus pour leurs définitions
        self.config = config or {}
        self.macros_ext = {k.upper(): Valeur(str(v), "date.sas", fichier_externe) for k, v in (macros_externes or {}).items()}
        self.dyn_ext = {d.upper() for d in (dynamiques_externes or set())}
        self.inclus_par: dict[str, list[tuple[str, int]]] = {}   # programme -> [(lanceur, rang)]
        self._graphe_includes()

    # ------------------------------------------------------------------ includes / lanceurs
    def _cible_include(self, f: FichierSAS, cible: str, valeurs: dict[str, Valeur]) -> str | None:
        if cible.startswith("FILEREF:"):
            cible = f.filenames.get(cible[8:], "")
            if not cible:
                return None
        texte, _, non = resoudre_texte(cible, valeurs, self.dyn_ext)
        if non:
            return None
        p = PureWindowsPath(texte)
        if not p.is_absolute() and not texte.startswith("\\\\") and not os.path.isabs(texte):
            texte = str(Path(f.chemin).parent / texte)
        return texte

    def fichier(self, cle: str, chemin: str) -> FichierSAS | None:
        if cle in self.fichiers:
            return self.fichiers[cle]
        if cle not in self.externes:
            self.externes[cle] = analyser_fichier(Path(chemin)) if os.path.isfile(chemin) else None
        return self.externes[cle]

    def includes_resolus(self, f: FichierSAS, valeurs: dict[str, Valeur]) -> list[tuple[int, str, str]]:
        """[(position, clé normalisée, chemin)] des %include résolus."""
        res = []
        for pos, _, cible in f.includes:
            v = dict(valeurs)
            v.update(self._lets_avant(f, pos, "programme"))
            ch = self._cible_include(f, cible, v)
            if ch:
                res.append((pos, cle_fichier(ch), ch))
        return res

    def _graphe_includes(self):
        base = self._valeurs_config(None)
        for cle, f in self.fichiers.items():
            rang = 0
            for _, cible_cle, _ in self.includes_resolus(f, base):
                if cible_cle in self.fichiers and cible_cle != cle:
                    rang += 1
                    self.inclus_par.setdefault(cible_cle, []).append((cle, rang))

    # ------------------------------------------------------------------ valeurs
    def _valeurs_config(self, programme: FichierSAS | None) -> dict[str, Valeur]:
        v = dict(self.macros_ext)
        for k, val in (self.config.get("global") or {}).items():
            if not isinstance(val, list):
                v[k.upper()] = Valeur(str(val), "config", "macros_config.yml (global)")
        if programme is not None:
            nom = programme.chemin.name
            for k, val in ((self.config.get("par_script") or {}).get(nom) or {}).items():
                if not isinstance(val, list):
                    v[k.upper()] = Valeur(str(val), "config", f"macros_config.yml (par_script {nom})")
            for rep, defs in (self.config.get("par_repertoire") or {}).items():
                if rep.lower() in {p.lower() for p in programme.chemin.parts}:
                    for k, val in (defs or {}).items():
                        if not isinstance(val, list):
                            v[k.upper()] = Valeur(str(val), "config", f"macros_config.yml (par_repertoire {rep})")
        return v

    @staticmethod
    def _lets_avant(f: FichierSAS, pos: int | None, source: str) -> dict[str, Valeur]:
        v = {}
        for l in f.lets:
            if pos is None or l.pos < pos:
                v[l.nom] = Valeur(l.valeur, source, l.fichier, l.ligne)
        return v

    def _absorber(self, ctx: Contexte, f: FichierSAS, jusqua: int | None, source: str, profondeur=0, vus=None):
        """Ajoute au contexte les %LET / LIBNAME de f (avant la position `jusqua`) et de ses %include."""
        vus = vus if vus is not None else set()
        cle = cle_fichier(str(f.chemin))
        if cle in vus or profondeur > 4:
            return
        vus.add(cle)
        evenements = [(l.pos, "let", l) for l in f.lets] + [(lb.pos, "lib", lb) for lb in f.libnames]
        incl = self.includes_resolus(f, ctx.macros)
        evenements += [(p, "inc", (c, ch)) for p, c, ch in incl]
        for pos, typ, obj in sorted(evenements, key=lambda e: e[0]):
            if jusqua is not None and pos >= jusqua:
                break
            if typ == "let":
                ctx.macros[obj.nom] = Valeur(obj.valeur, source, obj.fichier, obj.ligne)
            elif typ == "lib":
                ref, _, non = resoudre_texte(obj.ref, ctx.macros, ctx.dynamiques)
                ctx.libnames[ref.upper()] = (obj, source)
            else:
                c, ch = obj
                if c in self.fichiers:          # un autre programme : ses définitions ne sont pas reprises
                    continue
                inc = self.fichier(c, ch)
                if inc and inc.lisible:
                    self._absorber(ctx, inc, None, "include" if source == "programme" else source, profondeur + 1, vus)

    def contexte_initial(self, cle: str) -> tuple[Contexte, list[str]]:
        """Contexte au début du programme : config + date.sas + lanceur (avant l'inclusion du programme)."""
        f = self.fichiers[cle]
        ctx = Contexte(macros=self._valeurs_config(f), dynamiques=set(self.dyn_ext))
        for ref, chemin in (self.config.get("libnames") or {}).items():
            ctx.libnames[ref.upper()] = (Libname(0, 0, ref.upper(), str(chemin), "", False,
                                                 "macros_config.yml (libnames)", f"libname {ref} '{chemin}'"), "environnement")
        lanceurs = sorted(self.inclus_par.get(cle, []))
        for lanceur, _ in lanceurs[:1]:
            fl = self.fichiers[lanceur]
            pos_inclusion = next((p for p, c, _ in self.includes_resolus(fl, ctx.macros) if c == cle), None)
            self._absorber(ctx, fl, pos_inclusion, "lanceur")
        return ctx, [self.fichiers[l].chemin.name for l, _ in lanceurs]

    # ------------------------------------------------------------------ LIBNAME
    def resoudre_lib(self, ref: str, f: FichierSAS, pos_ligne: int, ctx: Contexte,
                     libs_programme: dict[str, tuple[Libname, str]]) -> ResolutionLib:
        trouve = libs_programme.get(ref) or ctx.libnames.get(ref)
        if not trouve:
            return ResolutionLib(ref, "NON_RESOLU", commentaire="aucun LIBNAME trouvé (programme, %include, lanceur, "
                                 "configuration) : bibliothèque pré-assignée ou définie ailleurs")
        lb, source = trouve
        defini = f"{Path(lb.fichier).name} (l.{lb.ligne})" if lb.ligne else lb.fichier
        if lb.concatenation:
            return ResolutionLib(ref, "COMPLEXE", moteur=lb.moteur, defini_dans=defini, source_mapping=source,
                                 commentaire=f"bibliothèque concaténée : {lb.texte}")
        if lb.moteur and lb.moteur not in ("base", "v9", "v8", "v7", "spde", "cvp") and not lb.chemin_brut:
            return ResolutionLib(ref, "COMPLEXE", moteur=lb.moteur, defini_dans=defini, source_mapping=source,
                                 commentaire=f"moteur {lb.moteur} sans chemin : {lb.texte}")
        valeurs = dict(ctx.macros)
        valeurs.update({k: v for k, v in libs_valeurs(f, lb).items()})
        chemin, res, non = resoudre_texte(lb.chemin_brut, valeurs, ctx.dynamiques)
        if non:
            return ResolutionLib(ref, "CHEMIN_MACRO_NON_RESOLUE", chemin="", chemin_brut=lb.chemin_brut,
                                 moteur=lb.moteur, defini_dans=defini, source_mapping=source,
                                 commentaire="macro-variable(s) non résolue(s) : " + ", ".join("&" + n for n in non))
        return ResolutionLib(ref, "RESOLU", chemin=chemin, chemin_brut=lb.chemin_brut, moteur=lb.moteur,
                             defini_dans=defini, source_mapping=source,
                             commentaire=("; ".join(res) if res else ""))


def libs_valeurs(f: FichierSAS, lb: Libname) -> dict[str, Valeur]:
    """%LET du même fichier que le LIBNAME, définis avant lui."""
    return {l.nom: Valeur(l.valeur, "programme" if l.fichier == str(f.chemin) else "include", l.fichier, l.ligne)
            for l in sorted(f.lets, key=lambda x: x.pos) if l.fichier == lb.fichier and l.pos < lb.pos}
