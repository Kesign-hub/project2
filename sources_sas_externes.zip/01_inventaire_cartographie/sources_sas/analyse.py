# -*- coding: utf-8 -*-
"""Analyse d'UN fichier SAS : %LET, LIBNAME, FILENAME, %INCLUDE et accès aux tables (lectures / écritures),
dans l'ordre du programme. Aucune résolution ici : seulement ce qui est écrit dans le code."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from .lecture import chaines, instructions, lire_fichier

NOM = r"[A-Za-z_][A-Za-z0-9_]*"
TABLES_SYSTEME = {"_NULL_", "_DATA_", "_LAST_"}
MOTEURS_EXCEL = {"xlsx", "xls", "excel", "excelcs", "pcfiles"}
MOTEURS_SAS = {"base", "v9", "v8", "v7", "v6", "spde", "spds", "cvp"}


@dataclass
class Let:
    pos: int
    ligne: int
    nom: str
    valeur: str          # telle qu'écrite (guillemets retirés)
    fichier: str


@dataclass
class Libname:
    pos: int
    ligne: int
    ref: str             # peut contenir une macro (&LIB.)
    chemin_brut: str     # "" si aucun chemin
    moteur: str          # "" = moteur par défaut (base)
    concatenation: bool  # libname X ("a" "b") ou libname X (LIB1 LIB2)
    fichier: str
    texte: str


@dataclass
class Acces:
    ordre: int
    ligne: int
    sens: str            # LIT | ECRIT
    instruction: str     # SET, MERGE, SQL FROM, SQL JOIN, DATA=, OUT=, CREATE TABLE ...
    lib: str             # brut, en majuscules (« WORK » si nom à un niveau)
    table: str
    vue: bool = False


@dataclass
class FichierSAS:
    chemin: Path
    lets: list[Let] = field(default_factory=list)
    libnames: list[Libname] = field(default_factory=list)
    filenames: dict = field(default_factory=dict)        # fileref -> chemin brut
    includes: list[tuple[int, int, str]] = field(default_factory=list)  # (pos, ligne, cible brute)
    acces: list[Acces] = field(default_factory=list)
    lisible: bool = True


def separer_ref(token: str) -> tuple[str, str] | None:
    """« LIB.TABLE », « &LIB..&TAB. », « TABLE » -> (LIB, TABLE). Le point qui termine une macro (&X.)
    n'est pas le séparateur. Retourne None si ce n'est pas un nom de table."""
    t = token.strip().strip(",")
    if not t or t[0] in "'\"(" or "=" in t:
        return None
    morceaux, cour, i = [], "", 0
    while i < len(t):
        c = t[i]
        if c == "&":
            m = re.match(r"&+" + NOM + r"\.?", t[i:])
            if not m:
                return None
            cour += m.group(0)
            i += len(m.group(0))
            continue
        if c == ".":
            morceaux.append(cour)
            cour = ""
            i += 1
            continue
        if not (c.isalnum() or c == "_"):
            return None
        cour += c
        i += 1
    morceaux.append(cour)
    if len(morceaux) == 1:
        lib, table = "WORK", morceaux[0]
    elif len(morceaux) == 2:
        lib, table = morceaux
    else:
        return None
    if not table or not lib or not re.match(r"^[A-Za-z_&]", table) or not re.match(r"^[A-Za-z_&]", lib):
        return None
    if table.upper() in TABLES_SYSTEME:
        return None
    return lib.upper(), table.upper()


def sans_parentheses(s: str) -> str:
    out, prof = [], 0
    for c in s:
        if c == "(":
            prof += 1
        elif c == ")":
            prof = max(prof - 1, 0)
        elif prof == 0:
            out.append(c)
    return "".join(out)


def liste_tables(texte: str) -> list[tuple[str, str]]:
    texte = re.sub(r"\b(end|nobs|point|key|indsname|curobs|open)\s*=\s*[\w&.]+", " ", texte, flags=re.I)
    res = []
    for tok in sans_parentheses(texte).replace(",", " ").split():
        r = separer_ref(tok)
        if r:
            res.append(r)
    return res


def option(texte: str, nom: str) -> str | None:
    m = re.search(rf"(?<![\w&])\b{nom}\s*=\s*([&\w.]+)", sans_parentheses_options(texte), re.I)
    return m.group(1) if m else None


def sans_parentheses_options(texte: str) -> str:
    """Retire les options de table « (keep=... where=(...)) » placées après un nom, pour que
    « data=a(where=(out=1)) » ne soit pas lu comme out=1."""
    return re.sub(r"(?<=[\w.&])\s*\((?:[^()]|\([^()]*\))*\)", " ", texte)


RE_SQL_SOURCE = re.compile(
    r"\b(from|join)\s+(.+?)(?=\b(?:where|group|order|having|on|left|right|inner|full|cross|outer|natural|union|except|"
    r"intersect|outer|as\s+select)\b|\)|$)", re.I | re.S)


def analyser_fichier(chemin: Path) -> FichierSAS:
    f = FichierSAS(chemin=Path(chemin))
    code = lire_fichier(chemin)
    if code is None:
        f.lisible = False
        return f
    nomf = str(chemin)
    proc, ordre = None, 0

    def acces(sens, instr, ref, ligne, vue=False):
        nonlocal ordre
        ordre += 1
        f.acces.append(Acces(ordre, ligne, sens, instr, ref[0], ref[1], vue))

    for ins in instructions(code):
        m, b, mot = ins.masque, ins.brut, ins.mot
        low = m.lower()
        # ----- macro-langage et déclarations (valables partout)
        if mot == "%let":
            mm = re.match(r"%let\s+(" + NOM + r")\s*=(.*)$", b, re.I | re.S)
            if mm:
                v = mm.group(2).strip()
                if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
                    v = v[1:-1]
                f.lets.append(Let(ins.pos, ins.ligne, mm.group(1).upper(), v, nomf))
            continue
        if mot == "libname":
            mm = re.match(r"libname\s+(&?" + NOM + r"\.?)\s*(.*)$", b, re.I | re.S)
            if mm:
                ref, reste = mm.group(1).upper().rstrip("."), mm.group(2).strip()
                if re.match(r"(clear|list)\b", reste, re.I) or not reste:
                    continue
                moteur = ""
                mo = re.match(r"([A-Za-z]\w*)\s+", reste)
                if mo and not reste.startswith(("'", '"', "(")):
                    moteur = mo.group(1).lower()
                ch = chaines(reste)
                concat = bool(re.search(r"^\s*(\w+\s+)?\(", reste)) and (len(ch) > 1 or not ch)
                f.libnames.append(Libname(ins.pos, ins.ligne, ref, ch[0] if ch and not concat else "",
                                          moteur, concat, nomf, re.sub(r"\s+", " ", b)[:300]))
            continue
        if mot == "filename":
            mm = re.match(r"filename\s+(" + NOM + r")\s", b, re.I)
            ch = chaines(b)
            if mm and ch:
                f.filenames[mm.group(1).upper()] = ch[0]
            continue
        if mot == "%include":
            ch = chaines(b)
            if ch:
                for c in ch:
                    f.includes.append((ins.pos, ins.ligne, c))
            else:
                ref = re.match(r"%include\s+(" + NOM + r")", m, re.I)
                if ref:
                    f.includes.append((ins.pos, ins.ligne, "FILEREF:" + ref.group(1).upper()))
            continue

        # ----- étapes
        if mot == "proc":
            proc = (low.split()[1] if len(low.split()) > 1 else "").strip()
            if proc in ("datasets", "contents", "catalog", "format", "options", "printto"):
                # pas de lecture de données (CONTENTS lit la structure seulement)
                continue
            d = option(m, "data")
            o = option(m, "out")
            base = option(m, "base")
            if proc == "append":
                if d and separer_ref(d):
                    acces("LIT", "PROC APPEND DATA=", separer_ref(d), ins.ligne)
                if base and separer_ref(base):
                    acces("ECRIT", "PROC APPEND BASE=", separer_ref(base), ins.ligne)
                continue
            if d and separer_ref(d):
                acces("LIT", f"PROC {proc.upper()} DATA=", separer_ref(d), ins.ligne)
            if o and separer_ref(o):
                acces("ECRIT", f"PROC {proc.upper()} OUT=", separer_ref(o), ins.ligne)
            elif proc == "sort" and d and separer_ref(d):
                acces("ECRIT", "PROC SORT (sur place)", separer_ref(d), ins.ligne)
            continue
        if mot in ("run", "quit"):
            proc = None
            continue
        if mot == "data":                                       # une étape DATA termine une PROC
            proc = None
            tete = re.sub(r"/.*$", "", m[4:], flags=re.S)       # « / view=... »
            vue = bool(re.search(r"/\s*view\s*=", m, re.I))
            for ref in liste_tables(tete):
                acces("ECRIT", "DATA", ref, ins.ligne, vue)
            continue
        if mot in ("set", "merge", "update", "modify") and proc is None:
            for ref in liste_tables(m[len(mot):]):
                acces("LIT", mot.upper(), ref, ins.ligne)
            continue
        if proc is None and re.search(r"\bdeclare\s+hash\b|\bdcl\s+hash\b", low):
            for c in re.findall(r"dataset\s*:\s*['\"]([^'\"]+)['\"]", b, re.I):
                ref = separer_ref(c.split("(")[0])
                if ref:
                    acces("LIT", "HASH DATASET:", ref, ins.ligne)
            continue
        if proc == "sql":
            mc = re.match(r"\s*create\s+(table|view)\s+([&\w.]+)", m, re.I)
            if mc and separer_ref(mc.group(2)):
                acces("ECRIT", f"SQL CREATE {mc.group(1).upper()}", separer_ref(mc.group(2)), ins.ligne,
                      mc.group(1).lower() == "view")
            mi = re.match(r"\s*(insert\s+into|delete\s+from|update)\s+([&\w.]+)", m, re.I)
            if mi and separer_ref(mi.group(2)):
                acces("ECRIT", "SQL " + mi.group(1).upper().split()[0], separer_ref(mi.group(2)), ins.ligne)
            if re.match(r"\s*(drop|describe)\b", m, re.I):
                continue
            corps = m[mi.end():] if mi and mi.group(1).lower().startswith("delete") else m
            for s in RE_SQL_SOURCE.finditer(corps):
                if re.match(r"\s*connection\s+to\b", s.group(2), re.I):
                    continue
                for morceau in sans_parentheses(s.group(2)).split(","):
                    tok = morceau.strip().split()[0] if morceau.strip() else ""
                    ref = separer_ref(tok)
                    if ref:
                        acces("LIT", "SQL " + s.group(1).upper(), ref, ins.ligne)
            continue
        if proc:
            o = option(m, "out")
            if o and separer_ref(o):
                acces("ECRIT", f"PROC {proc.upper()} OUT=", separer_ref(o), ins.ligne)
    return f
