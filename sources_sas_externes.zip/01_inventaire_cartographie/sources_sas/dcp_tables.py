# -*- coding: utf-8 -*-
"""DCP d'une table SAS, au même format que les DCP des fichiers plats (onglet Données, listes déroulantes,
légende, contrôle F99). Seule la DESCRIPTION de la table est lue (en-tête), jamais les données."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

try:
    import pyreadstat
except ImportError:  # signalé à l'utilisation
    pyreadstat = None

# ---------------------------------------------------------------- format DCP (identique à dcp_generator)
COLONNES_DCP = [
    "Base", "Table", "Nom de la donnée", "Libellé court", "Description",
    "Type", "Longueur", "Décimale", "Format", "Not Null",
    "Clé", "Catégorie CNIL", "Méthode_Anonymisation", "Mode_TOKEN", "Référence_TOKEN",
    "Données sources", "Champ actif/inactif", "Date de création", "Date d'inactivation", "ID MEGA",
]
CNIL_MODALITES = [
    "A - État civil, identité, données d'identification, images...",
    "B - Vie personnelle (habitudes de vie, situation familiale)",
    "C - Vie professionnelle",
    "D - Informations d'ordre économique et financier",
    "E - Données de connexion (adresses IP, logs)",
    "F - Données de localisation (déplacements, données GPS, GSM)",
    "G - Données révélant l'origine raciale ou ethnique",
    "H - Données révélant les opinions politiques",
    "I - Données révélant les convictions religieuses ou philosophiques",
    "J - Données révélant l'appartenance syndicale",
    "K - Données génétiques",
    "L - Données biométriques",
    "M - Données concernant la santé",
    "N - Données concernant la vie sexuelle ou l'orientation sexuelle",
    "O - Données relatives à des condamnations pénales ou infractions",
    "P - Numéro d'identification national unique (NIR)",
    "Z - Sans objet",
    "Validé : Z - Sans objet",
]
LISTES = {"Méthode_Anonymisation": (2, ["MASQUAGE", "TOKENISATION", "AUCUNE"]),
          "Mode_TOKEN": (3, ["P", "PN_2P"])}
A_REMPLIR = {"Catégorie CNIL", "Méthode_Anonymisation", "Clé", "Date de création"}
PATTERNS_CLE = re.compile(r"^(SIN|CONTRAT|IMAGE|INTASSU|REFASSU|NUM_\w+|NO_\w+|ID_\w+|CODE_\w+|CLE_\w+|\w+_ID)$", re.I)

ENTETE_FONT = Font(name="Arial", bold=True, color="FFFFFF")
ENTETE_FILL = PatternFill("solid", fgColor="1F4E78")
BASE_FONT = Font(name="Arial", size=10)
A_COMPLETER = PatternFill("solid", fgColor="FFF2CC")
SUGGESTION = PatternFill("solid", fgColor="DAEEF3")
ROUGE = PatternFill("solid", fgColor="FFC7CE")


def humaniser(nom: str) -> str:
    return " ".join(m if len(m) <= 3 or m.isupper() else m.capitalize() for m in nom.replace("_", " ").split())


def nom_dcp(chemin) -> str:
    """Même nom que la cartographie des fichiers plats : DCP_<nom>__<empreinte du chemin physique>.xlsx
    (fonction _nom_fichier_dcp de cartographie.dcp_generator quand elle est disponible)."""
    try:
        from cartographie.dcp_generator import _nom_fichier_dcp
        return _nom_fichier_dcp(str(chemin), "")
    except ImportError:
        cle = str(chemin).strip().lower().replace("/", "\\").rstrip("\\") + "|"
        h = hashlib.md5(cle.encode("utf-8", "replace")).hexdigest()[:8]
        base = re.split(r"[\\/]", str(chemin))[-1].rsplit(".", 1)[0]
        return f"DCP_{re.sub(r'[^A-Za-z0-9_-]', '_', base)}__{h}.xlsx"


def lire_description(chemin):
    if pyreadstat is None:
        raise RuntimeError("pyreadstat absent : activer le venv")
    if str(chemin).lower().endswith(".xpt"):
        _, meta = pyreadstat.read_xport(str(chemin), metadataonly=True)
    else:
        _, meta = pyreadstat.read_sas7bdat(str(chemin), metadataonly=True)
    return meta


def colonnes_dcp(meta) -> list[dict]:
    out = []
    labels = meta.column_labels or [None] * len(meta.column_names)
    for nom, lib in zip(meta.column_names, labels):
        typ = "C" if meta.readstat_variable_types.get(nom) == "string" else "N"
        lng = meta.variable_storage_width.get(nom) or 8
        fmt = (meta.original_variable_types.get(nom) or "").strip()
        if fmt in ("$", "NULL", "BEST", "F") or (typ == "C" and not fmt.startswith("$")):
            fmt = ""
        if fmt and not re.search(r"\d*\.\d*$", fmt):
            fmt += "."
        dec = ""
        m = re.search(r"\.(\d+)$", fmt)
        if typ == "N" and m and m.group(1) != "0":
            dec = int(m.group(1))
        out.append({"nom": nom, "libelle": (lib or "").strip(), "type": typ, "longueur": int(lng),
                    "format": fmt, "decimale": dec, "cle": "OUI (pattern)" if PATTERNS_CLE.match(nom) else ""})
    return out


def ecrire_dcp(chemin: Path, meta, cols: list[dict], cible: Path, date_effet: str) -> list[str]:
    wb = Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Données")
    for j, c in enumerate(COLONNES_DCP, 1):
        cell = ws.cell(row=1, column=j, value=c)
        cell.font, cell.fill = ENTETE_FONT, ENTETE_FILL
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
    nomf = re.split(r"[\\/]", str(chemin))[-1]
    table = meta.table_name or nomf.rsplit(".", 1)[0]
    for i, c in enumerate(cols, 2):
        v = {"Base": "", "Table": table, "Nom de la donnée": c["nom"],
             "Libellé court": c["libelle"] or c["nom"], "Description": c["libelle"] or humaniser(c["nom"]),
             "Type": c["type"], "Longueur": c["longueur"], "Décimale": c["decimale"], "Format": c["format"],
             "Not Null": "", "Clé": c["cle"], "Catégorie CNIL": "", "Méthode_Anonymisation": "",
             "Mode_TOKEN": "", "Référence_TOKEN": "", "Données sources": nomf,
             "Champ actif/inactif": "actif", "Date de création": date_effet, "Date d'inactivation": "", "ID MEGA": ""}
        for j, col in enumerate(COLONNES_DCP, 1):
            cell = ws.cell(row=i, column=j, value=v[col] if v[col] != "" else None)
            cell.font = BASE_FONT
            if col == "Clé" and v[col]:
                cell.fill = SUGGESTION
            elif col in A_REMPLIR and v[col] in ("", None):
                cell.fill = A_COMPLETER
    larg = {"Base": 12, "Table": 22, "Nom de la donnée": 26, "Libellé court": 26, "Description": 35,
            "Type": 8, "Longueur": 10, "Décimale": 10, "Format": 14, "Not Null": 10, "Clé": 14,
            "Catégorie CNIL": 45, "Méthode_Anonymisation": 22, "Mode_TOKEN": 12, "Référence_TOKEN": 15,
            "Données sources": 30, "Champ actif/inactif": 14, "Date de création": 14,
            "Date d'inactivation": 14, "ID MEGA": 14}
    for j, col in enumerate(COLONNES_DCP, 1):
        ws.column_dimensions[get_column_letter(j)].width = larg.get(col, 15)
    ws.freeze_panes = "A2"

    # Listes déroulantes (feuille cachée), comme les DCP des fichiers plats
    ref = wb.create_sheet("_REF_CNIL")
    for r, val in enumerate(CNIL_MODALITES, 1):
        ref.cell(row=r, column=1, value=val)
    ref.sheet_state = "hidden"
    n = ws.max_row
    if n >= 2:
        def liste(col_nom, col_ref, nb):
            lettre = get_column_letter(COLONNES_DCP.index(col_nom) + 1)
            lr = get_column_letter(col_ref)
            dv = DataValidation(type="list", formula1=f"'_REF_CNIL'!${lr}$1:${lr}${nb}", allow_blank=True)
            dv.errorStyle, dv.showErrorMessage = "warning", True
            dv.error = "Valeur hors liste : vous pouvez la garder si nécessaire."
            ws.add_data_validation(dv)
            dv.add(f"{lettre}2:{lettre}{n}")
        liste("Catégorie CNIL", 1, len(CNIL_MODALITES))
        for col_nom, (col_ref, vals) in LISTES.items():
            for r, val in enumerate(vals, 1):
                ref.cell(row=r, column=col_ref, value=val)
            liste(col_nom, col_ref, len(vals))

    leg = wb.create_sheet("Légende")
    leg["A1"], leg["B1"] = "Couleur", "Signification"
    leg["A2"], leg["B2"] = "█████", "Suggestion automatique (à valider)"
    leg["A2"].fill = SUGGESTION
    leg["A3"], leg["B3"] = "█████", "Cellule à remplir par le métier / le DPO"
    leg["A3"].fill = A_COMPLETER
    leg["A5"] = f"Source : table SAS {chemin}"
    leg["A6"] = f"{meta.number_rows if meta.number_rows is not None else '?'} ligne(s) — description lue dans l'en-tête, aucune donnée lue"
    leg.column_dimensions["A"].width = 15
    leg.column_dimensions["B"].width = 45

    # Contrôle de compatibilité avec F99_regle_dcp (mêmes règles que pour les fichiers plats)
    alertes = []
    for c in cols:
        if c["type"] == "C" and c["format"] and not c["format"].startswith("$"):
            alertes.append(f"{c['nom']} : type C mais format non-$ ({c['format']})")
        if c["type"] == "N" and c["format"].startswith("$"):
            alertes.append(f"{c['nom']} : type N mais format $ ({c['format']})")
    if alertes:
        wa = wb.create_sheet("Alertes_F99")
        wa["A1"] = "Alertes de compatibilité F99_regle_dcp"
        for k, a in enumerate(alertes, 2):
            wa.cell(row=k, column=1, value=a).fill = ROUGE
        wa.column_dimensions["A"].width = 80
    cible.parent.mkdir(parents=True, exist_ok=True)
    wb.save(cible)
    return alertes




# ---------------------------------------------------------------- même circuit que les fichiers plats :
# script SAS d'extraction du schéma -> CSV -> DCP construits à partir du schéma SAS réel
class MetaSchema:
    """Équivalent minimal des métadonnées pyreadstat, construit depuis le CSV de schéma SAS."""
    def __init__(self, table_name: str, number_rows=None):
        self.table_name, self.number_rows = table_name, number_rows


def colonnes_depuis_schema(entrees: list[dict]) -> list[dict]:
    """Entrées de _charger_schema_ref (cartographie.dcp_generator) pour UNE table -> colonnes du DCP."""
    out = []
    for e in sorted(entrees, key=lambda x: int(float(x.get("varnum") or 0))):
        typ = (e.get("type") or "C").upper()
        typ = "C" if typ.startswith("C") else "N"
        try:
            lng = int(float(e.get("longueur") or 8))
        except ValueError:
            lng = 8
        fmt = (e.get("format") or "").strip()
        while fmt.endswith(".."):
            fmt = fmt[:-1]
        dec = ""
        m = re.search(r"\.(\d+)$", fmt)
        if typ == "N" and m and m.group(1) != "0":
            dec = int(m.group(1))
        nom = e.get("name", "")
        out.append({"nom": nom, "libelle": (e.get("label") or "").strip(), "type": typ, "longueur": lng,
                    "format": fmt, "decimale": dec, "cle": "OUI (pattern)" if PATTERNS_CLE.match(nom) else ""})
    return out
