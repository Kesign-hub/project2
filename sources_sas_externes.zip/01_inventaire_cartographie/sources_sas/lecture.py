# -*- coding: utf-8 -*-
"""Lecture des programmes SAS : décodage robuste, masquage des commentaires et du contenu des chaînes,
découpage en instructions. Logique reprise de recherche_libname.py (déjà testée sur le parc)."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


def lire_fichier(chemin: Path) -> str | None:
    """UTF-8 si possible, sinon latin-1 (accents Windows). Ne plante jamais."""
    try:
        brut = Path(chemin).read_bytes()
    except OSError:
        return None
    for enc in ("utf-8-sig", "utf-8"):
        try:
            return brut.decode(enc)
        except UnicodeDecodeError:
            pass
    return brut.decode("latin-1", errors="replace")


def masquer(code: str) -> str:
    """Blanchit (même longueur, \\n conservés) les commentaires /* */ et * ...; ainsi que le CONTENU
    des chaînes '...' / "..." (les guillemets restent). Un name literal 'x'n est conservé."""
    n, out, i, debut = len(code), list(code), 0, True

    def blanchir(a, b):
        for k in range(a, b):
            if out[k] not in "\r\n":
                out[k] = " "

    while i < n:
        c = code[i]
        if c == "/" and i + 1 < n and code[i + 1] == "*":
            fin = code.find("*/", i + 2)
            fin = n if fin == -1 else fin + 2
            blanchir(i, fin)
            i = fin
            continue
        if c in ("'", '"'):
            j = i + 1
            while j < n:
                if code[j] == c:
                    if j + 1 < n and code[j + 1] == c:
                        j += 2
                        continue
                    break
                j += 1
            fin = min(j + 1, n)
            literal = fin < n and code[fin] in "nN" and not (fin + 1 < n and (code[fin + 1].isalnum() or code[fin + 1] == "_"))
            if not literal:
                blanchir(i + 1, fin - 1)
            i = fin
            debut = False
            continue
        if c == "*" and debut:
            fin = code.find(";", i)
            fin = n if fin == -1 else fin + 1
            blanchir(i, fin)
            i = fin
            debut = True
            continue
        if c == ";":
            debut = True
        elif not c.isspace():
            debut = False
        i += 1
    return "".join(out)


@dataclass
class Instruction:
    pos: int          # position de début dans le fichier
    ligne: int
    masque: str       # texte, commentaires et contenu des chaînes blanchis
    brut: str         # texte original (chaînes lisibles)

    @property
    def mot(self) -> str:
        m = re.match(r"\s*(%?[A-Za-z_]\w*)", self.masque)
        return m.group(1).lower() if m else ""


def instructions(code: str) -> list[Instruction]:
    """Découpe en instructions (séparateur « ; » hors chaînes/commentaires)."""
    masque = masquer(code)
    res, debut = [], 0
    for m in re.finditer(";", masque):
        fin = m.start()
        bloc_m, bloc_b = masque[debut:fin], code[debut:fin]
        if bloc_m.strip():
            decal = len(bloc_m) - len(bloc_m.lstrip())
            p = debut + decal
            res.append(Instruction(p, code.count("\n", 0, p) + 1, bloc_m.strip(), bloc_b.strip()))
        debut = fin + 1
    reste = masque[debut:]
    if reste.strip():
        p = debut + len(reste) - len(reste.lstrip())
        res.append(Instruction(p, code.count("\n", 0, p) + 1, reste.strip(), code[debut:].strip()))
    return res


def chaines(texte_brut: str) -> list[str]:
    """Contenu des chaînes '...' / "..." d'une instruction (guillemets doublés gérés)."""
    return [a or b for a, b in re.findall(r'"((?:[^"]|"")*)"|\'((?:[^\']|\'\')*)\'', texte_brut)]
