# -*- coding: utf-8 -*-
"""Classeur de résultats de l'inventaire des sources SAS."""
from __future__ import annotations

from collections import Counter
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .lineage import REGLES, Ligne, Source

F_ENT = Font(name="Arial", bold=True, color="FFFFFF")
FILL_ENT = PatternFill("solid", fgColor="1F4E78")
F = Font(name="Arial", size=10)
COULEURS = {"EXTERNE_SAS": "C6EFCE", "A_VERIFIER": "FFF2CC", "NON_RESOLU": "FCE4D6", "INFOCENTRE": "DDEBF7"}

DETAIL = ["Lot", "Domaine", "Programme", "Lanceur", "Ligne_code", "Type_instruction", "LIBREF", "Table",
          "Chemin_librairie", "Chemin_physique_estime", "Type_source", "Classification", "Regle", "Est_infocentre",
          "Est_externe", "Est_input", "Est_sortie", "Programme_producteur", "Defini_dans", "Source_mapping",
          "Macro_resolue", "Statut_resolution", "A_desensibiliser", "Commentaire", "Chemin_programme"]
CONSO = ["Lot", "Domaine", "LIBREF", "Table", "Chemin_librairie", "Chemin_fichier_sas7bdat", "Programmes_utilisateurs",
         "Nb_programmes", "Classification", "Regle", "Programme_producteur", "A_desensibiliser", "Statut", "Commentaire"]


def _feuille(wb, titre, entetes, lignes, largeurs=None, col_classe=None):
    ws = wb.create_sheet(titre)
    for j, h in enumerate(entetes, 1):
        c = ws.cell(row=1, column=j, value=h)
        c.font, c.fill, c.alignment = F_ENT, FILL_ENT, Alignment(horizontal="center", wrap_text=True)
    for i, l in enumerate(lignes, 2):
        for j, v in enumerate(l, 1):
            c = ws.cell(row=i, column=j, value=v)
            c.font = F
        if col_classe is not None:
            coul = COULEURS.get(l[col_classe])
            if coul:
                ws.cell(row=i, column=col_classe + 1).fill = PatternFill("solid", fgColor=coul)
    for j, w in enumerate(largeurs or [], 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = "A2"
    if lignes:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(entetes))}{len(lignes) + 1}"
    return ws


def _detail(l: Ligne) -> list:
    return [l.lot, l.domaine, l.programme, l.lanceur, l.ligne, l.type_instruction, l.libref, l.table,
            l.chemin_librairie, l.chemin_physique, l.type_source, l.classification, l.regle,
            "OUI" if l.est_infocentre else "", "OUI" if l.est_externe else "", "OUI" if l.est_input else "",
            "OUI" if l.est_sortie else "", l.producteur, l.defini_dans, l.source_mapping, l.macro_resolue,
            l.statut_resolution, l.a_desensibiliser, l.commentaire, l.chemin_programme]


def _conso(s: Source) -> list:
    return [s.lot, s.domaine, s.libref, s.table, s.chemin_librairie, s.chemin_fichier, ", ".join(s.programmes),
            len(s.programmes), s.classification, s.regle, s.producteur, s.a_desensibiliser, s.statut, s.commentaire]


def ecrire(chemin: Path, lignes: list[Ligne], sources: list[Source], libnames: list[list], params: list[tuple]):
    wb = Workbook()
    ws = wb.active
    ws.title = "Synthese"
    ws["A1"] = "Inventaire des tables SAS externes lues par les programmes (hors Infocentre)"
    ws["A1"].font = Font(name="Arial", bold=True, size=13, color="1F3864")
    r = 3
    for k, v in params:
        ws.cell(row=r, column=1, value=k).font = Font(name="Arial", bold=True)
        ws.cell(row=r, column=2, value=v).font = F
        r += 1
    r += 1
    ws.cell(row=r, column=1, value="Sources (vue consolidée) par classification").font = Font(name="Arial", bold=True)
    for k, n in sorted(Counter(s.classification for s in sources).items()):
        r += 1
        ws.cell(row=r, column=1, value=k).font = F
        ws.cell(row=r, column=2, value=n).font = F
    r += 2
    ws.cell(row=r, column=1, value="Onglets").font = Font(name="Arial", bold=True)
    for k, v in [("Sources_externes", "LA LISTE À DÉSENSIBILISER : tables SAS externes, hors Infocentre (une ligne par fichier)"),
                 ("A_verifier", "sources SAS non résolues ou douteuses : décision humaine"),
                 ("Toutes_sources", "toutes les sources lues, consolidées, toutes classifications"),
                 ("Detail", "une ligne par lecture / écriture, programme par programme (lineage)"),
                 ("Libnames", "LIBNAME trouvés et leur origine"),
                 ("Regles", "signification de chaque règle de classification")]:
        r += 1
        ws.cell(row=r, column=1, value=k).font = F
        ws.cell(row=r, column=2, value=v).font = F
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 110

    larg_c = [8, 18, 12, 30, 50, 60, 45, 8, 22, 34, 30, 12, 26, 60]
    ic = CONSO.index("Classification")
    _feuille(wb, "Sources_externes", CONSO, [_conso(s) for s in sources if s.classification == "EXTERNE_SAS"], larg_c, ic)
    _feuille(wb, "A_verifier", CONSO, [_conso(s) for s in sources if s.a_desensibiliser == "A VERIFIER"], larg_c, ic)
    _feuille(wb, "Toutes_sources", CONSO, [_conso(s) for s in sources], larg_c, ic)
    _feuille(wb, "Detail", DETAIL, [_detail(l) for l in lignes],
             [8, 18, 30, 25, 8, 22, 12, 30, 45, 55, 10, 24, 30, 8, 8, 8, 8, 25, 28, 14, 40, 22, 12, 60, 60],
             DETAIL.index("Classification"))
    _feuille(wb, "Libnames", ["Fichier", "Ligne", "LIBREF", "Moteur", "Chemin (tel qu'écrit)", "Concaténation", "Instruction"],
             libnames, [40, 8, 12, 10, 70, 12, 90])
    _feuille(wb, "Regles", ["Regle", "Signification"], sorted(REGLES.items()), [34, 120])
    chemin.parent.mkdir(parents=True, exist_ok=True)
    wb.save(chemin)
