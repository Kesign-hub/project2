# -*- coding: utf-8 -*-
"""
inventorier_sources_sas_externes.py
===================================
Recense les TABLES SAS EXTERNES (.sas7bdat) réellement lues par des programmes SAS, hors Infocentre,
hors tables WORK et hors tables produites par les programmes du périmètre ; puis (option
--cartographie) prépare leurs DCP exactement comme la cartographie des fichiers plats.

LECTURE SEULE : aucun programme SAS n'est modifié, aucune donnée n'est lue.

    python 01_inventaire_cartographie\\inventorier_sources_sas_externes.py '<dossier_programmes>' ^
        --sortie 'sources_externes.xlsx'

Options :
    --lot 'Lot 1'              colonne Lot (défaut : déduit du chemin « Lot N »)
    --config FICHIER.yml       même macros_config.yml que generate_cartography.py (global, par_script,
                               par_repertoire, fichiers_externes) + deux sections facultatives :
                                 libnames:  {DATE1225: '\\\\serveur\\...\\data2025'}   (bibliothèques pré-assignées)
                                 infocentre: ['\\\\infocentre\\\\', 'DSIALI']       (motifs de chemins Infocentre)
    --date-sas FICHIER         macro-variables de date (défaut : celui de la cartographie, s'il est accessible)
    --infocentre MOTIF ...     motifs (expressions régulières) reconnaissant un chemin Infocentre
                               (défaut : « infocentre »)
    --exclure DOSSIER ...      sous-dossiers ignorés (défaut : desensibilisation, cartographie)
    --sans-test-disque         ne pas vérifier l'existence des .sas7bdat
    --cartographie DOSSIER     cartographie des tables EXTERNE_SAS, comme pour les fichiers plats :
        --generate-schema-script   ÉTAPE 1 : écrit DOSSIER\\extract_schema_tables<_suffixe>.sas, à exécuter dans
                                   SAS (dictionary.columns, lecture seule) -> schema_tables<_suffixe>.csv
        --schema-ref FICHIER.csv   ÉTAPE 2 : crée les DCP dans DOSSIER\\DCP\\<domaine>\\ à partir du schéma SAS
                                   réel + inventaire_tables_sas<_suffixe>.xlsx au format des fichiers plats
        (sans l'une ni l'autre : dépannage, description lue directement par pyreadstat)
    --suffixe NOM              suffixe des fichiers de cartographie (ex. _Satisfaction_client)
    --date-effet JJ/MM/AAAA    date de création inscrite dans les DCP
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from datetime import datetime
from pathlib import Path

ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI))

from sources_sas.analyse import analyser_fichier  # noqa: E402
from sources_sas.export import ecrire  # noqa: E402
from sources_sas.lineage import Analyseur, consolider  # noqa: E402
from sources_sas.resolution import Resolveur, cle_fichier  # noqa: E402

DATE_SAS_DEFAUT = r"J:\DSIN\P_Perf\01_SUIVI\00_DATE\date.sas"


def charger_config(chemin: str | None) -> dict:
    if not chemin:
        return {}
    try:
        import yaml
        with open(chemin, encoding="utf-8") as fh:
            return yaml.safe_load(fh) or {}
    except Exception as e:  # noqa: BLE001
        sys.exit(f"[ERREUR] Configuration illisible {chemin} : {e}")


def macros_date_sas(chemins: list[str]) -> tuple[dict, set]:
    try:
        from cartographie.macro_resolver import obtenir_macros_externes
        return obtenir_macros_externes(chemins)
    except Exception:  # noqa: BLE001
        return {}, set()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Tables SAS externes lues par les programmes (hors Infocentre).")
    ap.add_argument("dossier")
    ap.add_argument("--sortie", default="sources_sas_externes.xlsx")
    ap.add_argument("--lot")
    ap.add_argument("--config")
    ap.add_argument("--date-sas")
    ap.add_argument("--infocentre", nargs="*")
    ap.add_argument("--exclure", nargs="*", default=[])
    ap.add_argument("--sans-test-disque", action="store_true")
    ap.add_argument("--cartographie")
    ap.add_argument("--suffixe", default="")
    ap.add_argument("--generate-schema-script", action="store_true")
    ap.add_argument("--schema-ref")
    ap.add_argument("--date-effet", default="")
    a = ap.parse_args(argv)

    racine = Path(a.dossier)
    if not racine.is_dir():
        sys.exit(f"[ERREUR] Dossier introuvable : {racine}")
    config = charger_config(a.config)
    exclus = {e.lower() for e in ["desensibilisation", "cartographie", *a.exclure]}
    programmes = [p for p in sorted(racine.rglob("*.sas"))
                  if not exclus & {x.lower() for x in p.relative_to(racine).parts[:-1]}
                  and "_desensibilise" not in p.stem.lower()]
    if not programmes:
        sys.exit(f"[ERREUR] Aucun programme .sas sous {racine}")
    lot = a.lot or next((m.group(0) for m in [re.search(r"Lot[ _]?\d+", str(racine), re.I)] if m), "")

    date_sas = [a.date_sas] if a.date_sas else ([DATE_SAS_DEFAUT] if os.path.isfile(DATE_SAS_DEFAUT) else [])
    date_sas += list(config.get("fichiers_externes") or [])
    macros_ext, dyn_ext = macros_date_sas(date_sas) if date_sas else ({}, set())
    motifs = a.infocentre if a.infocentre else (config.get("infocentre") or [r"infocentre"])

    print(f"{len(programmes)} programme(s) sous {racine}")
    fichiers = {cle_fichier(str(p)): analyser_fichier(p) for p in programmes}
    illisibles = [f.chemin.name for f in fichiers.values() if not f.lisible]
    res = Resolveur(fichiers, config, macros_ext, dyn_ext, ", ".join(date_sas) or "date.sas")
    an = Analyseur(racine, fichiers, res, lot, motifs, tester_disque=not a.sans_test_disque)
    an.collecter()
    an.classer()
    sources = consolider(an.lignes)

    libnames = [[f.chemin.name, lb.ligne, lb.ref, lb.moteur, lb.chemin_brut, "OUI" if lb.concatenation else "", lb.texte]
                for f in fichiers.values() for lb in f.libnames]
    libnames += [[f.chemin.name + " (%include)", lb.ligne, lb.ref, lb.moteur, lb.chemin_brut,
                  "OUI" if lb.concatenation else "", lb.texte]
                 for f in res.externes.values() if f for lb in f.libnames]
    params = [("Dossier analysé", str(racine)), ("Date", f"{datetime.now():%d/%m/%Y %H:%M}"),
              ("Programmes", len(programmes)), ("Programmes illisibles", ", ".join(illisibles) or "aucun"),
              ("Lanceurs détectés (programmes qui en incluent d'autres)",
               ", ".join(sorted({fichiers[l].chemin.name for v in res.inclus_par.values() for l, _ in v})) or "aucun"),
              ("Macro-variables externes", ", ".join(date_sas) or "aucune"),
              ("Configuration", a.config or "aucune"), ("Motifs Infocentre", " | ".join(motifs)),
              ("Existence des fichiers vérifiée", "non" if a.sans_test_disque else "oui")]
    sortie = Path(a.sortie)
    if sortie.exists():
        sortie = sortie.with_name(f"{sortie.stem}_{datetime.now():%Y%m%d_%H%M}{sortie.suffix}")
    try:
        ecrire(sortie, an.lignes, sources, libnames, params)
    except PermissionError:
        sys.exit("[ERREUR] Fichier de sortie ouvert dans Excel : le fermer et relancer.")

    from collections import Counter
    c = Counter(s.classification for s in sources)
    print(f"\n{len(an.lignes)} accès à des tables, {len(sources)} source(s) distincte(s) :")
    for k, n in sorted(c.items()):
        print(f"  {k:28s} {n}")
    print(f"-> {sortie}")
    print("   Liste à désensibiliser : onglet Sources_externes ; décisions humaines : onglet A_verifier")

    if a.cartographie and a.generate_schema_script:
        from sources_sas.cartographie_tables import generer_script_schema
        carto = Path(a.cartographie)
        sas, csvp = carto / f"extract_schema_tables{a.suffixe}.sas", carto / f"schema_tables{a.suffixe}.csv"
        n = generer_script_schema([(s.table, s.chemin_fichier) for s in sources
                                   if s.classification == "EXTERNE_SAS" and s.chemin_fichier], sas, csvp)
        print(f"\n-> Script SAS généré ({n} table(s)) : {sas}\n   1. Exécutez-le dans SAS (lecture seule)"
              f"\n   2. Il produit : {csvp}\n   3. Relancez avec : --cartographie '{carto}' --schema-ref '{csvp}'")
    elif a.cartographie:
        from sources_sas.cartographie_tables import cartographier
        b = cartographier(sources, an.lignes, Path(a.cartographie), a.suffixe, a.date_effet, a.schema_ref)
        print(f"\nCartographie : {b['dcp_crees']} DCP créé(s), {b['dcp_existants']} déjà présent(s) (conservés), "
              f"{b['absents']} fichier(s) absent(s), {b['illisibles']} illisible(s), "
              f"{b['sans_schema']} absente(s) du schéma SAS")
        if not a.schema_ref:
            print("   (dépannage : description lue par pyreadstat ; circuit normal = --generate-schema-script puis --schema-ref)")
        print(f"-> {b['inventaire']}\n-> {Path(a.cartographie) / 'DCP'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
