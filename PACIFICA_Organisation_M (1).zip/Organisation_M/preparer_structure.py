#!/usr/bin/env python3
"""Prépare les dossiers PACIFICA; simulation par défaut, sans déplacement de fichiers.
Python 3.9+; bibliothèque standard uniquement. Voir LIRE_MOI.md et --help.
"""
import argparse
import csv
import json
import os
import re
import stat
from pathlib import Path, PureWindowsPath
from datetime import datetime


def load_architecture(path):
    config = json.loads(path.read_text(encoding='utf-8'))
    directories = []
    for value in config['dossiers']:
        win = PureWindowsPath(value)
        if win.is_absolute() or win.drive or '..' in win.parts or ':' in value:
            raise ValueError(f'Chemin de structure non relatif: {value}')
        directories.append(win.parts)
    return config, directories


def prepare(config, directories, destination, create=False, all_lots=False):
    source = Path(config['source']).resolve()
    target = destination.resolve()
    if target == source or source in target.parents or target in source.parents:
        raise ValueError('La cible doit être distincte de la source et hors de son arborescence.')
    if create and target.exists():
        raise FileExistsError('La cible existe déjà: choisir un dossier nouveau et dédié.')
    selected = [p for p in directories if all_lots or not (
        len(p)>1 and p[0]=='Lots' and p[1]!='Lot_01')]
    if create:
        # La racine doit exister: évite de créer une fausse arborescence si M: est absent.
        if not target.parent.is_dir():
            raise FileNotFoundError(f'Dossier parent inaccessible: {target.parent}')
        target.mkdir()
        for parts in selected:
            (target.joinpath(*parts)).mkdir(parents=True, exist_ok=True)
        print(f'{len(selected)} dossiers préparés dans {target}. Aucun fichier source traité.')
    else:
        print(f'SIMULATION: {len(selected)} dossiers proposés dans {destination}. Aucune création.')
    return selected


def reparse(path):
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, 'st_file_attributes', 0) & 1024)


def audit_links(source, old_root):
    if not source.is_dir():
        raise FileNotFoundError(f'Source inaccessible: {source}')
    report_dir = Path.cwd()/('audit_liens_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    report_dir.mkdir()
    extensions = {'.sas','.py','.bat','.cmd','.ps1','.yml','.yaml','.json','.ini','.cfg','.toml'}
    counts = {'fichiers_lus':0, 'references_a_verifier':0, 'erreurs':0}
    with (report_dir/'liens_a_verifier.csv').open('w',newline='',encoding='utf-8-sig') as f, \
         (report_dir/'erreurs.csv').open('w',newline='',encoding='utf-8-sig') as e:
        writer=csv.writer(f,delimiter=';');writer.writerow(['Fichier','Ligne','Nature','Statut'])
        error=csv.writer(e,delimiter=';');error.writerow(['Chemin','Erreur'])
        def fail(exc):
            counts['erreurs']+=1;error.writerow([str(getattr(exc,'filename','')),str(exc)])
        for current, subdirs, files in os.walk(source,onerror=fail,followlinks=False):
            kept=[]
            for name in subdirs:
                if name.lower() in {'venv','.venv','__pycache__','.git','.ipynb_checkpoints'}:
                    continue
                try:
                    if not reparse(Path(current)/name):kept.append(name)
                except OSError as exc:fail(exc)
            subdirs[:]=kept
            for name in files:
                p=Path(current)/name
                if p.suffix.lower() not in extensions:continue
                try:
                    if reparse(p):continue
                    if p.stat().st_size>10*1024*1024:
                        counts['erreurs']+=1;error.writerow([str(p),'Source texte >10 Mio: lecture ignorée, vérifier séparément'])
                        continue
                    raw=p.read_bytes()
                    try:content=raw.decode('utf-8-sig')
                    except UnicodeDecodeError:content=raw.decode('cp1252')
                    counts['fichiers_lus']+=1
                    for line_no,line in enumerate(content.splitlines(),1):
                        normalized=line
                        while '\\\\' in normalized:normalized=normalized.replace('\\\\','\\')
                        flags=[]
                        if old_root.casefold() in normalized.casefold():flags.append('Ancienne racine explicite')
                        if re.search(r'(?i)\b[A-Z]:[\\/]|\\\\[\w-]+\\',line):flags.append('Chemin absolu poste ou réseau')
                        if re.search(r'(?i)\b(libname|filename)\b|%include\b|CHEM_DCP|CHEM_FIC|CHEM98|CHEM99|sys\.path',line):flags.append('Paramétrage chemin SAS/Python')
                        if re.search(r'^\s*(?:from\s+\S+\s+import\b|import\s+\S+)',line) and p.suffix.lower()=='.py':flags.append('Import Python: vérifier après copie')
                        if flags:
                            writer.writerow([str(p),line_no,' / '.join(flags),'A_VERIFIER_NON_MODIFIE'])
                            counts['references_a_verifier']+=1
                except (OSError,UnicodeError) as exc:fail(exc)
    (report_dir/'resume.json').write_text(json.dumps(counts,indent=2),encoding='utf-8')
    print(f'Audit créé dans {report_dir}: {counts}. Aucun code modifié.')
    return report_dir,counts


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--architecture',type=Path,default=Path(__file__).with_name('architecture.json'))
    parser.add_argument('--cible',type=Path)
    parser.add_argument('--source',type=Path)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--creer',action='store_true',help='Créer uniquement les dossiers dans une nouvelle racine')
    mode.add_argument('--auditer-liens',action='store_true',help='Audit en lecture seule des sources texte')
    parser.add_argument('--tous-les-lots',action='store_true',help='Inclure les dossiers des lots 2 à 8')
    args=parser.parse_args()
    config,dirs=load_architecture(args.architecture)
    if args.source:config['source']=str(args.source)
    if args.auditer_liens:
        audit_links(Path(config['source']),config['source'])
    else:
        prepare(config,dirs,args.cible or Path(config['cible_proposee']),args.creer,args.tous_les_lots)


if __name__=='__main__':
    main()
