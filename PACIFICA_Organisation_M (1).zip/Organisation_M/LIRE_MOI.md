# PACIFICA — Organisation simplifiée

Ouvrir organisation_M.html. Pour trouver un fichier: LOT, puis DOMAINE, puis l’un des CINQ dossiers.

Racine proposée: M:\DSIN\Migration_SAS_Python
- 00_Guide_et_suivi: mode opératoire, consignes, documentation et liens d’équipe.
- Outils: scripts partagés, moteur d’anonymisation et projet Python existant.
- Lots: Lot_01 puis Climatique, Demandes, Pilotage_activite, Reporting, Satisfaction_client.
- 99_Archives: versions dont l’archivage a été décidé; rien n’y est envoyé automatiquement sur la seule base de sa date.

Dans chaque domaine:
1. 01_Codes: SAS d’origine, lanceurs et macros; transcriptions Python lorsque séparables du projet technique.
2. 02_Carto_DCP: cartographie, inventaires, DCP, échanges/validations DPO et historique des complétions.
3. 03_Desensibilisation: pilotage DOC, préparation des données et du code, résultats et contrôles correspondants.
4. 04_Recette: exécutions SAS et Python, WORK utiles, logs, résultats de référence et comparaisons.
5. 05_Livraisons: packages assemblés puis effectivement envoyés, manifeste et preuve de livraison.

Le dossier 00_Suivi au niveau du lot regroupe les sujets communs et exceptions. Une zone Transverse peut accueillir les fichiers dont le domaine n’est pas identifiable. Les outils techniques restent entiers: pas de fusion automatique des deux copies d’outils, ni d’extraction des macros, référentiels ou données de tokenisation avant audit.

## Exemple concret
Climatique/01_Codes/SAS_origine/HS_Secheresse_bulletin_climatique.sas contient le SAS source.
Climatique/04_Recette/SAS/Executions_a_qualifier/usine/HS_Secheresse_bulletin_climatique conserve ensemble le SAS désensibilisé exécuté, ses tables WORK, son log et sa sortie Excel.
Le dossier usine conserve son nom historique; il n’est pas reclassé comme livré sans validation.

## Limites et règles
Le périmètre analysé est M:\DSIN\Lot 1, pas tout M:. Inventaire: 8 723 fichiers, 772 dossiers, environ 178,1 Go cumulés. Aucun rapport d’erreurs du scan n’a été reçu. Les fichiers source du lecteur n’ont pas été lus.
Le plan contient 9 495 lignes et propose une destination par élément. Les dossiers sont descriptifs, jamais des instructions de copie récursive. Tous les statuts sont A_VERIFIER.
497 groupes sont des doublons POTENTIELS (nom + taille), pas des fichiers identiques prouvés. Ne pas supprimer sur ce seul critère.
Les noms DPO ou Ok_DCP, les dossiers usine/ONSHORE et les dates de modification ne prouvent ni conformité ni validation ni livraison.
Les historiques completion_, OLD/OLD2 et .bak sont conservés. Le venv et les caches restent à l’origine, exclus de la copie proposée. Recréer un venv local à partir de dépendances validées.
Conserver les restrictions d’accès aux données et référentiels de tokens. Ne pas envoyer les tables de correspondance des tokens dans les packages.
La structure contractuelle interne des ZIP Accenture doit être conservée; les cinq dossiers concernent l’espace de travail partagé.
Les projets Python et ensembles d’exécution restent groupés. Les chemins absolus, imports et paramètres DOC doivent être audités avant bascule. Les liens Excel et EGP demandent une vérification séparée.
SAS et Python se comparent sur les mêmes entrées et périodes. Les sources historiques manquantes ne doivent pas être remplacées arbitrairement. Un export créé ou une table vide ne valide pas une recette.

## Commandes (Python 3.9+, sans dépendance)
Simulation, sans création:
    python preparer_structure.py

Création des dossiers du lot 1 dans une NOUVELLE racine:
    python preparer_structure.py --creer --cible "M:\DSIN\Migration_SAS_Python"

Inclure les modèles vides des lots 2 à 8:
    python preparer_structure.py --creer --tous-les-lots --cible "M:\DSIN\Migration_SAS_Python"

Audit en lecture seule des chemins/imports:
    python preparer_structure.py --auditer-liens --source "M:\DSIN\Lot 1"

Le script ne copie, ne déplace ni ne supprime les fichiers et ne corrige pas les liens. Il crée seulement les dossiers sur option, ou un rapport d’audit local. Si une création échoue partiellement, ne pas supprimer le répertoire automatiquement: vérifier les dossiers créés.
Après revue du plan, copier un périmètre pilote, vérifier les empreintes SHA-256, adapter les chemins justifiés et tester dans Pacifica avant d’étendre. Ne pas recopier 178 Go d’emblée.

## Livrables
- organisation_M.html: guide lisible et arborescence dépliable.
- plan_classement.csv: ancien chemin vers destination proposée, avec validation à renseigner.
- doublons_potentiels.csv, chemins_longs_a_verifier.csv: points à contrôler.
- synthese_dossiers.csv: volumes actuels.
- modele_manifeste_package.csv: registre de package vide, à renseigner par programme et version.
- preparer_structure.py, architecture.json: simulation, création des dossiers et audit des liens.
